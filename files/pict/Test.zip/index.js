(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.currentSoundStreamInMovieclip;
	this.actionFrames = [];
	this.soundStreamDuration = new Map();
	this.streamSoundSymbolsList = [];

	this.gotoAndPlayForStreamSoundSync = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.gotoAndPlay = function(positionOrLabel){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(positionOrLabel);
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(this.currentFrame);
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
		this.clearAllSoundStreams();
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
		this.clearAllSoundStreams();
	}
	this.startStreamSoundsForTargetedFrame = function(targetFrame){
		for(var index=0; index<this.streamSoundSymbolsList.length; index++){
			if(index <= targetFrame && this.streamSoundSymbolsList[index] != undefined){
				for(var i=0; i<this.streamSoundSymbolsList[index].length; i++){
					var sound = this.streamSoundSymbolsList[index][i];
					if(sound.endFrame > targetFrame){
						var targetPosition = Math.abs((((targetFrame - sound.startFrame)/lib.properties.fps) * 1000));
						var instance = playSound(sound.id);
						var remainingLoop = 0;
						if(sound.offset){
							targetPosition = targetPosition + sound.offset;
						}
						else if(sound.loop > 1){
							var loop = targetPosition /instance.duration;
							remainingLoop = Math.floor(sound.loop - loop);
							if(targetPosition == 0){ remainingLoop -= 1; }
							targetPosition = targetPosition % instance.duration;
						}
						instance.loop = remainingLoop;
						instance.position = Math.round(targetPosition);
						this.InsertIntoSoundStreamData(instance, sound.startFrame, sound.endFrame, sound.loop , sound.offset);
					}
				}
			}
		}
	}
	this.InsertIntoSoundStreamData = function(soundInstance, startIndex, endIndex, loopValue, offsetValue){ 
 		this.soundStreamDuration.set({instance:soundInstance}, {start: startIndex, end:endIndex, loop:loopValue, offset:offsetValue});
	}
	this.clearAllSoundStreams = function(){
		var keys = this.soundStreamDuration.keys();
		for(var i = 0;i<this.soundStreamDuration.size; i++){
			var key = keys.next().value;
			key.instance.stop();
		}
 		this.soundStreamDuration.clear();
		this.currentSoundStreamInMovieclip = undefined;
	}
	this.stopSoundStreams = function(currentFrame){
		if(this.soundStreamDuration.size > 0){
			var keys = this.soundStreamDuration.keys();
			for(var i = 0; i< this.soundStreamDuration.size ; i++){
				var key = keys.next().value; 
				var value = this.soundStreamDuration.get(key);
				if((value.end) == currentFrame){
					key.instance.stop();
					if(this.currentSoundStreamInMovieclip == key) { this.currentSoundStreamInMovieclip = undefined; }
					this.soundStreamDuration.delete(key);
				}
			}
		}
	}

	this.computeCurrentSoundStreamInstance = function(currentFrame){
		if(this.currentSoundStreamInMovieclip == undefined){
			if(this.soundStreamDuration.size > 0){
				var keys = this.soundStreamDuration.keys();
				var maxDuration = 0;
				for(var i=0;i<this.soundStreamDuration.size;i++){
					var key = keys.next().value;
					var value = this.soundStreamDuration.get(key);
					if(value.end > maxDuration){
						maxDuration = value.end;
						this.currentSoundStreamInMovieclip = key;
					}
				}
			}
		}
	}
	this.getDesiredFrame = function(currentFrame, calculatedDesiredFrame){
		for(var frameIndex in this.actionFrames){
			if((frameIndex > currentFrame) && (frameIndex < calculatedDesiredFrame)){
				return frameIndex;
			}
		}
		return calculatedDesiredFrame;
	}

	this.syncStreamSounds = function(){
		this.stopSoundStreams(this.currentFrame);
		this.computeCurrentSoundStreamInstance(this.currentFrame);
		if(this.currentSoundStreamInMovieclip != undefined){
			var soundInstance = this.currentSoundStreamInMovieclip.instance;
			if(soundInstance.position != 0){
				var soundValue = this.soundStreamDuration.get(this.currentSoundStreamInMovieclip);
				var soundPosition = (soundValue.offset?(soundInstance.position - soundValue.offset): soundInstance.position);
				var calculatedDesiredFrame = (soundValue.start)+((soundPosition/1000) * lib.properties.fps);
				if(soundValue.loop > 1){
					calculatedDesiredFrame +=(((((soundValue.loop - soundInstance.loop -1)*soundInstance.duration)) / 1000) * lib.properties.fps);
				}
				calculatedDesiredFrame = Math.floor(calculatedDesiredFrame);
				var deltaFrame = calculatedDesiredFrame - this.currentFrame;
				if(deltaFrame >= 2){
					this.gotoAndPlayForStreamSoundSync(this.getDesiredFrame(this.currentFrame,calculatedDesiredFrame));
				}
			}
		}
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Mesh = function() {
	this.initialize(img.Mesh);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,356,354);


(lib.Mesh_1 = function() {
	this.initialize(img.Mesh_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.Mesh_2 = function() {
	this.initialize(img.Mesh_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,77,31);


(lib.Mesh_0 = function() {
	this.initialize(img.Mesh_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,65,93);


(lib.Mesh_0_1 = function() {
	this.initialize(img.Mesh_0_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,45,43);


(lib.Mesh_1_1 = function() {
	this.initialize(img.Mesh_1_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,77,48);


(lib.Mesh_0_2 = function() {
	this.initialize(img.Mesh_0_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,107,100);


(lib.Mesh_1_2 = function() {
	this.initialize(img.Mesh_1_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,193,135);


(lib.Mesh_3 = function() {
	this.initialize(img.Mesh_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,107,100);


(lib.Mesh_1_0 = function() {
	this.initialize(img.Mesh_1_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,45,47);


(lib.Mesh_2_1 = function() {
	this.initialize(img.Mesh_2_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,49,33);


(lib.Mesh_2_2 = function() {
	this.initialize(img.Mesh_2_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,45,47);


(lib.Mesh_3_1 = function() {
	this.initialize(img.Mesh_3_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,71,62);


(lib.Mesh_4 = function() {
	this.initialize(img.Mesh_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,71,62);


(lib.Mesh_5 = function() {
	this.initialize(img.Mesh_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,69,29);


(lib.Path = function() {
	this.initialize(img.Path);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,2);


(lib.Path_1 = function() {
	this.initialize(img.Path_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,2);


(lib.Path_10 = function() {
	this.initialize(img.Path_10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_11 = function() {
	this.initialize(img.Path_11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_12 = function() {
	this.initialize(img.Path_12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Mesh_4_1 = function() {
	this.initialize(img.Mesh_4_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,43,43);


(lib.Path_13 = function() {
	this.initialize(img.Path_13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,12,13);


(lib.Path_14 = function() {
	this.initialize(img.Path_14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,8,8);


(lib.Path_15 = function() {
	this.initialize(img.Path_15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Mesh_3_2 = function() {
	this.initialize(img.Mesh_3_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,49,33);


(lib.Path_17 = function() {
	this.initialize(img.Path_17);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,10);


(lib.Path_18 = function() {
	this.initialize(img.Path_18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_19 = function() {
	this.initialize(img.Path_19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_2 = function() {
	this.initialize(img.Path_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_21 = function() {
	this.initialize(img.Path_21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_22 = function() {
	this.initialize(img.Path_22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_23 = function() {
	this.initialize(img.Path_23);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_24 = function() {
	this.initialize(img.Path_24);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_25 = function() {
	this.initialize(img.Path_25);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_26 = function() {
	this.initialize(img.Path_26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_27 = function() {
	this.initialize(img.Path_27);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_28 = function() {
	this.initialize(img.Path_28);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_29 = function() {
	this.initialize(img.Path_29);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_3 = function() {
	this.initialize(img.Path_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_30 = function() {
	this.initialize(img.Path_30);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_31 = function() {
	this.initialize(img.Path_31);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_32 = function() {
	this.initialize(img.Path_32);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_33 = function() {
	this.initialize(img.Path_33);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,4);


(lib.Path_34 = function() {
	this.initialize(img.Path_34);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,4);


(lib.Path_35 = function() {
	this.initialize(img.Path_35);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_36 = function() {
	this.initialize(img.Path_36);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,2);


(lib.Path_37 = function() {
	this.initialize(img.Path_37);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,2);


(lib.Path_38 = function() {
	this.initialize(img.Path_38);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_39 = function() {
	this.initialize(img.Path_39);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_4 = function() {
	this.initialize(img.Path_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_40 = function() {
	this.initialize(img.Path_40);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_41 = function() {
	this.initialize(img.Path_41);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_42 = function() {
	this.initialize(img.Path_42);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_43 = function() {
	this.initialize(img.Path_43);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_44 = function() {
	this.initialize(img.Path_44);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_45 = function() {
	this.initialize(img.Path_45);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_46 = function() {
	this.initialize(img.Path_46);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19,19);


(lib.Path_47 = function() {
	this.initialize(img.Path_47);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_48 = function() {
	this.initialize(img.Path_48);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,11,11);


(lib.Path_49 = function() {
	this.initialize(img.Path_49);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_5 = function() {
	this.initialize(img.Path_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_50 = function() {
	this.initialize(img.Path_50);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_51 = function() {
	this.initialize(img.Path_51);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_52 = function() {
	this.initialize(img.Path_52);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,2);


(lib.Path_53 = function() {
	this.initialize(img.Path_53);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_54 = function() {
	this.initialize(img.Path_54);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_55 = function() {
	this.initialize(img.Path_55);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_56 = function() {
	this.initialize(img.Path_56);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,12,13);


(lib.Path_57 = function() {
	this.initialize(img.Path_57);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,8,8);


(lib.Path_58 = function() {
	this.initialize(img.Path_58);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_59 = function() {
	this.initialize(img.Path_59);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_6 = function() {
	this.initialize(img.Path_6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_60 = function() {
	this.initialize(img.Path_60);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_61 = function() {
	this.initialize(img.Path_61);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_62 = function() {
	this.initialize(img.Path_62);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_63 = function() {
	this.initialize(img.Path_63);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_64 = function() {
	this.initialize(img.Path_64);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_65 = function() {
	this.initialize(img.Path_65);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_66 = function() {
	this.initialize(img.Path_66);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_67 = function() {
	this.initialize(img.Path_67);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_68 = function() {
	this.initialize(img.Path_68);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_69 = function() {
	this.initialize(img.Path_69);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_7 = function() {
	this.initialize(img.Path_7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_70 = function() {
	this.initialize(img.Path_70);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_71 = function() {
	this.initialize(img.Path_71);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_72 = function() {
	this.initialize(img.Path_72);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,10);


(lib.Path_73 = function() {
	this.initialize(img.Path_73);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,10);


(lib.Path_74 = function() {
	this.initialize(img.Path_74);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,5);


(lib.Path_75 = function() {
	this.initialize(img.Path_75);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_76 = function() {
	this.initialize(img.Path_76);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_77 = function() {
	this.initialize(img.Path_77);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_78 = function() {
	this.initialize(img.Path_78);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_79 = function() {
	this.initialize(img.Path_79);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_8 = function() {
	this.initialize(img.Path_8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7,7);


(lib.Path_80 = function() {
	this.initialize(img.Path_80);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_81 = function() {
	this.initialize(img.Path_81);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_82 = function() {
	this.initialize(img.Path_82);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Path_83 = function() {
	this.initialize(img.Path_83);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,11);


(lib.Path_84 = function() {
	this.initialize(img.Path_84);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_85 = function() {
	this.initialize(img.Path_85);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_86 = function() {
	this.initialize(img.Path_86);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_87 = function() {
	this.initialize(img.Path_87);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_88 = function() {
	this.initialize(img.Path_88);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_89 = function() {
	this.initialize(img.Path_89);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_9 = function() {
	this.initialize(img.Path_9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,2);


(lib.Path_90 = function() {
	this.initialize(img.Path_90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_91 = function() {
	this.initialize(img.Path_91);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_92 = function() {
	this.initialize(img.Path_92);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_93 = function() {
	this.initialize(img.Path_93);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_94 = function() {
	this.initialize(img.Path_94);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,4);


(lib.Path_95 = function() {
	this.initialize(img.Path_95);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,4);


(lib.Path_96 = function() {
	this.initialize(img.Path_96);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.Path_16 = function() {
	this.initialize(img.Path_16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,3);


(lib.Path_20 = function() {
	this.initialize(img.Path_20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,6,6);


(lib.Mesh_6 = function() {
	this.initialize(img.Mesh_6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,62,57);


(lib.Mesh_7 = function() {
	this.initialize(img.Mesh_7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,118,118);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#0060AA","#4C2254"],[0,1],7.8,2.8,-9.9,-7.9).s().p("Ah6gpQAYADAQAPQAaAXAiAEQAiAFAbgOIAngWQAZgMATgHQgXAugyAZQgmASgvAEIgFAAQgyAAgfhYg");
	this.shape.setTransform(-1.4,39.3354);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#BDBDBD","#FFFFFF"],[0,1],11.8,7.1,-9.8,-5.9).s().p("AgCByQhFgBgGgOQgMgFgMgLQgWgXAHghQAFgXAQghQALgYgDgSQgCgNAZgMQAZgMAigEQBZgJAbA1QAGAoAAASIABAUQADAVgJAmQgLAsgSAAIhDABIgSAAg");
	this.shape_1.setTransform(-0.3359,-15.0404);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#0060AA","#4C2254"],[0,1],2.9,5.5,-2.1,-4.7).s().p("Ag0BZQgUgCAEgPQAXgmAcgnQA4hPAcgEQATAEhvClQgIAIgOAAIgFAAg");
	this.shape_2.setTransform(11.785,-23.6398);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#0060AA","#4C2254"],[0,1],4.2,4.7,-3.2,-3.9).s().p("AgvBYQANgrARgtQAihaAagLQAUgBhCC8QgGAMgSADIgHABQgMAAgBgOg");
	this.shape_3.setTransform(8.7286,-30.7939);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#0060AA","#4C2254"],[0,1],5.8,4.7,-4.4,-3.9).s().p("AgjBfQAFgsAKgwQAUheAbgOQAXgEglDEQgEAMgTAGIgLABQgLAAgDgLg");
	this.shape_4.setTransform(2.4658,-33.0193);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#0060AA","#4C2254"],[0,1],5.2,3.3,-4.5,-2.6).s().p("AgTBkQgCgtACgwQAFhgAUgTQATgHgFDHQgCANgQAJQgGADgFAAQgHAAgDgJg");
	this.shape_5.setTransform(-4.8174,-33.0662);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#0060AA","#4C2254"],[0,1],5.3,2.7,-5.5,-3.8).s().p("AAPA0QgEgQgJgQQgQgfgTAAQgagBAFgXQAEgXAhAGQA8AKAMAyQAEASgVARQgOALgGAAQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAgBg");
	this.shape_6.setTransform(-13.1267,-19.2748);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#BDBDBD","#FFFFFF"],[0,1],16.2,9.4,-17.2,-10.8).s().p("AhvDMQgSglgJgyQgEgTAWhLQAXhKgEgVQgEgaAHhMIAJhGQCageAqAnQAQAPADAbIAAAzQAAASAJBSQAJBEgHBIQgIBTg+AqQgsAeg/AFIgFAAQgnAAgbg2g");
	this.shape_7.setTransform(-0.916,18.2202);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(-18.7,-44,37.5,88), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path();
	this.instance.setTransform(258.55,-526.05,1.8284,1.8284);

	this.instance_1 = new lib.Path_1();
	this.instance_1.setTransform(-431.4,-458.75,1.8284,1.8284);

	this.instance_2 = new lib.Path_2();
	this.instance_2.setTransform(431.9,-149.95,1.8284,1.8284);

	this.instance_3 = new lib.Path_3();
	this.instance_3.setTransform(488.85,-298.4,1.8284,1.8284);

	this.instance_4 = new lib.Path_4();
	this.instance_4.setTransform(567.1,-145.95,1.8284,1.8284);

	this.instance_5 = new lib.Path_5();
	this.instance_5.setTransform(398.9,127.8,1.8284,1.8284);

	this.instance_6 = new lib.Path_6();
	this.instance_6.setTransform(-136.95,-320.2,1.8284,1.8284);

	this.instance_7 = new lib.Path_7();
	this.instance_7.setTransform(-497.05,-472.4,1.8284,1.8284);

	this.instance_8 = new lib.Path_8();
	this.instance_8.setTransform(-86.85,-302.45,1.8284,1.8284);

	this.instance_9 = new lib.Path_9();
	this.instance_9.setTransform(175.85,95,1.8284,1.8284);

	this.instance_10 = new lib.Path_10();
	this.instance_10.setTransform(286.25,-26.45,1.8284,1.8284);

	this.instance_11 = new lib.Path_11();
	this.instance_11.setTransform(462.1,-400.55,1.8284,1.8284);

	this.instance_12 = new lib.Path_12();
	this.instance_12.setTransform(414.8,-291.65,1.8284,1.8284);

	this.instance_13 = new lib.Path_13();
	this.instance_13.setTransform(842.4,-248.8,1.8284,1.8284);

	this.instance_14 = new lib.Path_14();
	this.instance_14.setTransform(481.65,14.55,1.8284,1.8284);

	this.instance_15 = new lib.Path_15();
	this.instance_15.setTransform(463.7,16.85,1.8284,1.8284);

	this.instance_16 = new lib.Path_16();
	this.instance_16.setTransform(171,-202.25,1.8284,1.8284);

	this.instance_17 = new lib.Path_17();
	this.instance_17.setTransform(390.6,-219.6,1.8284,1.8284);

	this.instance_18 = new lib.Path_18();
	this.instance_18.setTransform(940.55,-177.65,1.8284,1.8284);

	this.instance_19 = new lib.Path_19();
	this.instance_19.setTransform(356.5,-73,1.8284,1.8284);

	this.instance_20 = new lib.Path_20();
	this.instance_20.setTransform(490.05,-401.9,1.8284,1.8284);

	this.instance_21 = new lib.Path_21();
	this.instance_21.setTransform(609.9,-286.45,1.8284,1.8284);

	this.instance_22 = new lib.Path_22();
	this.instance_22.setTransform(429.6,139.55,1.8284,1.8284);

	this.instance_23 = new lib.Path_23();
	this.instance_23.setTransform(399,-483.45,1.8284,1.8284);

	this.instance_24 = new lib.Path_24();
	this.instance_24.setTransform(295.95,60.8,1.8284,1.8284);

	this.instance_25 = new lib.Path_25();
	this.instance_25.setTransform(268.65,175.25,1.8284,1.8284);

	this.instance_26 = new lib.Path_26();
	this.instance_26.setTransform(518,-242,1.8284,1.8284);

	this.instance_27 = new lib.Path_27();
	this.instance_27.setTransform(191.95,-112.4,1.8284,1.8284);

	this.instance_28 = new lib.Path_28();
	this.instance_28.setTransform(174.65,-469.95,1.8284,1.8284);

	this.instance_29 = new lib.Path_29();
	this.instance_29.setTransform(-702.05,-514.8,1.8284,1.8284);

	this.instance_30 = new lib.Path_30();
	this.instance_30.setTransform(706,-306.9,1.8284,1.8284);

	this.instance_31 = new lib.Path_31();
	this.instance_31.setTransform(643,-202.05,1.8284,1.8284);

	this.instance_32 = new lib.Path_32();
	this.instance_32.setTransform(-6.7,-400.7,1.8284,1.8284);

	this.instance_33 = new lib.Path_33();
	this.instance_33.setTransform(670.6,-321.35,1.8284,1.8284);

	this.instance_34 = new lib.Path_34();
	this.instance_34.setTransform(715.3,-257.55,1.8284,1.8284);

	this.instance_35 = new lib.Path_35();
	this.instance_35.setTransform(214.85,-465.55,1.8284,1.8284);

	this.instance_36 = new lib.Path_36();
	this.instance_36.setTransform(-590.75,-421.4,1.8284,1.8284);

	this.instance_37 = new lib.Path_37();
	this.instance_37.setTransform(-937.7,-85.6,1.8284,1.8284);

	this.instance_38 = new lib.Path_38();
	this.instance_38.setTransform(-817.65,-80.65,1.8284,1.8284);

	this.instance_39 = new lib.Path_39();
	this.instance_39.setTransform(-295.75,174.9,1.8284,1.8284);

	this.instance_40 = new lib.Path_40();
	this.instance_40.setTransform(-760.7,-229.3,1.8284,1.8284);

	this.instance_41 = new lib.Path_41();
	this.instance_41.setTransform(-682.45,-76.8,1.8284,1.8284);

	this.instance_42 = new lib.Path_42();
	this.instance_42.setTransform(-850.7,196.95,1.8284,1.8284);

	this.instance_43 = new lib.Path_43();
	this.instance_43.setTransform(-20.65,70.7,1.8284,1.8284);

	this.instance_44 = new lib.Path_44();
	this.instance_44.setTransform(-401.05,102.6,1.8284,1.8284);

	this.instance_45 = new lib.Path_45();
	this.instance_45.setTransform(-946.65,318.45,1.8284,1.8284);

	this.instance_46 = new lib.Path_46();
	this.instance_46.setTransform(-623.2,285.25,1.8284,1.8284);

	this.instance_47 = new lib.Path_47();
	this.instance_47.setTransform(-478.4,196.55,1.8284,1.8284);

	this.instance_48 = new lib.Path_48();
	this.instance_48.setTransform(-185.25,266.95,1.8284,1.8284);

	this.instance_49 = new lib.Path_49();
	this.instance_49.setTransform(-42.95,527.05,1.8284,1.8284);

	this.instance_50 = new lib.Path_50();
	this.instance_50.setTransform(-587.65,391.65,1.8284,1.8284);

	this.instance_51 = new lib.Path_51();
	this.instance_51.setTransform(-292.55,219.35,1.8284,1.8284);

	this.instance_52 = new lib.Path_52();
	this.instance_52.setTransform(-914.2,-498.1,1.8284,1.8284);

	this.instance_53 = new lib.Path_53();
	this.instance_53.setTransform(-936.45,-207.75,1.8284,1.8284);

	this.instance_54 = new lib.Path_54();
	this.instance_54.setTransform(-787.6,-331.4,1.8284,1.8284);

	this.instance_55 = new lib.Path_55();
	this.instance_55.setTransform(-834.75,-222.35,1.8284,1.8284);

	this.instance_56 = new lib.Path_56();
	this.instance_56.setTransform(-407.4,-179.55,1.8284,1.8284);

	this.instance_57 = new lib.Path_57();
	this.instance_57.setTransform(-480.95,-99.5,1.8284,1.8284);

	this.instance_58 = new lib.Path_58();
	this.instance_58.setTransform(-145,369.15,1.8284,1.8284);

	this.instance_59 = new lib.Path_59();
	this.instance_59.setTransform(-358.1,299.95,1.8284,1.8284);

	this.instance_60 = new lib.Path_60();
	this.instance_60.setTransform(-693.15,419.45,1.8284,1.8284);

	this.instance_61 = new lib.Path_61();
	this.instance_61.setTransform(9.35,468.45,1.8284,1.8284);

	this.instance_62 = new lib.Path_62();
	this.instance_62.setTransform(-491.4,-361.8,1.8284,1.8284);

	this.instance_63 = new lib.Path_63();
	this.instance_63.setTransform(-253.9,415.35,1.8284,1.8284);

	this.instance_64 = new lib.Path_64();
	this.instance_64.setTransform(-847.3,345.05,1.8284,1.8284);

	this.instance_65 = new lib.Path_65();
	this.instance_65.setTransform(-403.15,-471.95,1.8284,1.8284);

	this.instance_66 = new lib.Path_66();
	this.instance_66.setTransform(-400.7,-255.35,1.8284,1.8284);

	this.instance_67 = new lib.Path_67();
	this.instance_67.setTransform(-473.45,536.2,1.8284,1.8284);

	this.instance_68 = new lib.Path_68();
	this.instance_68.setTransform(-755.5,312.4,1.8284,1.8284);

	this.instance_69 = new lib.Path_69();
	this.instance_69.setTransform(-447.05,366.9,1.8284,1.8284);

	this.instance_70 = new lib.Path_70();
	this.instance_70.setTransform(-436.2,382.9,1.8284,1.8284);

	this.instance_71 = new lib.Path_71();
	this.instance_71.setTransform(-343.45,407.2,1.8284,1.8284);

	this.instance_72 = new lib.Path_72();
	this.instance_72.setTransform(-105.25,-129.4,1.8284,1.8284);

	this.instance_73 = new lib.Path_73();
	this.instance_73.setTransform(-859,-150.4,1.8284,1.8284);

	this.instance_74 = new lib.Path_74();
	this.instance_74.setTransform(-355.7,125.35,1.8284,1.8284);

	this.instance_75 = new lib.Path_75();
	this.instance_75.setTransform(-309.1,-108.35,1.8284,1.8284);

	this.instance_76 = new lib.Path_76();
	this.instance_76.setTransform(-893.1,-3.75,1.8284,1.8284);

	this.instance_77 = new lib.Path_77();
	this.instance_77.setTransform(-759.55,-332.8,1.8284,1.8284);

	this.instance_78 = new lib.Path_78();
	this.instance_78.setTransform(-639.7,-217.25,1.8284,1.8284);

	this.instance_79 = new lib.Path_79();
	this.instance_79.setTransform(-689.85,208.8,1.8284,1.8284);

	this.instance_80 = new lib.Path_80();
	this.instance_80.setTransform(-109.35,173.25,1.8284,1.8284);

	this.instance_81 = new lib.Path_81();
	this.instance_81.setTransform(-289.35,-371.75,1.8284,1.8284);

	this.instance_82 = new lib.Path_82();
	this.instance_82.setTransform(-949.05,430.95,1.8284,1.8284);

	this.instance_83 = new lib.Path_83();
	this.instance_83.setTransform(-529.05,-533,1.8284,1.8284);

	this.instance_84 = new lib.Path_84();
	this.instance_84.setTransform(-953.55,130,1.8284,1.8284);

	this.instance_85 = new lib.Path_85();
	this.instance_85.setTransform(-931.3,271.9,1.8284,1.8284);

	this.instance_86 = new lib.Path_86();
	this.instance_86.setTransform(-731.45,-172.8,1.8284,1.8284);

	this.instance_87 = new lib.Path_87();
	this.instance_87.setTransform(-348.8,-140.1,1.8284,1.8284);

	this.instance_88 = new lib.Path_88();
	this.instance_88.setTransform(-392.5,480.7,1.8284,1.8284);

	this.instance_89 = new lib.Path_89();
	this.instance_89.setTransform(25.9,206.35,1.8284,1.8284);

	this.instance_90 = new lib.Path_90();
	this.instance_90.setTransform(-468.45,-8.6,1.8284,1.8284);

	this.instance_91 = new lib.Path_91();
	this.instance_91.setTransform(-543.6,-237.8,1.8284,1.8284);

	this.instance_92 = new lib.Path_92();
	this.instance_92.setTransform(-606.5,-132.85,1.8284,1.8284);

	this.instance_93 = new lib.Path_93();
	this.instance_93.setTransform(-562.6,-541.9,1.8284,1.8284);

	this.instance_94 = new lib.Path_94();
	this.instance_94.setTransform(-578.95,-252.15,1.8284,1.8284);

	this.instance_95 = new lib.Path_95();
	this.instance_95.setTransform(-534.25,-188.25,1.8284,1.8284);

	this.instance_96 = new lib.Path_96();
	this.instance_96.setTransform(-93.15,-374.65,1.8284,1.8284);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_96},{t:this.instance_95},{t:this.instance_94},{t:this.instance_93},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-953.5,-541.9,1907,1083.6999999999998), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#4A469C","#4655B1","#3F72D9","#04B0ED"],[0.153,0.322,0.58,0.996],-750.2,0,750.2,0).s().p("Eh1NBFsMAAAiLYMDqaAAAMAAACLYg");
	this.shape.setTransform(-0.0043,0.0074,0.6279,1.1871);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-471,-529.5,942,1059), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah5A1QAKgKAGg8QAFg7AggbQA0grBIAQQAkAIAZARQAmAkARAqQAOAigEAdQgGA4hIAbQhEAZgugYQglgShHAPQgkAIgcALQAhg2Acgdg");
	mask.setTransform(20.71,18.1349);

	// Layer_3
	this.instance = new lib.Mesh_0_1();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(2.4,4.6,36.6,27.1), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag1CpQAUgPAUgaQg7gMhJARQglAIgZALQAXhJAqhIQgugHgnAEQAdgpArgrQBVhWBFgHQA7gGAvATQAhAOASAUQAPAHAIARQAsAvAEA4QACADAAAJIgCAqQgKAygrAjQgqAkhhAAg");
	mask.setTransform(31.65,25.9294);

	// Layer_3
	this.instance = new lib.Mesh_6();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(8.8,8.4,45.7,35.1), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhggeQgEgaABgZIADgUIADgBQBegJAsAMQAlALANAeQANAegTAhQgXAnhJA+QhKg4gPhQg");
	mask.setTransform(20.8913,40.5571);

	// Layer_3
	this.instance = new lib.Mesh_4();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(10.9,29.9,20,21.300000000000004), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ClipGroup_2_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah7glQgHghACggIADgaIAEgBQB5gPA4APQAxAMARAnQASAmgYAsQgcAzhcBSQhhhGgWhog");
	mask.setTransform(24.2299,39.1125);

	// Layer_3
	this.instance = new lib.Mesh_2_2();
	this.instance.setTransform(12.2,23.6);

	this.instance_1 = new lib.Mesh_1_0();

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_0, new cjs.Rectangle(11.3,25.4,25.900000000000002,27.5), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ClipGroup_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhggeQgEgaABgZIADgUIADgBQBegJAsAMQAlALANAeQANAegTAhQgXAohJA+QhKg5gPhQg");
	mask.setTransform(19.1413,37.2321);

	// Layer_3
	this.instance = new lib.Mesh_3_1();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-4.8,-12.6,5.6,7.5).s().p("AhggeQgEgaABgZIADgUIADgBQBegJAsAMQAlALANAeQANAegTAhQgXAohJA+QhKg5gPhQg");
	this.shape.setTransform(19.1413,37.2321);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0, new cjs.Rectangle(9.1,26.6,20.1,21.299999999999997), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlbGXQhIhliDi8IgBAAIAAgBIgBgCIAAAAQhBi0g1iYQhokuAEgbIAbgPIBBgjQBdgxAhAIQA+ALHZB0QA1AFAogCQAlgCAkgJQBHgZE6hrIBRgbICcEtIhFAyIAAABQjzCwhYA+QgcAYgXAdQgYAfgbAuIhlD8QhYDfgRAjQgMAfhdAxQgcAOgmASIgcANQgZgMi6kDg");
	mask.setTransform(123.9907,101.725);

	// Layer_3
	this.instance = new lib.Mesh_3();
	this.instance.setTransform(0,73.15);

	this.instance_1 = new lib.Mesh_1_2();
	this.instance_1.setTransform(65.4,0);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(46.9,33.9,154.2,135.7), null);


(lib.ClipGroup_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("ApFBPIPVn7IC2FfQlvDApYE5g");
	mask_1.setTransform(122.35,42.85);

	// Layer_3
	this.instance_1 = new lib.Mesh_0_2();
	this.instance_1.setTransform(0,29.95);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_1, new cjs.Rectangle(64.2,30,42.8,55.7), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhIgzIBIgmIBJCOIhIAlg");
	mask_1.setTransform(7.275,9);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAABIgCgBIACAAIAAgCIAAACIADAAIgCABIABABIgCgBIAAACg");
	this.shape.setTransform(8.9,6.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIAAgBIABABIABAAIgBABIABABIgCgBIAAABg");
	this.shape_1.setTransform(8.275,6.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIAAgBIABABIABAAIgBABIABABIgCAAIAAAAg");
	this.shape_2.setTransform(5.325,4.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIAAgCIABACIABAAIgBABIABABIgCgBIAAACg");
	this.shape_3.setTransform(6.625,3.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIAAgCIAAACIACAAIgBABIABABIgCgBIAAABg");
	this.shape_4.setTransform(6.025,3.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIAAgBIABABIABAAIgBABIABABIgCgBIAAABg");
	this.shape_5.setTransform(6.075,2.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAAAAIgBAAIABAAIAAgBIAAABIACAAIgBAAIABACIgCgBIAAABg");
	this.shape_6.setTransform(5.475,2.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAAAAIgBAAIABAAIAAgBIABABIABAAIgBAAIABACIgBgBIgBACg");
	this.shape_7.setTransform(5.525,1.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AABACIgBABIAAgDIgBAAIABAAIAAgCIABACIABAAIgBAAIABADg");
	this.shape_8.setTransform(6.175,1.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2A3560").s().p("AgjgVIAmgVIAhBBIglAUg");
	this.shape_9.setTransform(6.925,4.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CB001C").s().p("AgmhFIAFgDIBJCOIgGADg");
	this.shape_10.setTransform(10.6,7.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgmhFIAFgDIBJCOIgGADg");
	this.shape_11.setTransform(10.05,7.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CB001C").s().p("AgmhFIAFgDIBICOIgFADg");
	this.shape_12.setTransform(9.5,7.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgnhFIAGgDIBJCOIgGACg");
	this.shape_13.setTransform(8.925,8.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CB001C").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_14.setTransform(8.375,8.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_15.setTransform(7.825,8.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CB001C").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_16.setTransform(7.275,9.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgnhFIAGgCIBJCNIgGADg");
	this.shape_17.setTransform(6.725,9.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CB001C").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_18.setTransform(6.175,9.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_19.setTransform(5.625,9.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CB001C").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_20.setTransform(5.05,10.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_21.setTransform(4.5,10.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CB001C").s().p("AgnhFIAGgDIBJCOIgGADg");
	this.shape_22.setTransform(3.95,10.725);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,14.6,18), null);


(lib.Path_97 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-3.5,0,3.6,-0.3).s().p("AgGgPQgEhPgZg4QBCAxAEBdQADAzgNAlQgQArglAcQAag/gEhng");
	this.shape.setTransform(3.5702,15.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_97, new cjs.Rectangle(0,0,7.2,30.3), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-3.6,0.3,3.6,0).s().p("AgUAdQgQghgCg0QgBgSACgQIAPAAIAegDIABAjQADBdAbA6QgngYgUgog");
	this.shape.setTransform(3.9107,20.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-3,0.1,3.1,-0.1).s().p("AAdglQgNAhgGApIgmABQAQgsApgfg");
	this.shape_1.setTransform(4.025,3.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,7.9,30.3), null);


(lib.ClipGroup_4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AivA7QhKgWgEglQgEgsASgJQAPgHAnANIBTAeQA4ARAsgCQAsgCA2gWQAfgNAzgYQAngSARAGQAUAIAAAuQAAAjhIAdQhJAdhpAFIgjAAQhSAAg+gSg");
	mask_1.setTransform(33.156,18.793);

	// Layer_3
	this.instance_1 = new lib.Mesh_5();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_1, new cjs.Rectangle(7.7,11.1,50.9,15.500000000000002), null);


(lib.ClipGroup_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjGE3Qg1gMACgxQACgpAyiEQBUi0BZhkQAsgzAcgOQA2gqA1gDQBKgEASBZQAQBTg0ArIgxAiQgfAUgPATQgDAjgUAbQgLAQgkAfQhPBHgkBZQgQA1gvAPQgSAGgTAAQgOAAgPgDg");
	mask.setTransform(25.0937,50.0271);

	// Layer_3
	this.instance = new lib.Mesh_4_1();
	this.instance.setTransform(27.7,0);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_1, new cjs.Rectangle(27.7,18.7,22.500000000000004,24.3), null);


(lib.ClipGroup_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AAqG2QgIgDgEgIIgNgfIgCgDIgqhnIgBgEIgOgkQgCgGACgGQACgGAFgEQgahKgNhKQgaiLASiFQAJhHAWhEQgKgKAFgMIAahIQADgIAIgEQAHgDAJADIATAHQAIADADAIQAEAIgDAIIgaBHQgEAOgPAAQgVBBgIBDQgZDABGDRQANAAAEANIAPAoIABACIAnBdIARAnQAEAIgEAIQgDAHgIAEIgTAJQgEACgEAAQgEAAgEgCg");
	mask.setTransform(43.3564,43.9183);

	// Layer_3
	this.instance = new lib.Mesh_3_2();
	this.instance.setTransform(0,18);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_1, new cjs.Rectangle(34.4,18,14.600000000000001,33), null);


(lib.ClipGroup_1_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ag5G1IgUgIQgIgEgDgHQgDgIAEgIIAQgmIABgBIA2iHQAFgMANAAQBFjQgYjCQgJhGgUg+QgPAAgEgNIgahIQgDgIADgIQAEgIAIgDIATgHQAIgDAIADQAIAEADAIIAaBHQAFAOgKAJQAVA+AKBNQASCEgaCMQgOBJgZBLQALAIgFAOIg5CQIgBACIgOAfQgDAIgIADIgHABQgFAAgEgCg");
	mask_1.setTransform(8.9828,43.95);

	// Layer_3
	this.instance_1 = new lib.Mesh_2_1();
	this.instance_1.setTransform(6.7,18.05);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0_1, new cjs.Rectangle(6.7,18.1,11.3,33), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AlAGHQgOAAgKgKQgKgKAAgNQBIlNhImRQAAgOAKgJQAKgKAOAAQFQhCEyBCQANAAAKAKQAKAJAAAOQhCGSBCFMQAAANgKAKQgKAKgNAAQihA0ihAAQigAAigg0g");
	mask_1.setTransform(35.475,47.3375);

	// Layer_3
	this.instance_2 = new lib.Mesh_0();
	this.instance_2.setTransform(3.95,0);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(4,3,65,88.7), null);


(lib.ClipGroup_0_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AlAGHQgOAAgKgKQgKgKAAgNQBIlNhImRQAAgOAKgJQAKgKAOAAQFQhCEyBCQANAAAKAKQAKAJAAAOQhCGSBCFMQAAANgKAKQgKAKgNAAQihA0ihAAQigAAigg0g");
	mask_2.setTransform(36.925,46.3875);

	// Layer_3
	this.instance_2 = new lib.Mesh_1_1();

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_2, new cjs.Rectangle(1.5,2.1,70.9,45.9), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Ag5CtQgchChJgtQhKgvhigMQgOghAAgiQAAgTAEgPQgBgFAAgFIANhIQARAKAXAMQAogSBTgCQAxgBB0ABIChgBQBQACAoAQIAwgWIANBLQAAAFgBAFQAEAPAAATQAAAigOAhQhiAMhKAvQhJAtgcBCQgXAMgjAAQghAAgYgMg");
	mask_2.setTransform(36.925,33.8);

	// Layer_3
	this.instance_1 = new lib.Mesh_2();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(2.5,15.4,68.9,15.6), null);


(lib.Path_98 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#83C5E9","#82C3E9","#7DBCEB","#75B1ED","#6AA0F0","#5B8AF5","#486FFA","#3654FF"],[0,0.439,0.596,0.71,0.8,0.878,0.945,1],0,0,0,0,0,59).s().p("AmZGnQiwiqgEj0QgEjzCqivQCrivD0gEQDzgECwCqQCvCqAED0QAEDyiqCwQirCvj0AEIgKAAQjtAAirimg");
	this.shape_1.setTransform(58.975,58.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_98, new cjs.Rectangle(0,0,118,117.8), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA8ADB").s().p("AExAmQgigXgSgHQgYgKgaABQggAAgqAKQgaAHg1ASQg7AUgdAHQgzANgqABQhQABh6gxQgfgMgXgLQA7glBBgYQBUAfAugBQAcAAAngLQAYgGAxgRIBCgVQA3ALAuAQQBzAsBdBYIAGAGQgfgMg0ghg");
	this.shape.setTransform(66.675,8.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA8ADB").s().p("AjgAjQhhgrhNhLIgEgEIAZAEQA/AMAwAeQAcASAlAiQATATAIAFQAJAGAJABQALAAARgKIAigXQAwghAggOQA3gZA8ACQA9ACAtAUQAaALAeAZIARALQAEADAGgBQALAAA7gZIArgSQhgBIh0AfQgRgOgRgGQgYgJgjAAQgkgCgiAOQgWALghAYQhngKhegrg");
	this.shape_1.setTransform(58.675,113);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#613D99").s().p("AhVB8QhOgChBgeQgngRg5gpQgngdgUgIQgegPghAAQgqAAgvASQgVgtgPgzQBAgZA9AAQA2AAAyAXQAeAOAwAjQAwAjAdANQAvAVA5ABQA1ABAogUQAZgMAtgkQAzgqAggPQA4gZBBAHQBAAIAvAfQAbASAjAmQAbAcANAIQAWAMAjgBIASgBQgcA1glAvQgrgHghgZQgVgOgdggQgagdgRgLQgagQgogFQglgEgfAPQgUAIgnAhQg2ArgjARQg7AfhKAAg");
	this.shape_2.setTransform(59.475,86.7898);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA8ADB").s().p("AE4CPQhWAAg9glQgZgPgYgWQgMgMgagcQghglgSgMQgbgTgqAAQhKgBhFAjQgpAUhDA1Qg4AsgeAQQguAYhSgQQgugJg9gWQgEg3AEg2IAOAEQBXAiAzAFQAaADAKgFQAYgNAtgjQBNg9A1gaQBZgtBhABQBGABA1AjQAfATAqAxQAmAqAZAOQAnAXA+gBQA9gBAtgXQAcgPAugnQAdgYARgMQAbgUAbgMQANA0AFA2QgQAJgjAeQg4AwgmAUQhDAihUACg");
	this.shape_3.setTransform(61.7125,55.2239);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#613D99").s().p("ABqBZQiRgMhzgnQixg7jYA5IgLADQAhhAAwg6QA4gJA3gBQCEgEB1AoQC3A9ECgOQBigGBUgPQAeAqAXAzIgIACQhZAShpAIQhAAEg9AAQhBAAg9gFg");
	this.shape_4.setTransform(62.375,28.8507);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,123.4,121.8), null);


(lib.Path_23_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-0.4,-0.5,0,-0.4,-0.5,23.2).s().p("AjoDJQgPgRA3hKQA7hPBchPQBbhPBYguQBSgrAOAQQAOAQg7BGQg7BGhhBSQhfBThPAwQg6AkgXAAQgHAAgDgEg");
	this.shape.setTransform(23.5994,20.4712);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_23_1, new cjs.Rectangle(0,0,47.3,41), null);


(lib.Path_22_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],0.4,0.4,0,0.4,0.4,18.7).s().p("AjBCaQgLgNAyg3QAxg2BRg/QBQhABAgjQBAgkAKANQALAOguA6QgyA+hNA8QhLA8hIAjQgvAWgUAAQgIAAgDgEg");
	this.shape.setTransform(19.6383,15.7906);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_22_1, new cjs.Rectangle(0,0,39.3,31.6), null);


(lib.Path_21_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-0.1,-11.9,0,-0.1,-11.9,26.6).s().p("AgMAcQgUgKgKgOQgLgOAFgLQAGgMASgBQASgCATAJQAUAKAKAOQALAOgGALQgEAMgTABIgFAAQgPAAgRgHg");
	this.shape.setTransform(5.05,3.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_21_1, new cjs.Rectangle(0,0,10.1,7.1), null);


(lib.Path_20_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],28.7,-56.3,0,28.7,-56.3,101.7).s().p("AAKAqQgQgFgPgQQgPgQgFgRQgEgSAJgIQAKgJARAGQAQAFAPAQQAPAQAFARQAEASgJAIQgGAFgJAAQgFAAgHgCg");
	this.shape.setTransform(4.275,4.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_20_1, new cjs.Rectangle(0,0,8.6,8.9), null);


(lib.Path_19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],9.1,-10.5,0,9.1,-10.5,18.3).s().p("AABA9QgUgTgNgeQgMgZgCgaQgCgaAJgQQATABAUAUQAUASANAeQAMAaACAaQACAZgIARQgUgBgUgUg");
	this.shape.setTransform(4.7328,8.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19_1, new cjs.Rectangle(0,0,9.5,16.4), null);


(lib.Path_18_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],0.4,-15.2,0,0.4,-15.2,23).s().p("AAxA6QgjgGgigVQgggSgWgWQgWgYgFgUQAUgLAiAHQAiAGAjAUQAgATAVAXQAVAXAGAVQgMAGgRAAQgLAAgNgDg");
	this.shape.setTransform(10.15,6.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18_1, new cjs.Rectangle(0,0,20.3,12.1), null);


(lib.Path_17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-13.4,-11.7,0,-13.4,-11.7,23.1).s().p("AhmA0QABgZAYgaQAYgaAlgRQAhgPAhgDQAggCAVALQgBAZgYAaQgYAaglARQghAPghADIgJAAQgaAAgSgJg");
	this.shape.setTransform(10.325,6.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_17_1, new cjs.Rectangle(0,0,20.7,12.2), null);


(lib.Path_16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-14.8,3.9,0,-14.8,3.9,23).s().p("AgqA+QgDgiAKgnQAJgkARgbQAQgbASgKQAPAPADAiQADAjgKAnQgJAkgRAbQgPAbgTAKQgPgQgDgig");
	this.shape.setTransform(4.3892,11.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16_1, new cjs.Rectangle(0,0,8.8,22.5), null);


(lib.Path_15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],13.7,-11.9,0,13.7,-11.9,27.2).s().p("AgMBZQgVgjgKgvQgKgqADgmQADglAPgVQAYAJAUAiQAWAjALAvQAJAqgEAmQgDAlgOAVQgYgIgVgjg");
	this.shape.setTransform(5.15,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15_1, new cjs.Rectangle(0,0,10.3,26.4), null);


(lib.Path_14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],2.2,17.5,0,2.2,17.5,26.6).s().p("ABBA6QgogBgrgRQgogQgdgXQgcgWgKgXQAVgPAoACQAoABArARQAoAQAdAXQAcAWAKAXQgTANgiAAIgIAAg");
	this.shape.setTransform(12.55,5.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14_1, new cjs.Rectangle(0,0.1,25.1,11.6), null);


(lib.Path_13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],9.9,14.5,0,9.9,14.5,26.6).s().p("AhNAoQgkgHgSgQQAMgVAjgRQAlgRAvgFQAqgEAkAHQAkAHASARQgMAVgjARQglARgvAFIgcABQgaAAgYgFg");
	this.shape.setTransform(13.225,4.5102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13_1, new cjs.Rectangle(0,0,26.5,9.1), null);


(lib.Path_12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],4.3,-24.7,0,4.3,-24.7,37.8).s().p("ABBBqQg2gSg0gqQgwglgegrQgdgrgDgjQAigLA1ASQA2ASA0AqQAwAlAeArQAdArADAjQgNAEgQAAQgaAAgggLg");
	this.shape.setTransform(15.2,11.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12_1, new cjs.Rectangle(0,0,30.4,23.5), null);


(lib.Path_11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-42.5,36.7,0,-42.5,36.7,72.4).s().p("AggDzQhHhWglh8QghhuAIhnQAHhlAsg9QBNAPBFBVQBJBWAkB8QAhBugIBnQgIBlgrA9QhNgQhGhUg");
	this.shape.setTransform(16.75,34.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11_1, new cjs.Rectangle(0,0,33.5,68.7), null);


(lib.Path_10_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-21.4,-63.5,0,-21.4,-63.5,102.3).s().p("AgyAzQgdgHgFgUQgFgUAVgUQAVgVAjgKQAjgKAcAHQAdAHAFAUQAGAUgVAUQgVAWgkAJQgTAGgSAAQgNAAgNgDg");
	this.shape.setTransform(8.634,5.3872);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_0, new cjs.Rectangle(0,0,17.3,10.8), null);


(lib.Path_10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-72.4,-8.7,0,-72.4,-8.7,109.1).s().p("AiLFfQidgOhdhpQgwiEA/iPQA/iSCThYQCThWCdANQCdAOBdBoQAwCFg/CPQhACSiSBXQh/BMiGAAQgVAAgWgCg");
	this.shape.setTransform(41.0127,35.2745);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_1, new cjs.Rectangle(-0.1,0,82.19999999999999,70.6), null);


(lib.Path_9_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-54,-32.5,0,-54,-32.5,102.3).s().p("AgpAhQgIgJAHgRQAHgQARgOQARgOARgDQASgCAIAJQAIAKgHARQgGAPgSAOQgSAOgQADIgIABQgMAAgGgIg");
	this.shape.setTransform(4.6,4.1086);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_0, new cjs.Rectangle(0,0,9.3,8.2), null);


(lib.Path_9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],60.5,50.3,0,60.5,50.3,85.9).s().p("AiMGQQitgchSiJQhRiJA7ikQA6imCkhhQCkhhCsAcQCtAbBRCJQBRCJg6CkQg6CmikBhQh/BMiFAAQglAAgngGg");
	this.shape.setTransform(44.1585,40.5401);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_1, new cjs.Rectangle(-0.1,0,88.5,81.1), null);


(lib.Path_8_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],37,-1.3,0,37,-1.3,55.9).s().p("AgUAiQgHgPAAgTQABgUAJgOQAIgOAKABQAMAAAHAOQAIAOgBATQAAAUgJAOQgIAOgLAAQgLAAgIgOg");
	this.shape.setTransform(2.754,4.8241);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_0, new cjs.Rectangle(0,0,5.5,9.7), null);


(lib.Path_8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],21.7,37.1,0,21.7,37.1,64.7).s().p("AhHCyQheglgyhQQgxhNAQhSQAuhGBagXQBbgXBdAlQBdAlAyBQQAyBNgQBSQguBGhaAXQgjAJgjAAQg4AAg6gXg");
	this.shape.setTransform(25.2828,20.0464);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_1, new cjs.Rectangle(0,0,50.6,40.1), null);


(lib.Path_7_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],47.3,-25.9,0,47.3,-25.9,81.2).s().p("AgEA5QgSgOgNgaQgNgZADgXQABgYAPgIQAPgGASANQAUANAMAbQAMAagBAXQgCAYgPAGQgFADgGAAQgLAAgMgJg");
	this.shape.setTransform(4.7,6.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_0, new cjs.Rectangle(0,0,9.4,13.2), null);


(lib.Path_7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FD057A","#F61381","#EA2B8D","#DB4C9E","#CB6DAF"],[0,0.153,0.333,0.529,0.729,0.898],2.1,-46.5,0,2.1,-46.5,50.6).s().p("AhVDTQhogpgxhcQgwhaAjhYQAkhXBjggQBjghBnApQBoAqAxBcQAwBagjBYQgkBXhiAhQgsAOgtAAQg3AAg7gYg");
	this.shape.setTransform(26.625,23.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_1, new cjs.Rectangle(0,-0.1,53.3,47), null);


(lib.Path_6_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],47.3,-25.9,0,47.3,-25.9,81.2).s().p("AgEA5QgSgOgNgaQgNgZADgYQABgYAPgGQAPgHASANQAUAOAMAaQAMAZgBAYQgCAYgPAGQgFADgGAAQgLAAgMgJg");
	this.shape.setTransform(4.7,6.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_0, new cjs.Rectangle(0,0,9.4,13.2), null);


(lib.Path_6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-6,-33.2,0,-6,-33.2,52).s().p("AAgCsQhLgIg8g1Qg8g1gQhHQgPhHAjg4QA2gnBKAIQBLAIA8A1QA8A1AQBHQAPBHgjA4QgsAhg7AAIgZgCg");
	this.shape.setTransform(18.4,17.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_1, new cjs.Rectangle(0,0,36.9,34.8), null);


(lib.Path_5_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],35.2,-1.2,0,35.2,-1.2,53.3).s().p("AgBAuQgLAAgHgOQgHgOABgSQAAgTAIgNQAIgOAKABQALABAHANQAIANgBATQgBASgIAOQgHANgKAAIgBAAg");
	this.shape.setTransform(2.6042,4.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_0, new cjs.Rectangle(0,0,5.2,9.2), null);


(lib.Path_5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-14.6,33.8,0,-14.6,33.8,40.2).s().p("AAbDDQhTgDhDg7QhDg7gLhQQgLhRAzg3QAzg3BUAEQBTADBDA7QBDA7ALBPQALBRgzA3QgxA0hNAAIgJAAg");
	this.shape.setTransform(20.375,19.4973);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_1, new cjs.Rectangle(0,0.1,40.8,38.9), null);


(lib.Path_4_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],0.2,-20.2,0,0.2,-20.2,44.7).s().p("Ag2AuQgcgKgEgUQgDgTAWgTQAXgTAkgHQAjgHAcAKQAcAJAEAUQAEAUgXATQgXATgkAHQgOADgNAAQgTAAgRgGg");
	this.shape.setTransform(8.7311,5.2121);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_0, new cjs.Rectangle(0,0.1,17.5,10.3), null);


(lib.Path_4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],12.3,27.8,0,12.3,27.8,46.1).s().p("AgLBLQhKgGg7gYQg7gYgaggQAbgiBCgSQBDgRBRAGQBKAGA8AYQA6AYAaAgQgaAihCASQgxANg5AAQgWAAgVgCg");
	this.shape.setTransform(23.025,7.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_1, new cjs.Rectangle(0,0,46.1,15.4), null);


(lib.Path_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-17.8,-25.3,0,-17.8,-25.3,68.8).s().p("AheBhQgXgWAMgsQAMgrAngoQAngoArgNQAsgNAWAWQAXAWgLAsQgMArgnAoQgnAogrANQgQAFgOAAQgWAAgPgOg");
	this.shape.setTransform(10.961,11.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_0, new cjs.Rectangle(0,0,22,22.2), null);


(lib.Path_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],41.8,-6.7,0,41.8,-6.7,63.7).s().p("AiGChQAAhgAnhqQAjhhA1hGQA0hGA2gYQAkAwAABeQAABggnBqQgjBgg2BHQgzBGg3AYQgkgwABheg");
	this.shape.setTransform(13.5247,30.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_1, new cjs.Rectangle(0,0,27.1,60.6), null);


(lib.Path_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-21.4,-14,0,-21.4,-14,43.5).s().p("AgjBJQgYgLgGgdQgHgeAPgeQAPgeAbgOQAagNAYALQAYAMAHAdQAGAegOAdQgPAfgbANQgPAIgNAAQgLAAgMgGg");
	this.shape.setTransform(6.7523,7.8624);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_1, new cjs.Rectangle(0,0,13.6,15.8), null);


(lib.Path_2_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],46.5,-48.8,0,46.5,-48.8,101.7).s().p("AAQBFQgbgJgZgaQgYgbgHgcQgHgcAPgOQAPgOAcAIQAcAJAZAbQAZAaAGAcQAHAdgPAOQgJAJgPAAQgJAAgLgEg");
	this.shape.setTransform(7.0725,7.2618);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_0, new cjs.Rectangle(0.1,0,14,14.6), null);


(lib.Path_2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-15.1,-41.2,0,-15.1,-41.2,66.5).s().p("AgXBrQhqgPhUgoQhRgogkgxQAqgvBhgTQBjgUB0ARQBqAPBUAoQBRAnAkAyQgqAvhhATQg1ALg6AAQgzAAg1gIg");
	this.shape.setTransform(33.075,11.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_2, new cjs.Rectangle(0,0,66.2,23), null);


(lib.Path_1_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],0,-12.3,0,0,-12.3,27.2).s().p("AggAdQgRgGgDgMQgCgLAOgNQAOgLAVgFQAVgEARAFQASAGACAMQACALgNANQgOALgWAFQgIACgJAAQgLAAgKgDg");
	this.shape.setTransform(5.2756,3.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_12, new cjs.Rectangle(0,0,10.6,6.3), null);


(lib.Path_1_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],28.7,-56.3,0,28.7,-56.3,101.7).s().p("AAKAqQgQgFgPgQQgPgQgEgRQgFgSAJgIQAJgJASAGQAQAFAPAQQAQAQAEARQAEASgKAIQgFAFgJAAQgGAAgGgCg");
	this.shape.setTransform(4.3,4.4096);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_11, new cjs.Rectangle(0,0,8.6,8.9), null);


(lib.Path_1_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],7.4,-9.4,0,7.4,-9.4,18.3).s().p("AgGBPQgbgTgQglQgRgkADghQADggAVgKQAUgKAaAUQAaATARAlQARAkgDAhQgDAhgVAJQgGADgIAAQgPAAgRgNg");
	this.shape.setTransform(6.4006,9.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_10, new cjs.Rectangle(0,0,12.9,18.4), null);


(lib.Path_1_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-0.4,-13.3,0,-0.4,-13.3,23).s().p("AA2BPQgogDgrgZQgsgagXgfQgWghAMgVQAMgVAoADQAoADArAZQAsAaAXAgQAXAggMAVQgLATggAAIgKgBg");
	this.shape.setTransform(11.0605,7.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_9, new cjs.Rectangle(0,0,22.2,16), null);


(lib.Path_1_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-12.1,-9.6,0,-12.1,-9.6,23.1).s().p("Ag6BTQgpgEgNgcQgMgbAZggQAYgiAugWQAugWAqAFQApAEAMAaQANAbgZAiQgYAhguAWQgnASgjAAIgOAAg");
	this.shape.setTransform(11.6139,8.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_8, new cjs.Rectangle(0,0,23.3,16.6), null);


(lib.Path_1_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FA0379","#EC0A80","#D4178A","#B32999","#8840AC","#8144AF"],[0,0.141,0.306,0.486,0.675,0.867,0.898],-12.7,4.1,0,-12.7,4.1,23).s().p("AgeB4QgXgGgIgnQgIgnANgxQANgyAZgeQAZgfAXAGQAYAFAIAoQAHAngMAwQgNAygaAfQgUAZgUAAIgIAAg");
	this.shape.setTransform(6.4595,12.0434);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_7, new cjs.Rectangle(0,0,13,24.1), null);


(lib.Path_1_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],11.3,-11.1,0,11.3,-11.1,27.2).s().p("AgZBvQgdglgNg7QgNg6ALguQALguAcgHQAcgGAcAmQAdAlANA7QANA6gLAuQgLAugcAHIgIAAQgXAAgZggg");
	this.shape.setTransform(7.4925,14.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_6, new cjs.Rectangle(0,0,15,28.7), null);


(lib.Path_1_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],2.8,15.2,0,2.8,15.2,26.6).s().p("AgYA/Qg3gVgggiQgfghAKgaQALgaAugDQAvgEA2AWQA3AWAfAhQAfAhgKAaQgKAbguADIgNAAQgqAAgugTg");
	this.shape.setTransform(13.55,8.1995);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_5, new cjs.Rectangle(0,0,27.1,16.4), null);


(lib.Path_1_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],9.4,12.1,0,9.4,12.1,26.6).s().p("AhfA5QgrgPgDgcQgDgaAogYQAogYA7gGQA5gGAsAPQArAQADAbQADAbgoAYQgoAYg7AGIgdACQgoAAgggMg");
	this.shape.setTransform(14.247,6.8633);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_4, new cjs.Rectangle(0.1,0,28.4,13.8), null);


(lib.Path_1_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FD057A","#F61381","#EA2B8D","#DB4C9E","#CB6DAF"],[0,0.153,0.333,0.529,0.729,0.898],2.5,-21.8,0,2.5,-21.8,37.8).s().p("ABGCOQhBgOhBg0QhCg0gcg6Qgdg7AZggQAZgfBAAOQBAAQBBA0QBCAzAdA6QAdA7gZAfQgRAWgkAAQgQAAgUgFg");
	this.shape.setTransform(17.05,14.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_3, new cjs.Rectangle(0,0,34.1,29.4), null);


(lib.Path_1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-35.1,33.7,0,-35.1,33.7,72.4).s().p("AhJE0QhfhagtiaQguiZAeh/QAfiBBZgaQBZgbBeBbQBfBaAuCaQAtCZgfB/QgeCBhZAaQgUAGgVAAQhFAAhJhGg");
	this.shape.setTransform(24.15,37.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_2, new cjs.Rectangle(0,0,48.3,75.6), null);


(lib.Path_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],12.1,23.7,0,12.1,23.7,46.1).s().p("AgJB0QhmgHhFgpQhFgoAEgvQAEgwBLgdQBLgcBlAIQBmAJBFAoQBFAngEAwQgEAwhLAdQg6AVhKAAQgWAAgWgCg");
	this.shape.setTransform(24.625,11.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_1, new cjs.Rectangle(0,0,49.3,23.7), null);


(lib.Path_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],36.1,-7.9,0,36.1,-7.9,63.7).s().p("AhzFBQg/gWgLhuQgLhuAwiEQAwiFBPhPQBOhOA/AXQA/AWALBuQALBugwCEQgwCFhPBOQg8A9g1AAQgOAAgOgFg");
	this.shape.setTransform(19.175,32.5651);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_0, new cjs.Rectangle(0,0,38.4,65.2), null);


(lib.Path_1_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FF0077","#FD057A","#F61381","#EA2B8D","#DB4C9E","#CB6DAF"],[0,0.153,0.333,0.529,0.729,0.898],-15.3,-35.2,0,-15.3,-35.2,66.5).s().p("AgZCnQiSgVhghAQhghAALhEQALhFBugiQBvgiCSAVQCRAVBhBAQBfBAgKBEQgKBGhvAiQhFAUhRAAQgzAAg4gIg");
	this.shape.setTransform(35.4,17.4905);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_13, new cjs.Rectangle(0,0,70.8,35.1), null);


(lib.Path_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],-1.4,0.6,0,-1.4,0.6,16).s().p("AAUCeQgig+gZhTQgahSgFhGQgEhCAPgFQAKgDALBAQAPBiARA2QAQA3AqBaQAbA8gKADIgCAAQgQAAgfg1g");
	this.shape.setTransform(7.1595,21.1097);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0, new cjs.Rectangle(0,0,14.3,42.3), null);


(lib.Path_99 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#1FC8AB","#23C3AB","#2DB5AC","#3F9DAC","#587CAD","#7751AF","#8144AF"],[0,0.137,0.298,0.475,0.655,0.843,0.898],2.1,-1.4,0,2.1,-1.4,22.2).s().p("ABzC2Qg8h8gshCQgrhChbhoQg8hEANgIQASgMBDA/QBHBEBCBlQBDBjAiBdQAgBWgTAMIgCABQgNAAgkhLg");
	this.shape_2.setTransform(17.4677,25.608);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_99, new cjs.Rectangle(0.2,0,34.599999999999994,51.3), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FBD368").s().p("AAABYQgggRguAAIgnAEQAKgGAahEQAahAAngUQArgWAlAYQASAMAKAQQAyBIgxAwQgTATgbAGQgKACgJAAQgPAAgNgGg");
	this.shape.setTransform(4.3626,-1.5795);

	this.instance = new lib.ClipGroup_0();
	this.instance.setTransform(3.35,2,1,1,0,0,0,22.5,21.5);
	this.instance.compositeOperation = "multiply";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F1B879").s().p("Ah5A1QAKgKAGg8QAFg7AggbQA0grBIAQQAkAIAZARQAmAkARAqQAOAigEAdQgGA4hIAbQhEAZgugYQglgShHAPQgkAIgcALQAhg2Acgdg");
	this.shape_1.setTransform(1.56,-1.3651);

	this.instance_1 = new lib.ClipGroup();
	this.instance_1.setTransform(-0.65,2.55,1,1,0,0,0,31,28.5);
	this.instance_1.compositeOperation = "multiply";

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC4E32").s().p("Ag1CpQAUgPAUgaQg7gMhJARQglAIgZALQAXhJAqhIQgugHgnAEQAdgpArgrQBVhWBFgHQA7gGAvATQAhAOASAUQAPAHAIARQAsAvAEA4QACADAAAJIgCAqQgKAygrAjQgqAkhhAAg");
	this.shape_2.setTransform(0,-0.0206);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.instance_1},{t:this.shape_1},{t:this.instance},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol16, new cjs.Rectangle(-31.6,-25.9,62,57), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#9E9E9E","#454545"],[0,1],-0.3,-0.2,0.2,0.7).s().p("AkmCaQAAgCEkiYIEkiZIAFAKQpHEpgGAAIAAAAg");
	this.shape.setTransform(-70.475,13.0257);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-2.1,-1.4,0.8,4.3).s().p("AksClQgFgKEgihQCPhQCRhPIAeA5QiUBJiWBFQkVCEgYAAIgCgBg");
	this.shape_1.setTransform(-69.8301,11.8613);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#A6A6A6","#B3B3B3","#CDCDCD","#D6D6D6","#BABCBE"],[0,0.11,0.353,0.498,0.996],3.7,10.4,-7.7,-11.7).s().p("AjECoIBkg0IgqhOQgrhPAAgGQgCgSCchNQCahNAGAJQAgAqAQAkQAiBPgnAmQgwAvhEAwQhGAzg3AZQgvAWgjATQgSAKgIAFg");
	this.shape_2.setTransform(-53.1653,23.1779);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#A1A1A1"],[0,1],-5.1,-11,6.3,11.1).s().p("Ag0CbQgHgGhPieIhkAzIgXgrQAlgOBIgqQA1geBSgdQBPgbBBgMQA2gJAsBJQAVAiAQAyQADAKiYBRQiGBJgaAAQgEAAgBgCg");
	this.shape_3.setTransform(-69.8211,-4.4844);

	this.instance = new lib.ClipGroup_4();
	this.instance.setTransform(-69.6,-2.55,1,1,0,0,0,35.5,31);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.ClipGroup_1_0();
	this.instance_1.setTransform(-56.75,25.45,1,1,0,0,0,35.5,31);
	this.instance_1.compositeOperation = "multiply";

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-3.8,-12.6,5,8.2).s().p("AhggeQgEgaABgZIADgUIADgBQBegJAsAMQAlALANAeQANAegTAhQgXAohJA+QhKg5gPhQg");
	this.shape_4.setTransform(-73.1087,31.6821);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-3.8,-12.6,5,8.2).s().p("AhggeQgEgaABgZIADgUIADgBQBegJAsAMQAlALANAeQANAegTAhQgXAnhJA+QhKg4gPhQg");
	this.shape_5.setTransform(-84.2087,7.0071);

	this.instance_2 = new lib.ClipGroup_2_0();
	this.instance_2.setTransform(-78.05,18.15,1,1,0,0,0,28.6,35.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-5.1,-16.1,6.8,10.5).s().p("Ah7glQgHggACghIADgZIADgCQB6gPA4APQAwAMASAnQARAngYArQgcA0hcBSQhhhHgVhog");
	this.shape_6.setTransform(-82.3951,21.9375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-0.1,-0.3,0.2,0.4).s().p("AnfD2IO8nxIADAGIu8Hxg");
	this.shape_7.setTransform(-6.975,-20.15);

	this.instance_3 = new lib.ClipGroup_3();
	this.instance_3.setTransform(-54.95,-45.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-1,-2.1,1.1,2.1).s().p("AgigIIAvgYIAWApIgvAYg");
	this.shape_8.setTransform(52.325,-46.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-1,-2.1,1.1,2.1).s().p("AgigIIAvgYIAWApIgvAYg");
	this.shape_9.setTransform(49.075,-52.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-3.8,-14.6,9.3,10.9).s().p("AAbB2QAFgaAYgMIAFAHQgGgZALgbQgLAEgBgCQgGgFgXgwQgbgyAAgFQgBgCAJgIQgcgGgRgSIADAHQgYAMgYgKIgTgMIA0geIAIASIAPgUIA6ApIAJgEIA4A0IAJBJIgJADIgBBJIgYACQAGAIAEAIIg3AZQgBgKADgNg");
	this.shape_10.setTransform(64.85,-56.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-0.2,-0.5,0.3,0.6).s().p("AgYANQgBgCAHgGIAQgJQAYgNADAFQABADgHAFQgGAFgKAFQgJAFgIACIgGABQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAg");
	this.shape_11.setTransform(96,-70.4373);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-0.2,-0.5,0.3,0.6).s().p("AgYANQgBgCAHgGQAGgFAKgFQAJgFAIgCQAIgCABACQAEAFgZAMQgQAJgHAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAg");
	this.shape_12.setTransform(95.1648,-72.0161);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-0.2,-0.5,0.3,0.6).s().p("AgYANQgBgDAGgFQAHgFAKgFQAJgFAIgCQAIgCABACQADAGgZALQgQAJgGAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAg");
	this.shape_13.setTransform(94.3544,-73.6161);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-3,-9.1,5.2,6.8).s().p("AAQA5QgGgDgIgIQgQgQgNgaQgOgZgBgSIACgOIgOgaQAvAGAPAHQAWAKASAZIAGAcQABAlgbAug");
	this.shape_14.setTransform(94.4505,-70.975);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-9.6,-17.5,8.8,18).s().p("AgNACQgjhBgag+QgTgvAAgDIAFgDIAtBrQA7CABOB4IgFACQg6hZgshYg");
	this.shape_15.setTransform(-46.775,1.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-9.6,-17.4,8.7,18).s().p("AgOACQgihAgag/IgTgyIAFgCIAsBqQA7CABPB3IgFACQg4hTgvhdg");
	this.shape_16.setTransform(-18.275,-13.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-9.5,-17.3,8.7,17.9).s().p("AgOACQgihBgZg9QgUguAAgEIAFgDIAtBqQA6CABPB2IgFADQg5hVguhbg");
	this.shape_17.setTransform(11.975,-29.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-6.8,-14.4,7.8,13.8).s().p("AgihMIgohAIAHgBIATAcQAZApAhBBQAWArALAVQANAdATAzIgEAEQg3iBgyhYg");
	this.shape_18.setTransform(81.35,-65.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-9.5,-17.3,8.6,17.8).s().p("AgNACQgihAgag+IgTgxIAFgDIAsBqQA6B/BOB1IgFADQg3hTguhcg");
	this.shape_19.setTransform(42.175,-44.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-4.9,-23.5,13.5,12.1).s().p("As7CnITgqFIBegZQBugWBNAQQA7AHAQAGQAZAJAUAcIAGAgQgBArglA2QguBDgvA0QgzA3glAXQg0AfykJrg");
	this.shape_20.setTransform(17.125,-28.1368);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-0.1,-0.3,0.2,0.3).s().p("Am9DlIN4nNIADAFIt5HMg");
	this.shape_21.setTransform(-3.725,-21.575);

	this.instance_4 = new lib.ClipGroup_2();
	this.instance_4.setTransform(-48.3,-44.65);

	this.instance_5 = new lib.ClipGroup_0_1();
	this.instance_5.setTransform(-45.3,5.75,1,1,0,0,0,90.3,65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-9.1,-17.4,9.3,18.2).s().p("ApFBPIPUn6IC3FfIvHH4g");
	this.shape_22.setTransform(-6.15,-20);

	this.instance_6 = new lib.ClipGroup_1();
	this.instance_6.setTransform(-11.45,-12.8,1,1,0,0,0,129.2,86.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#E9FFFF").s().p("AAAAAIAAgBIABABIAAABIgBgBg");
	this.shape_23.setTransform(-57.5333,-36.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#E9FFFF").s().p("AAAABQAAgBAAAAQgBAAAAAAQABAAAAAAQAAAAAAAAIABAAIAAABIgBABIAAgBg");
	this.shape_24.setTransform(-58.0867,-36.0633);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#E9FFFF").s().p("AAAABQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABAAIAAABIgBAAIAAAAg");
	this.shape_25.setTransform(-58.2833,-36.625);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#E9FFFF").s().p("AAAABQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAg");
	this.shape_26.setTransform(-58.9,-36.6781);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#E9FFFF").s().p("AAAABQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgBg");
	this.shape_27.setTransform(-58.245,-37.55);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#E9FFFF").s().p("AAAAAIAAgBIABABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBABIAAgCg");
	this.shape_28.setTransform(-58.755,-37.2333);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#E9FFFF").s().p("AAAABIAAgCIABABQAAAAAAAAQABAAAAABQgBAAAAAAQAAAAAAABIgBgBg");
	this.shape_29.setTransform(-59.0633,-38);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#E9FFFF").s().p("AAAABIAAgBQAAgBAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIAAABIAAAAIgBABIAAgBg");
	this.shape_30.setTransform(-64.6208,-34.8612);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#E9FFFF").s().p("AAAABIAAgBIABAAQAAAAAAAAQABABAAAAQgBAAAAAAQAAAAAAAAIgBAAIAAAAg");
	this.shape_31.setTransform(-64.3133,-35.275);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#E9FFFF").s().p("AAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIABABQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAIAAABIAAgCg");
	this.shape_32.setTransform(-65.6,-36.1719);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#E9FFFF").s().p("AAAABIAAgBIABAAIAAABIgBABIAAgBg");
	this.shape_33.setTransform(-65.0667,-35.5133);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#E9FFFF").s().p("AAAABQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAAAIgBABIAAgBg");
	this.shape_34.setTransform(-65.2833,-37.4488);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#E9FFFF").s().p("AAAABQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABAAIAAABIgBAAIAAAAg");
	this.shape_35.setTransform(-64.295,-36.525);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#E9FFFF").s().p("AAAAAIAAAAIABAAIAAABIgBABIAAgCg");
	this.shape_36.setTransform(-64.8167,-36.8167);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#E9FFFF").s().p("AAAABIAAgBIABAAIAAABIgBAAg");
	this.shape_37.setTransform(-61.7333,-31.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#E9FFFF").s().p("AAAABIAAgBQAAgBAAAAQAAAAAAAAQABABAAAAQAAAAAAAAIAAACIgBgBg");
	this.shape_38.setTransform(-61.8333,-32.2167);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#E9FFFF").s().p("AAAABQAAgBgBAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAQAAAAABAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgBABIAAgBg");
	this.shape_39.setTransform(-60.825,-31.5133);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#E9FFFF").s().p("AAAAAIAAAAIABAAIAAABIgBABIAAgCg");
	this.shape_40.setTransform(-62.2667,-32.6667);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#E9FFFF").s().p("AAAABIAAgBIABAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgBg");
	this.shape_41.setTransform(-61.205,-31.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#E9FFFF").s().p("AAAAAIAAgBIABABQAAAAAAAAQABAAAAAAQgBABAAAAQAAAAAAAAIgBABIAAgCg");
	this.shape_42.setTransform(-61.3633,-31.7833);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#E9FFFF").s().p("AAAABIAAgBIABAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIgBAAg");
	this.shape_43.setTransform(-62.105,-31.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#E9FFFF").s().p("AAAABIAAgBQAAgBAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgBg");
	this.shape_44.setTransform(-62.355,-32.1062);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#E9FFFF").s().p("AAAABQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIAAABIAAgBg");
	this.shape_45.setTransform(-59.6,-37.225);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#E9FFFF").s().p("AAAABIAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBAAIAAABIAAgBg");
	this.shape_46.setTransform(-59.7883,-38.3946);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#E9FFFF").s().p("AAAAAQAAAAgBAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAIAAABIgBABIAAgCg");
	this.shape_47.setTransform(-60.3488,-38.4167);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#E9FFFF").s().p("AgCAJIgDgHIABgBIACAEIADgFIgDgGIgGABIACADIgBAAIgCgDIgBgCIgBgCIABgBIACADIATgCIABACIgMAOIAAADIgBAAgAgBgHIADAHIAGgIg");
	this.shape_48.setTransform(-59.775,-32);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#E9FFFF").s().p("AgFANIAIgUIgNAHIABADIgBAAIgBgDIgDgDIABgBIACADIAPgIIAAgBIgBgCIABgBIACAFIgGASIALgHIgBgDIABAAIABADIADAEIgBABIgCgDIgQAJg");
	this.shape_49.setTransform(-60.625,-34.675);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#E9FFFF").s().p("AgFACIABAAIACADIADgEIgDgHIgGABIACACIgCABIgCgDIAAgCIgBgCIABgBIABADIAVgCIABACIgOAOIABADIgBABgAgBgGIADAGIAGgHg");
	this.shape_50.setTransform(-62,-36.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#E9FFFF").s().p("AgFANIAHgUIgMAHIACADIgBAAIgEgEIgBgCIABgBIACADIAOgIIABgBIgBgCIABgBIADAFIgHASIALgHIgBgDIAAAAIADAEIACADIgCAAIgBgCIgRAJg");
	this.shape_51.setTransform(-62.85,-38.975);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#AE263D").s().p("AA2AwQgJgCgIgEIgSgIQgTgJgOgHIghgSIgQgJQgJgFgGgGIAQAKIBOAkIgJgIQgGgGgGgJIgEgHIgGgHQgHgIgGgGIgbgZIAdAXIAUAUIAFAHIALAPIAaAUIArAQg");
	this.shape_52.setTransform(-60.875,-36.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#185CBA").s().p("AgLAyQgUgIgLgUQgKgUAFgUQAFgVASgJQASgJASAIQAUAIALAUQAKAUgFAUQgFAVgRAJQgKAFgKAAQgIAAgJgEg");
	this.shape_53.setTransform(-61.15,-35.6304);

	this.instance_7 = new lib.ClipGroup_5();
	this.instance_7.setTransform(-23.65,35.85,1,1,0,0,0,7.3,9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-4.3,-41.4,32.5,29.8).s().p("AnXDvIjYk+IAmgUIEGF8IBogvIiPkdIAWgMIEWIoQA0gXAdhLQAFgMA6jLQAwikAZhIQAihfAbgkQAZggCAhgQBBgwA7gqICKiHIB5ghQluEVhFAyQgbAZgWAgQgXAhgZA0IhXETQhND1gPAmQgLAihfAxQgpAWg0AXQgbgQjelDgAltE4ICVDbIBBgiIh2jrg");
	this.shape_54.setTransform(-3.15,22.05);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#BDBDBD","#C0C0C0","#CACACA","#DBDBDB","#F3F3F3","#FFFFFF"],[0,0.278,0.51,0.722,0.922,1],32.3,38.4,-4.7,-33.1).s().p("AnDE7IjYk/ITbqIIBcCzQlKD7hDAxQgcAagVAeQgYAigYAzIhYEUQhOD0gOAmQgKAhhUAtQgsAYg6AZQgbgPjelDg");
	this.shape_55.setTransform(-5.125,14.525);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#454545","#323232","#252525","#212121"],[0,0.325,0.667,1],-18.8,-61.2,18,10).s().p("ApKBAQiIlvADgfIAjgUIA3geQBfgxAjALQBBAQHvCgQA3AJApAAQAmABAlgIQA3gTGxiIIhDBEIi/AkQhDAZhMAYQiYAxgpABQgtAChhgcQhMgVifg4QjIhFgNgDQhNgUgxAeIEiIhIgXAMIiWkZIhjA5ICgGxIgmAUQhEixhEi4gAqkk4IBbD5IBhgyIh8jog");
	this.shape_56.setTransform(-26.6782,-28.1758);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-23.1,-60.9,13.7,10.3).s().p("ApuA/QiHluADgfIBjg3QBVgrAhAKQBBAQHvChQA4AJApAAQAlAAAlgHQBOgbGMh8IBYCoIzaKLQhEiyhEi4g");
	this.shape_57.setTransform(-23.1032,-28.128);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.instance_7},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.instance_6},{t:this.shape_22},{t:this.instance_5},{t:this.instance_4},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.instance_3},{t:this.shape_7},{t:this.shape_6},{t:this.instance_2},{t:this.shape_5},{t:this.shape_4},{t:this.instance_1},{t:this.instance},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(-140.6,-99.3,258.4,179.2), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-8.3,-3.1,16,6).s().p("AgvAHIAAgSQA4ABAnAEIAAASQgwgFgvAAg");
	this.shape.setTransform(53.4375,98.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-9,-3.3,15.3,5.8).s().p("Ag1AHIAEgSQA6ABAtAFQgEAMgDAFQgzgFgxAAg");
	this.shape_1.setTransform(54.325,94.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-8.2,-3,16.1,6.1).s().p("AgyAHIAEgSQAuAAAzAFIgBASQgpgEg7gBg");
	this.shape_2.setTransform(55,90);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-7.9,-2.9,16.4,6.2).s().p("AgtAIIADgTQAzABAlAEIAAASQgtgEguAAg");
	this.shape_3.setTransform(55.5,85.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-16.9,1.2,8,-0.5).s().p("AgsAEQAwgTAkgFIAGAUQgeACgwATQgFgLgHgGg");
	this.shape_4.setTransform(-6.35,103.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-16.7,1.2,8.2,-0.5).s().p("Ag0AGQA6gYAmgFIAJAUQgkADg7AYg");
	this.shape_5.setTransform(-8.375,99);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-16.4,0.7,8.5,-0.4).s().p("AgzAEQA3gWAngEIAJATQgnADg5AXg");
	this.shape_6.setTransform(-10.2,94.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-16.5,0.4,8.4,-0.1).s().p("AgwABQA1gRAkgFIAHATIABACQglACg2ATg");
	this.shape_7.setTransform(-12.175,89.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#0060AA","#4C2254"],[0,1],-11.1,0,11.2,0).s().p("AhVBpQgMgfABgPQACgLgDgoQgDgtgHgKQgJgNALgrQAKgtAUAFQAUAFA/ACQABAXAPAeQAOAeASAVQAOAQAQAeQATAjAHAfQgoA5h7AHIgCABQgTAAgNgog");
	this.shape_8.setTransform(54.5923,120.6527);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#0060AA","#4C2254"],[0,1],-3.1,0.2,3.2,-0.2).s().p("AgIAfQgMgEgHgLQgGgMADgLQAEgNALgHQAMgGALADQANAEAHAMQAGALgEAMQgDAMgMAHQgHAEgIAAIgIgBg");
	this.shape_9.setTransform(38.2649,111.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.1,2.4,2.1,-2.3).s().p("AgIAeQgMgDgHgMQgGgLAEgMQADgMAMgHQALgGAMAEQANADAGAMQAGAMgDALQgEAMgMAHQgHAEgIAAIgIgCg");
	this.shape_10.setTransform(13.4851,111.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#0060AA","#4C2254"],[0,1],-9.5,3.7,7.5,-2.2).s().p("AhDB3QABgYAIg9QAHg7ghhAQAygrAegJQAYgHAVAqQAKAWAOAmQAOAZAFA5QAFBEgYATQgYAUgpAAIgBAAQgsAAgWgYg");
	this.shape_11.setTransform(4.4763,123.5937);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#0060AA","#4C2254"],[0,1],3.1,-4.6,-3.6,4.2).s().p("AghAgQgfgGgCgPQgDgUAvgxQAhAJAgAQQAMAGAMAKQgeAwgcAcQgJgUghgHg");
	this.shape_12.setTransform(48.8687,-75.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#BDBDBD","#FFFFFF"],[0,1],13.1,7.5,-15,-6.8).s().p("Ag8CBQg2gcgYhJQgYhGAagzQAXguA9gBQA0gBA+AfQBAAhAUBGQAWBMhRASQg2ANgkAgQgKAKgJAAQgMAAgagNg");
	this.shape_13.setTransform(46.984,-68.1015);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#BDBDBD","#FFFFFF"],[0,1],21.5,13.3,-17.8,-10.5).s().p("AglCmQg9gahAhZIgzhTQAuh1BIggQAwgWAvATQARAHAhAzQAoA+A7AuQBDAzgCA7QgBAggTAqQgFAZhMADIgKAAQhLAAhBgcg");
	this.shape_14.setTransform(65.8029,-50.609);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-15,1.3,15,-0.7).s().p("AhxA3QgNABgLgKQgLgKgBgPIgBgYQgBgOAJgLQAJgMANgBQB0AaB1gqQAOAAALAJQALAKAAAPIACAYQABAPgJALQgJALgOABQhTAThVAAQggAAghgDg");
	this.shape_15.setTransform(48.35,74.0027);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-12.7,1.4,12.8,-1.4).s().p("AhhBCQgagWgEgiQgEgdAUgYQATgYAegDIBsgMQAegDAYATQAYATADAeIABAJQAEAdgUAYQgTAYgeADIhjALIgLABQgbAAgXgSg");
	this.shape_16.setTransform(46.525,61.4859);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#0060AA","#4C2254"],[0,1],-14.5,1.7,14.5,-1.5).s().p("AhmBXQglgdgGgvQgEgpAaghQAbgiAqgEIBVgKQAqgFAiAbQAhAbAEAqIACAMQAEApgaAhQgbAhgqAFIhJAIIgPABQgmAAgfgag");
	this.shape_17.setTransform(46.875,60.5285);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#0060AA","#4C2254"],[0,1],13.3,-0.1,-13.4,0.2).s().p("AARCmIhPgFQgngCgTgIQgTgJALhWQAOhZgBgLQAAgWAHgbQAHghAMgHQAbgRBTgMQBjgPABAoIAKBgQAHBlgRAaQgIANAAATQACAZgBADQgGAVg4AAIgjgBg");
	this.shape_18.setTransform(46.8996,86.977);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#0060AA","#4C2254"],[0,1],-16.5,0,16.6,0).s().p("AhdBBQgPgfgGhEQgCgbgRgTQgUgTgIgIQgEgFAAgPQAvAgAHANQAGAKAGAuQAGAqgBANQAQAoAdAYQAgAaAigFQAxgGAXgHQAlgKARgUQAQgSAHgVQACBaiQAGIgJAAQhNAAgfg/g");
	this.shape_19.setTransform(49.6764,128.7588);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#D6D6D6","#858585"],[0,1],-16.5,0,16.6,0).s().p("AhdCUQgPgfgGhEQgCgbgRgUQgUgRgIgJQgJgKANg7IAQg5QgHgNACgcQACgRBjgCQBXgCAWAGQAJACgEAQIgLAmQgGAWAQAlQAOAlAXAZQAQASASAjQAUApAFAhQAIAtgZAcQgiAlhZADIgJABQhNAAgfhAg");
	this.shape_20.setTransform(49.6903,120.4177);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#4C2254").s().p("AjrCjQg7gwgEhmQgEhaA2g5QBIhKCogIQCmgHBOBEQA7A0AEBbQAFBlg3A1QhDBCitAIIgkABQiPAAhBg2gAgIjPQiPAGhHA4QhIA4AEBlQAEBfA0AuQBHA+CsgHQCugIBBhEQAvgygEheQgFhmhMgyQhEgsh3AAIgfABg");
	this.shape_21.setTransform(4.4315,-113.4415);

	this.instance = new lib.Group_1();
	this.instance.setTransform(-18.6,-112.5,1,1,0,0,0,3.9,15.1);
	this.instance.alpha = 0.5;

	this.instance_1 = new lib.Path_97();
	this.instance_1.setTransform(27.5,-114.2,1,1,0,0,0,3.6,15.1);
	this.instance_1.alpha = 0.5;

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#0060AA","#4C2254"],[0,1],-29.4,1.3,29.5,-1.3).s().p("AjoChQg5gvgFhlQgEhfA+g5QBIhBCcgHQCagHBOA7QBDAzAEBgQAEBkg1A0QhCBBirAHIgkABQiNAAhAg0g");
	this.shape_22.setTransform(4.5556,-113.465);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-25.1,-22.5,25.2,23.6).s().p("Aj5DtQg/hHgHiYQgGiQBChUQBNhiCpgHQCogHBVBaQBKBOAGCRQAHCXg5BNQhHBhi5AIIgdAAQihAAhJhTg");
	this.shape_23.setTransform(4.5846,-113.1714);

	this.instance_2 = new lib.ClipGroup_4_1();
	this.instance_2.setTransform(7,-91.2,1,1,0,0,0,34.5,14.5);
	this.instance_2.alpha = 0.5;
	this.instance_2.compositeOperation = "multiply";

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#D6D6D6","#858585"],[0,1],-25.3,1.6,25.5,-0.6).s().p("AiuA7QhLgWgEglQgEgsASgJQAPgHAnANIBTAeQA4ARAsgCQAsgCA3gWQAegNAzgYQAogSAQAGQAUAIAAAuQABAkhJAcQhJAdhpAFIgjAAQhRAAg+gSg");
	this.shape_24.setTransform(5.6061,-86.907);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#0060AA","#4C2254"],[0,1],-4.8,1.8,5.4,-2.3).s().p("AhBgYQAPgJALgFQAigNAhgFQAqA1gFAUQgDAOggADQghAEgLATQgagfgZgyg");
	this.shape_25.setTransform(-36.2782,-74.825);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-9,-10.1,11.7,7.4).s().p("AAKCMQgJAAgJgLQghgjg1gSQhQgaAdhJQAbhEBDgbQA/gaA1AGQA9AHATAwQAVA1geBEQgfBGg5AXQgYAJgMAAIgCAAg");
	this.shape_26.setTransform(-35.0802,-66.7528);

	this.instance_3 = new lib.ClipGroup_3_1();
	this.instance_3.setTransform(-47.75,-47.7,1,1,0,0,0,35.4,40.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#0060AA","#4C2254"],[0,1],-12.1,-3.6,11.7,4.2).s().p("AiCgJQAgg5AggvQCNAsA3A6QgCAmgbAgIg5A3QhFhchpgfg");
	this.shape_27.setTransform(-59.55,-40.125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-11.9,-7.7,9.3,7.3).s().p("AjGE3Qg1gMACgxQACgpAyiEQBUi0BZhkQAbggAZgTIAUgOQA2gqA1gDQBKgEASBZQAQBTg0ArIgxAiQgfAUgPATQgDAjgUAbQgLAQgkAfQhPBHgkBZQgQA1gvAPQgSAGgTAAQgOAAgPgDg");
	this.shape_28.setTransform(-58.0563,-38.3729);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#0060AA","#4C2254"],[0,1],-0.7,0,0.8,0).s().p("AgHAKIAAgTIAPAAIAAATg");
	this.shape_29.setTransform(8.1,-44.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#0060AA","#4C2254"],[0,1],-0.7,0,0.8,0).s().p("AgHAUIAAgnIAPAAIAAAng");
	this.shape_30.setTransform(5.875,-45.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#0060AA","#4C2254"],[0,1],-0.7,0,0.8,0).s().p("AgHAUIAAgnIAPAAIAAAng");
	this.shape_31.setTransform(3.7,-45.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#0060AA","#4C2254"],[0,1],-0.7,0,0.8,0).s().p("AgHAUIAAgnIAPAAIAAAng");
	this.shape_32.setTransform(1.5,-45.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#0060AA","#4C2254"],[0,1],-0.7,0,0.8,0).s().p("AgHAUIAAgnIAPAAIAAAng");
	this.shape_33.setTransform(-0.675,-45.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#0060AA","#4C2254"],[0,1],-1.9,0,1.9,0).s().p("AgMAOQgGgGAAgIQAAgHAGgFQAFgGAHAAQAIAAAGAGQAFAFAAAHQAAAIgFAGQgGAFgIAAQgHAAgFgFg");
	this.shape_34.setTransform(22.375,-45.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.rf(["#D55456","#84357A"],[0,1],0,0,0,0,0,1.9).s().p("AgNAOQgFgGAAgIQAAgHAFgFQAGgGAHAAQAIAAAFAGQAGAFAAAHQAAAIgGAGQgFAFgIAAQgHAAgGgFg");
	this.shape_35.setTransform(17.675,-45.725);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.rf(["#D55456","#84357A"],[0,1],0,0,0,0,0,5.3).s().p("AglAlQgPgPAAgWQAAgVAPgPQAQgPAVAAQAWAAAQAPQAPAPAAAVQAAAWgPAPQgQAPgWAAQgVAAgQgPg");
	this.shape_36.setTransform(6.125,-58.575);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#00D4B9","#34549A"],[0,1],-3.4,0,3.5,0).s().p("AgYBXQgKgKAAgPIAAh7QAAgOAKgLQALgKANAAQAOAAALAKQAJALABAOIAAB7QgBAPgJAKQgLAKgOAAQgNAAgLgKg");
	this.shape_37.setTransform(-7.7,-53.075);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-14.2,12,14.3,-11.9).s().p("AhSB8QgyAAgigjQgkgjAAgyIAAgHQAAgyAkgjQAigjAyAAIClAAQAyAAAjAjQAjAjAAAyIAAAHQAAAygjAjQgjAjgyAAg");
	this.shape_38.setTransform(5.95,-53.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#EDEDED","#ADADAD"],[0,1],-15.6,13.1,15.6,-13).s().p("AhfCIQgyAAgjgjQgjgkAAgxIAAgfQAAgxAjgjQAjgkAyAAIC/AAQAyAAAjAkQAjAjAAAxIAAAfQAAAxgjAkQgjAjgyAAg");
	this.shape_39.setTransform(6.025,-53.125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#0060AA","#4C2254"],[0,1],2.5,1.1,-2.4,-1).s().p("AgZgHIADgFIAwAUIgCAFg");
	this.shape_40.setTransform(-20.675,-1.275);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#0060AA","#4C2254"],[0,1],2.5,1.1,-2.4,-1).s().p("AgZgHIACgFIAxAUIgDAFg");
	this.shape_41.setTransform(-20.275,-2.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#0060AA","#4C2254"],[0,1],2.5,1.1,-2.4,-1).s().p("AgZgHIADgFIAvAUIgBAFg");
	this.shape_42.setTransform(-19.9,-3.175);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#0060AA","#4C2254"],[0,1],2.5,1.1,-2.4,-1).s().p("AgYgHIABgFIAxAVIgDAEg");
	this.shape_43.setTransform(-19.5,-4.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#0060AA","#4C2254"],[0,1],2.5,1.1,-2.4,-1).s().p("AgZgIIADgEIAwAUIgCAFg");
	this.shape_44.setTransform(-19.1,-5.05);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],3.7,0.3,-3.7,-0.2).s().p("AgCAqIgXgIQgHgDgEgHQgDgIADgHIAPgnQAEgNAOAAIgLAgIAhAMIAMgfQALAIgFAOIgPAnQgDAIgHADIgIACIgGgCg");
	this.shape_45.setTransform(-14.2287,-16.925);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],2.9,1.3,-2.8,-1.2).s().p("AgQAlQgLgFgFgMQgFgMAFgLIAIgSQAFgLAMgFQALgFAMAFQAMAGAFAMQAFAMgGALIgHARQgFAMgNAFQgFACgFAAQgGAAgHgDg");
	this.shape_46.setTransform(-19.8875,-3.2375);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-2.9,1.1,3,-1).s().p("AgDA2QgMgFgEgMIgTgzQgEgMAFgMQAFgMANgEQAMgEALAFQAMAGAEAMIATAyQAEAMgFAMQgFAMgNAEQgFACgGAAQgGAAgGgDg");
	this.shape_47.setTransform(-13.325,-80.758);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#0060AA","#4C2254"],[0,1],-8.8,0,8.8,0).s().p("AhXGfQBeitAeisQAXiDgPh6QgMhagehOIgcg9IAegUIAfBCQAhBSAMBeQARCEgaCMQgfCuhgCxg");
	this.shape_48.setTransform(-14.548,-43.075);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-2.8,-1.2,2.9,1.2).s().p("AgdBHQgMgFgFgMQgEgMAFgMIAjhTQAFgMALgFQAMgFAMAFQAMAGAFALQAFAMgFAMIgjBTQgFAMgMAFQgGACgGAAQgGAAgGgCg");
	this.shape_49.setTransform(-17.0566,-9.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.4,1.1,2.5,-1).s().p("AgZAIIAwgUIADAFIgxAUg");
	this.shape_50.setTransform(32.225,-1.275);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.4,1.1,2.5,-1).s().p("AgZAIIAxgUIACAFIgwAUg");
	this.shape_51.setTransform(31.825,-2.225);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.4,1.1,2.5,-1).s().p("AgZAIIAwgUIADAEIgxAVg");
	this.shape_52.setTransform(31.45,-3.15);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.4,1.1,2.5,-1).s().p("AgYAJIAvgVIACAFIgvAUg");
	this.shape_53.setTransform(31.05,-4.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.4,1.1,2.5,-1).s().p("AgZAIIAxgUIACAEIgxAVg");
	this.shape_54.setTransform(30.65,-5.05);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-3.7,0.3,3.7,-0.2).s().p("AgLAqQgHgDgDgIIgPgnQgFgOALgIIAMAfIAhgLIgLghQAOAAAEANIAPAnQADAHgDAIQgEAHgHADIgXAIIgGACIgIgCg");
	this.shape_55.setTransform(25.7787,-16.925);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-2.8,1.3,2.9,-1.2).s().p("AgGAmQgNgFgFgMIgIgRQgFgLAFgMQAEgMAMgGQANgFALAFQAMAFAFALIAHASQAGALgFAMQgFAMgLAFQgHADgGAAQgFAAgFgCg");
	this.shape_56.setTransform(31.45,-3.2375);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],3,1.1,-2.9,-1).s().p("AgTA3QgNgEgFgMQgFgMAEgMIATgyQAEgMAMgGQALgFAMAEQANAEAFAMQAFAMgEAMIgTAzQgEAMgMAFQgGADgGAAQgGAAgFgCg");
	this.shape_57.setTransform(24.875,-80.758);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#0060AA","#4C2254"],[0,1],8.8,0,-8.8,0).s().p("AhIBSQgZiMARiEQAMheAghSIAghCIAeAUIgcA9QgfBOgLBaQgQB6AXCDQAfCsBeCtIggASQhgixggiug");
	this.shape_58.setTransform(26.11,-43.075);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],2.9,-1.2,-2.8,1.2).s().p("AAGBHQgLgFgGgMIgjhTQgFgMAFgMQAFgLAMgGQAMgFAMAFQALAFAFAMIAjBTQAGAMgFAMQgFAMgMAFQgGACgGAAQgGAAgGgCg");
	this.shape_59.setTransform(28.619,-9.9);

	this.instance_4 = new lib.ClipGroup_2_1();
	this.instance_4.setTransform(9.15,-42.85,1,1,0,0,0,26.2,43.9);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.ClipGroup_1_0_1();
	this.instance_5.setTransform(4.05,-42.8,1,1,0,0,0,27.8,44);
	this.instance_5.compositeOperation = "multiply";

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-36,-13.5,34.2,10.6).s().p("Ak/CgQgGiSgdigQAAgOAKgKQAKgJAOAAQFShDEwBDQANAAAKAJQAKAKAAAOQgbChgFCQQiWA3itAAQioAAiXg2g");
	this.shape_60.setTransform(6.275,-64.4625);

	this.instance_6 = new lib.ClipGroup_0_2();
	this.instance_6.setTransform(7.85,-42.45,1,1,0,0,0,38.5,45.4);
	this.instance_6.alpha = 0.8516;
	this.instance_6.compositeOperation = "multiply";

	this.instance_7 = new lib.ClipGroup_1_1();
	this.instance_7.setTransform(6.3,-42.3,1,1,0,0,0,35.5,46.5);
	this.instance_7.compositeOperation = "multiply";

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#EDEDED","#ADADAD"],[0,1],-1.2,0,1.2,0).s().p("AgLG7IAAt1IAXAAIAAN1g");
	this.shape_61.setTransform(6.425,-41.475);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-43.1,-15.8,43.2,13.9).s().p("AlAGHQgOAAgKgKQgKgKAAgNQBIlNhImRQAAgOAKgJQAKgKAOAAQFQhCEyBCQANAAAKAKQAKAJAAAOQhCGSBCFMQAAANgKAKQgKAKgNAAQihA0ihAAQigAAigg0g");
	this.shape_62.setTransform(6.275,-41.4625);

	this.instance_8 = new lib.ClipGroup_6();
	this.instance_8.setTransform(8,2.3,1,1,0,0,0,38.5,26.1);
	this.instance_8.compositeOperation = "multiply";

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#0060AA","#4C2254"],[0,1],-34.2,0,34.3,0).s().p("Ak1AcQgNAAgKgJQgJgKAAgMIANhIQBvBECHANQDGAUDVhoIANBLQAAAMgJAKQgJAJgOAAQibAzibAAQibAAiagzg");
	this.shape_63.setTransform(6.425,-0.5625);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#D6D6D6","#BABABA"],[0,1],-34.4,0,34.5,0).s().p("Ag5CrQgchChJguQhKguhigMQgOghAAgjQAAhYBlgSQAogIBGAAQApAABcABICGgBQBHAAAnAIQBlASAABYQAAAjgOAhQhiAMhKAuQhJAugcBCQgXALgjAAQghAAgYgLg");
	this.shape_64.setTransform(6.425,10.2438);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-14.8,2.6,15,-1.6).s().p("AiFA5QgLgIgCgPIgEgZQgCgOAJgMQAIgLANgCQB2ARBxgyQAOgCALAJQALAIACAPIAEAZQACAOgJALQgIAMgNACQhwAjh3gCIgFABQgLAAgJgIg");
	this.shape_65.setTransform(-8.425,76.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-16.4,9.9,15.8,-7.7).s().p("AiGCOQghgsgcg8IgXgxQgfg+BJg+QAfgbCMhQQBUAJBTCnQAqBSAYBRIgBAHQgEAJgLAMQglAohnA8QgeASgfAAQhIAAhJhlg");
	this.shape_66.setTransform(35.238,32.4035);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#0060AA","#4C2254"],[0,1],-14.3,8.5,14.7,-7.4).s().p("Ah9BjQgTgSgPgZIgKgWQgMgaBFgtQAXgPCAhIQAtgJAmAhQAaAXATApQAIAPgEARQgEAPgNALQgsAhhVAwQgqAYgkAAQgoAAgggcg");
	this.shape_67.setTransform(42.0985,47.1841);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-17.3,6.4,17.2,-5.3).s().p("Ah6DfQgRgDgIgGIgEgEQgShXgFhiQgKjCBBg4QB6gKBCAUQBRAZAKBJIAKAzQAIA/gCAzQgICph3AJQgzAEgoAAQgyAAgegHg");
	this.shape_68.setTransform(-13.5378,31.6459);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#0060AA","#4C2254"],[0,1],16.5,-2.1,-16.4,2.2).s().p("AhvBnQgRgBgNgLQgNgLgDgQQgIgtAIghQAKgwAqgUQCQgSAdgBQBSgEAGAcIAFAYQADAdgFAYQgSBRhlAMQhTAKg0AAIgQAAg");
	this.shape_69.setTransform(-12.5634,47.1945);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-12.7,1.7,12.8,-1.5).s().p("AhgBDQgbgUgEgiQgEgeATgYQASgYAegEIBsgOQAegDAZASQAYATAEAeIABAJQAEAdgTAYQgTAYgeAEIhjANIgMAAQgaAAgXgRg");
	this.shape_70.setTransform(-11.0431,63.7869);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#0060AA","#4C2254"],[0,1],-14.4,1.9,14.5,-1.8).s().p("AhlBZQglgdgGgvQgGgpAaghQAagiAqgFIBVgLQAqgGAiAaQAiAaAFAqIACAMQAFApgaAiQgaAigqAFIhJAJIgQABQgmAAgfgYg");
	this.shape_71.setTransform(-10.7007,62.8284);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#0060AA","#4C2254"],[0,1],-12.8,3.2,12.4,-5.6).s().p("Ag7CjQgHgngUgPQgagTgchhIgXheQgNgmBigUQBTgRAfAHQANACATAcQAPAYAHAUQAEALAsBQQAmBMgOAPQgPAOgkAQIhKAfQgyAYgZAAQgPAAgGgJg");
	this.shape_72.setTransform(-2.3528,92.457);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#0060AA","#4C2254"],[0,1],-12.4,6.1,14.3,-3.2).s().p("AhBCVQgcgGgLgYQAmAQAlgJQAvgMAHgEQAWgNASgsIAIhyQAGg8ANgIQAFgNAHgKQACAJgBALQgKAggEAcQgIAzAEBDQgTBIgtAYQgWALgcAAQgSAAgUgEg");
	this.shape_73.setTransform(9.1167,129.9219);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#D6D6D6","#858585"],[0,1],-13.2,5.5,14,-4).s().p("AgtDeQgpgIgFg4QgCgcAKhVQAGgwgVg1IgWgrQgbgyBqgvQAmgRAkgIQAkgIgBAIQAAAYAeA3QAfA2gCAeQgKAggEAbQgIAzAEBEQgTBIguAXQgVALgdAAQgSAAgVgEg");
	this.shape_74.setTransform(6.9331,122.5154);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#DEDBE0").s().p("AhQBVQgkgFAFgiQAQgxAJgiQBAhJBRAkQAbAMARATQAQASgMAAQgSAAABAlQABATAEATIAAAKQgCAKgMgDQgIgCg8AMQguAKgdAAIgSgCg");
	this.shape_75.setTransform(-75.0314,-4.9979);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.3,-0.2,1.7,0.2).s().p("AgUgRIAQgzQAKgBAIABQAQADgJAIQgKAJgCAeIgBA1QAAAVgIAJQgEAFgEAAQgXgeALg5g");
	this.shape_76.setTransform(-84.7404,8.3917);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.7,-0.4,2.1,0.1).s().p("AgFBhQgYgOADhOIAIhLIAtgbIgQBIQgDAOACAgIAEAqQAAANgFAKQgGAMgHAAIgBgBg");
	this.shape_77.setTransform(-74.1417,8.7538);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.5,-0.3,2.3,0.2).s().p("AgCBeQgRgLgFgUQgLgtAbhnQARgQALANQAGAGACAKIgHA7QgGA8ABAKQABANgGAOQgFALgFAAIgDgBg");
	this.shape_78.setTransform(-80.022,6.6668);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#0060AA","#4C2254"],[0,1],-3,-0.3,3.3,0.3).s().p("AAMBeQgSgHgIgTQgRgqALhrQAOgUANALQAGAFAEAJIACA8QACA8ADAKQAEANgFAPQgDANgGAAIgCgBg");
	this.shape_79.setTransform(-68.9645,8.3656);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#0060AA","#4C2254"],[0,1],-5.9,-0.7,6.5,0.7).s().p("AAdBSQgGgIgKgaQgJgWgNgLQgMgJgZgGQgWgGATgtQATgtAOAMIAvBEQArBKgXAbQgFADgFAAQgGAAgGgGg");
	this.shape_80.setTransform(-63.025,-0.1229);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#4C2254","#0060AA"],[0,1],2.3,0,-2.3,0).s().p("AgCAZQgHAAgEgCQgFgDAAgEQgIgQAIgOQAAgEAFgDQAFgDAGAAIAIAAQAHAAAFADQAFADAAAEIAAAeQAAAEgFADQgFACgHAAg");
	this.shape_81.setTransform(-29.2875,-108.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.4,0,2.4,0).s().p("AgFAZQgIAAgFgDQgFgDAAgDIAAgeQAAgEAFgDQAFgDAIAAIAHAAQAIAAAFADQAFADAAAEQAIAOgIAQQAAADgFADQgFADgIAAg");
	this.shape_82.setTransform(38.275,-108.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#4C2254","#0060AA"],[0,1],3,0,-2.9,0).s().p("AgCApQgJAAgHgFQgGgEAAgHQgKgZAKgYQAAgHAGgFQAHgEAJAAIAKAAQAJAAAGAEQAHAFAAAHIAAAxQAAAHgHAEQgGAFgJAAg");
	this.shape_83.setTransform(-29.8375,-116.175);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#FFFFFF","#858585"],[0,1],3.8,0,-3.7,0).s().p("AgDBhQgMAAgHgLQgIgMAAgPQgMg6AMg7QAAgPAIgMQAHgLAMAAIANAAQAMAAAHALQAIAMAAAPIAAB1QAAAPgIAMQgHALgMAAg");
	this.shape_84.setTransform(-29.9,-113.15);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#0060AA","#4C2254"],[0,1],-2.9,0,3,0).s().p("AgHApQgJAAgGgFQgHgEAAgHIAAgxQAAgHAHgFQAGgEAJAAIAKAAQAJAAAHAEQAGAFAAAHQAKAYgKAZQAAAHgGAEQgHAFgJAAg");
	this.shape_85.setTransform(38.975,-116.175);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#FFFFFF","#858585"],[0,1],-3.7,0,3.8,0).s().p("AgJBhQgLAAgJgLQgIgMAAgPIAAh1QAAgPAIgMQAJgLALAAIANAAQALAAAJALQAHAMABAPQAMA6gMA7QgBAPgHAMQgJALgLAAg");
	this.shape_86.setTransform(39.05,-113.15);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#D6D6D6","#858585"],[0,1],-40.5,0.9,40.5,-0.8).s().p("AmLAbQgFgTgEgEIADgKQAHgKAWgBILogQQATgBAJAKQAFAFAAAGQgEAEgEASQgCAJgXAAIrmARIgCAAQgVAAgCgIg");
	this.shape_87.setTransform(4.475,-111.303);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-40.5,1.3,40.5,-0.5).s().p("AlwBwQgMABgMgTQgKgPgBgHIgDibQAAgEAJgIQAMgJAMAAILngRQAMAAAMAJQAKAHAAAEIADCbQgOAqgSAAQj0AajiAAQiMAAiFgKg");
	this.shape_88.setTransform(4.6488,-102.5579);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#EDEDED","#ADADAD"],[0,1],-39.1,1.2,39.8,-0.5).s().p("AlOCOQgLAAgLgUQgJgQgBgIIgcjhQABgDATgFQAUgFANgBIKpgPQAPAAATABQAUACABAEIgTDnQAAAHgJARQgKAUgLABQjRAejFAAQiMAAiGgPg");
	this.shape_89.setTransform(4.65,-91.9743);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#FFFFFF","#BDBDBD"],[0,1],-40.4,1.3,40.6,-0.5).s().p("AlrFKQgMABgNg8QgLgzAAgTIgLntQAAgNAJgZQALgdAMAAILngQQAMgBAMAdQALAYAAANIALHtQgMCDgTAAQjRA+jHAAQirAAikgug");
	this.shape_90.setTransform(5.8238,-47.8408);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.instance_8},{t:this.shape_62},{t:this.shape_61},{t:this.instance_7},{t:this.instance_6},{t:this.shape_60},{t:this.instance_5},{t:this.instance_4},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.instance_3},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.instance_2},{t:this.shape_23},{t:this.shape_22},{t:this.instance_1},{t:this.instance},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(-87.2,-145.2,174.4,290.4), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#0CA0AF","#0C9EAF","#0A97AE","#088CAD","#047BAC","#0068AA"],[0,0.506,0.686,0.816,0.922,1],0,0,0,0,0,57).s().p("Ah1I7IgLgCIgBgCIgVgKIAAgBQgDgBgBgCIgDAAIgCgBIAAgBIgJgGIgCgDIgEgDIgCgCQADgCACAAQgDgDgFgDIgJgEIAAgDIgCgDIAHADIgIgHIgDgDIABAAIADADIAEADIgHgMIgEgGIAAgDIgCgDIgEAAIAHAKIgDAAQgEgBgCgGQgCgGgCgCQgDgDgEgIQgEgIgEgEQABgKgBgCIgBgCIgDgEQACgHgDgGQgCgGgKgPIgBgCIgDgWIgCgIIAAgIIgBgCIgBgCIgCgFIgBgEIAAAAIgBgDIgBgDIAAgBIgCgFIAAgDIgDgGIAAAAIgGgXQgIAAgJgMQgJgLgJABQgLABgHgLIgLgTIgFgIIgGgJIgBgFQgBgHgNgKQgMgKgCgIIAAgDQgDgDABgFIABgJQABgCADgBIACgCIgBgEIgIAAIgDgRIAGgBQgCgJAHgDIAAgEIAEgDIgBgHQAEAAAAgCQABgCAAgLQAGgFgDgHIgFgNIgCAAQgDgFAFgHQAFgHAAgDQAGgCABgCIAAgMIAHgBIAKgHIAKAAIAAgGQACgCADgBIAEAAIACACQgQAMANAVIACgCIgDgPIALgLIADgCQADABAIAFQADACAAAEIAGABIAKABIAGACIAEAGIADAAQADgHACgDIAGABIACABIAEgEQADABAFACIgBADIgCABQAAAGACACIAIgDIADAAIABAFQAAACAEACIADACIAMAHQAAANAXAFIAEAAIAGgBQAFgBACABIAQAGQACAGAKACIAEAKIACAMIAFAAQADAHgDAKQgDACgEgBIAAAIQAFABABgCQABgCAAgFIAEAAIACAAIALADIABADIgCACIgDAEIAAAFIAIAAIAAgJQAEgBAHADIADABQANACAKAJIgFADIAAACQAHADADgCIAAgDIAFgBIALAEIANAAQAFgBACAAIAIAFQABAHACABQACACAKADIAJAAQAJAEABAUQAAADgDAHIgNARQgDAEgDAAQgLAOgCABQgCAEAAAHIAAAFIABAHQAAAEgDAHIgBAEQgDAOgCABQgDAGAAAFIgFAEQgCAIgFACIgCAFIgUABIgGAFIgJAAQgEAEgKAMQgCAEADAGQADAHgBADQgBACgDADQgDACgBADIgGAMIgDAAIgBgGQgFAEgFAXQgBAEgFAAIgTgDIgFAAQABACAEADIAGAEIABAEIACAAIACAEIgBADIgDAFQgCAEAAADIgDgBIgGAAIgDABIgKABIABADQADAEAAADIABADIABACIgGAAIgFgCIgDAAIACADQADAFACABIADgBIAAAAIABAAIACACIAAADIgEAAIACAHIADAIIgFAAIgCACIABADIAJAHIADABIADACIgBACIACAGIgCACIADAEIgDABIAEAFIAIAHIACACIAJAGIAEACIAIADIgBABgAjCH/IABABgAEfHDIACgDQAAgBAAAAQABAAAAgBQAAAAgBAAQAAAAAAAAQACgEAFgDIACgCIAUg2IAKgQQACgKAEgHQgBgJABgKQACgUAKgHIAYgoIgBgHIACgHQAGgJgCgPQgCgVAAgEQgDgCgBgFIgBgJQgDgBgCgDQACgDADgBQAIgcADgIIACgMIgXgBQgGgCgBgDIgBgOQgEgDgHADIgGADIgBAAIgMgBQgFACgEAHIgQAAQgDgBgCgDIgMAAQgJgBgFACIgDAHQgKABgDgEQgFgEgKgVQgVgCACgVQgIgFgLgNQgIgMAAgCIAAgHIgEgOQAIgHAAgDIAAgEIAAgWIAEgKIgEgDIgMgCQgBgDAAgFIABgDQAGgCACgDQABgFAAgOIAGgCIADAAIAIgSQAIgSACgBQANgBABgOQADgBAHAAIAAgHIAAgZQAFgDAHABIgCgPIALAAIAAgIQAAgGABgDIAEACQAEAFAJgBIACAAIAEABIAEABQAEgDAIABIACgHQAHgDAIABIABgDQALgCADAAQADABAGAFQADgBABgDIAWgCQAEABAFAEQgCADgDABIAAAEQAFAEABAKQABAKAFADQADADAKAEQAJADAFAEIADAHIALACQAFABAFAIIAFAAIACgBIgEgXQAKABAOAIIAXANIABAAIACgDIACAAQAUAaAMAwQAGAZADATIAAAFQgBANAHAXQAIAYAAAMQABADAAAMIACACIAEAAIAEgBIABgDQADACgBAFQgDAXgEAKQgDAKgPAjQgFAMgOAWQgOAVgFAMIgBACQAAAGgGAMQgEALgBAHIgQAjIg/BNQgOANgfAVQgfAWgOANQgGACgEgBIgHACIgKAAgAGiGMIgBgBIACgCIgCAAIAAgBIAIgLIAHgKIAMgPIAAAAQAHgFAGgPIAKgNQABgCADABIADgEQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAAAIAPgWQAAAEgMAVIgGAJIgEAHQgqA8gKACgAmNBSQgBAAgBAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgCgBgHgJIgEgCIgEACIgDgEQABgEgCgEIgLgVIgFgDIAAAFIgIgDIgDgIIgDgBIgJAAIgEgHIgHgJIgGgEIgGABIgBAEIgFABIgHgDIgRgMIgHgHIgGgDIgJgQIABgGIADgEIgDgEIgBgKIgDgKIgEgPIgEgFIABgIIgCgGIgCgHIgCgJIgBgMIACgJIAAgFIgDgDIgCAAIgCALIABAHIgBAKIACACIAAAIIABAFIAAAQIACAFIAAAHIACADIABAHIgBAGIgDADIABgGIgCgFIgCgGIgCgDIAAgEIABgFIgCgHIgFgKIAAgFIADgFIAAgFIgCgMIAEgdIAAgGIgCgEIgBgFIgCABIAAgHIACgHIAAgFIAEgMIAAgFIACgHIADgJIABgFIAHgPIAHgRIADgDIAagvIACgHIACgEIABgDIADgFIABgBIAAACIgBADIABAAIgEAGIAAACIgBADIgDAEIgEALIAKgRIADgJIACgEIAAgBIACgGIADgFIADgGIAGgHIgBgBIASgWIAAAAIABgCIAEgEIACgDIAEgFIABgBIAHgIIgBACIAIgIIArgmIAbgVIAwgfIgCACIACgCIASgJIAGgDIgNAHIAAABIAJgFIgJAFIAIgDIABgBIAAABIgDADIgCADIACAAIgEADIgIAFIAFABIAGgCIgBACIgJAIIAOgLIAPgGIgCAEIABAAIABADIAIgBIAFgEIAGgCIACgFIAGgCIAHgEIgBADIgHAGIgDAAIgEAEIABAAIgGAFIgBADIAIgGIALgFIAGgEIgHADIgDAAIAEgEIACABIAGgEIAAgCIADgDIAOgJIACAAIAEgCIADAAIgCADIgFADIACABIgLAHIAAABIgEAHIAJgEIgCAFIgHADIgEAGIABABIAYgPIABgCIAEgDIAEgBIgCgCIAAgCIgCABIgEAAIACgDIAEgCIACABIAEgDIgDAAIgDgBIAXgMIAKgDIAIgBIgOAGIgKAHIgDAEIADgBIADgEIAFgCIACgDIAGgDIAEgCIADAAIAFgCIAFAAIgGAGIgFACIgDADIACAAIAEgDIACABIADAAIADgCIAFAAIACABIgCACIACAAIgBACIgBADIAGgBIACABIgEACIABAAIADAAIgBACIAEAAIADACIgEACIAEABIAAACIgDABIgCACIAFABIgEACIgEAAIgDAEIAHAAIgBAFIAEAAIADABIADABIACADIgBACIAHAAIgBAEIgDACIgEAAIgCADIgHACIgEAGIgFgBIgBgFIgFgIIgIAFIACAIIAGACIgDAHIAEADIgGAFIgCAFIgRgMIAAAEIAIAKIgCADIgFgCIgJAAIgCgGIgGAAIgBgEIABgEIgCgGIgIgCIgCABIgEADIgFAAIgFgBIAEgEIAIgEIAEAAIADABIAIgCIABgEIARgKIADgEIAAgEIgDgBIACgEIgCgBIABgDIgCAAIACgEIgDAAIAAgEIgCABIgBADIgJABIAAgCIgEAAIgCACIgFAAIACADIABABIgBAEIgGADIgDABIgEAFIgBADIgLAGIgFADIgEAAIgBADIgEACIgDgBIgCADIACABIAAAEIAFAAIgDAFIAFABIgFAFIgEAAIgCgCIgDAAIgFAAIgFAEIgDABQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBIgFAAIADgDIAFgCIAHgIIAMgJIABgCIgEAAIAAADIgHAEIgFACIgCgCIgDgCIgDAAIACADIgBACIAEAAIADABIgFAEIgDACIgEADIgEABIgCgCIgGAEIgDABIgEgCIgFgBIADADIADABIgCAEIgOAHIgWAQIgKAMIgBAEIACACIgEAKIgCAFIALgDIAGAIIAAAEIAHACIABADIAHAAIAIABIgFAHIgGAPIACAHIAAAJIAIgCIAGgGIAEgFIABgFIAEgKIAAgIIAIgBIAIgFIAHgHIAFgJIADgHIgDgEIgCgDIAFgDIADgGIAEAAIABgGIACgEIAGgHIAAgEIAFgEIAHAAIACACIAGAAIAEgCIAFAFIABAEIADADIAHABIgHANIgFAHIAGgCIADADIAAAEIAFAAIAGgEIAHgCIACgGIAKgHIAAAFIACAMIAGANIgBADIgEAAIABAEIAHAIIAIACIAFADIAGABIgFADIgSAFIgEAEIAEACIANgHIAJAAIAAAEIAIABIgBAGIgDADIACADIgDADIgGACIgMABIgIAHIgIAFIgIAAIgIgBIgbABIgHACIgEAGIgIABIgHAFIgEAFIgLAAIAHADIgDADIgNAMIAZgRIANgHIALgDIAJAAIgBAIIgIAGIABAKIAGAGIAGADIAKAAIAHgJIAIgCIgCAGIgHAFIgHAHIgHACIgQAGIgFACIgFAEIgEgCIABgGIAGgEIALgBIAEgCIgGgCIgNAAIgGAGIgJAFIgJgBIgCAFIgGAAIgIAIIgCALIAAAFIgIABIgIAEIgKAAIgHANIgDAEIgJAOIgDgHIgGADIABAFIgCAFIACAFIADAKIgGADIgDAGIgHAEIgRAOIgHADIgJASIgDARIADALIAAAMIACAJIgCAHIgDAEIgEgBIAAgHIgDgDIgBgFIgEgEIAAgFIgCgFIABgIIgHgNIgDABIgDAEIgDAAIgDgHIgJgBIgGACIgHAAIgDAIIAAAFIgKABIgCgGIgFACIgEgCIgGgBIgLANIgEAAIgHAMIABALIgDAMIgFAKIABAeIAEALIACAIIAFAFIAEAHIAIgCIAHgEIAFgBIAJgcIARgDIADADIgBAIIgEAEIAAAKIgFAPIAAAIIgEAGIAEAEIAHgEIAIACIAJgCIAHAFIADAGIAAAJIgBANIAAARIAIAKIAEAEIAeABIAEAGIgBAGIgEABIgCgFIgLgBIgCAFIABAIgAIkA/QgCgDAAgGIABgSIgHgnIAAgBIgFgNQgCgEAAgFIAAgJIgFgPQgEgJgBgGIAAgCQAAgEgLgaIgBgCIAAAFIgBAAIgBgBIgEgHQgFgIAAgFIAAgBIAAgBIgBgDIgCgCIAAgCIgBgCIgEgCIAAgBIABAAIAEABIABABIAAABIACABIABgBIAAAAIACgBIAAAAIAAgBIABgBIgBgLIAMACIgMgCIAAgCIAAgBIABgGIAAgBIgBgDIAAgBIAAgBIgBgFIAAgBIgEgKIgBgGIAAgBIgCgCIAAgBIAAACIgBAAIgDgDIgDAAIABADIABABIABAEIgFgBIgBgBIAAAAIgBgCIgCgCIgDgDIgCgBIgBABIABABIAAAEIAAABIABABIgBABIAAAAIgBAAIgCgBIgBAAIAAgBIgBgBIgBgBIgCgDIgBgBIgBgBIAAAAIgBABIACAFIAAACIAAADIgBgBIAAgBIgCgFIAAgCIgBgEIgCgBIgBgBIgBgBIAAgBIgDgFIgBgFQgBgDgDgEQgDgEgBgCIABgBIgFgIIgEgCQgDgCgDABIAAACQABAAAAABQABABAAAAQAAABAAAAQAAABAAAAIgDAAIgDgDIgCgBIAAACIABADQALAQADAAIgCgGIAFAFIAAABIgCAAQABAFAAACIgCAAIgDgCIAAABIABAFIgBAFIgBAAIgDgBIgDgGQgBgEgDgCIgCACQgGgGAAgDIABAAIABACIACAAIgDgIIgDAAIgGgOQgEgIgDgEQgBgDgGgDQgFgDgBgDIgCgCQgDAAgDgDQgWgWgFABIACAGIgBADIACAEIAFABIADAGIABAAIAGAGQADADABADIAGADIAGADIADAEQAFAFAFACIACAFQACACgBADQgBgDgEgCIgEABIAAACIACACIAEAAIABADIAAADIgDACIABAHIgFAEIACAHIgHAAIgGgFIgGgFIgBgCIAHABIAHAAIAAgDIAFgBQgDgNgigZQgBgDgDgBQgDgCgGgIQgEgGgFgCQgCAFgEAAIgDAAIAAAHIgGAAIgGgDIgBAAQgFgBgDABIADAMIAAAGIgIAAIgBACIgCABIgCADIgEAAIAAADIAAAIIADAIIACAGQgRAFgUANIACAAIgBACIgGgGIgGgEIgGgBQgEgBgDAAIgFAAQgBgGABgDIgBgBIAAgDIgCgCQgEgIAEgFIAAgCIgBgKQgDgDgCgHQgCgHgBgCIAAgCQAFAAADgBIAAgCIABgBIACABIAHACIAPAAQADAEAKACIACAAIAFgDIAAgBQAGgHgQgUIgEgJIgKgHIgCgBQgDACgFgFIgBgBIgBgCIAHgDIAEACQAEACAFgBIgBgCIAAgBIgCgEIgBgBIgCgFIAEACIABACIAKABIgBgFQADgBADABIgDgKIAEABIABAAQAEgHADAAIgDgFIgDgCIAAgCIABgBIABABIACAAIACABQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBIACgCIABgCIAGABIACAAIADAAIACAAIgCgEIgFgFIgBgDIgBgCIgLgNIACgBIAAgCIgBgBIgCgCIAEgCIgBgFQACABADAGQACAFAFgBIABADQAAAEADABIAAgBIAAgBIAEgCIACACIAGALIgBABIgGgDQgBAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAABIADAEIACAAQADADADABQAAAAABAAQAAAAAAgBQAAAAAAAAQABAAAAAAIgCgDIACgBIACABIACAAIAAgCIADABQAGAIADgEIAEABIADgHIAKAGIABAAIgEgDIgCgEIAJABIgBgBQgHgGgHgSIACAAIACADIABAAIAHAFQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQgHgIgFgBQAAABAAAAQABABAAAAQAAABgBAAQAAAAAAABQgFgBgCgEIADgBIgBgBIgBAAIgBgBIgBAAIAAAAIgBgBIAAgBIAAAAIABAAIACABIACABIABAAIABABIgBgBIgCgDIABgBIACABIAAgBIABgBIACABIABgBIAGADIgCgHIADAAIgBgBIgBgBIgDAAIgFgEIAAAAIAAABIgGABIAAABIgEAAIAAACIAAAAIgVgOQgIgIgHgNIABAAIABAAQAAgCgHgGIACAAIgFgEIgGgDIAAABIgEgEIgBAAIgCABIADAEIAAABIAGAEQADACABAEIgBAAIAAABIACADIgCABIABAEIgBAAQABAAAAABQAAAAAAAAQAAABABABQAAAAABABQABAAAAABQAAABABAAQAAABAAAAQAAABAAAAIAIAKIAJAIQAEgBACADIABABIADAHIgBAAIgBABIAAABIAAABIAAAAQABAEAFAGIAAACIAEACIACAAIADADIgFAAIAEAEIgCAAIAAACIgDgBIgCAAQAAACACAEIgGAAIgDgDIgBgBIgBgDIgCgCQgDgBgEgFIgBgDIgFgDQgEgCAAgCIAAgBIgGgGIgBAAQgDgGgFgBIABADIgBAAIAAABIAAADIAAABIABACIgBABIgBAAIAAABQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAgBAAIgDgBIgCABIgDgDIgBAAIgCAAIgBgBIgCgCIAAgBIAAAAIAAgBIgCgDQgEgBgBgCIAAgBIgCgDIABgBQAAgBgBAAQAAgBAAAAQgBAAgBAAQAAAAgBAAIgCAAIgCgDIAAgBIAAgBQgDgDgCgCIABgBIgDgDIABgCQAEAAgEgEIAAgBIABAAIABgDIACAAIAAgBIgCgCIgBgCIACAAIADACIABgBIgCgDIABgDIABAAIAAgCIgDgCIgDAAIgBgCIABgBIAAgDIABABIgJgPIABAAIgGgHIABAAIAAgBIACAAQgCgBgEgBIgBACIAAABIgBAAIAAACIgCgBIAAgBIABAAIgCgCIAAgCIABAAIgDgDIACAAIgDgDIAFADIAGACIgHgEIgCgBIABgBIgBgBQAEADABAAIgIgGIgCgCIAOAGIgHgEIABAAIAGABIABAAIgEgCQgFgBgDgDIABgBIADABIADACIAAAAIgDgDIABAAIgBgBIABAAIADACIACABIAFADIgHgFIAEAAIADADIAEACIgFgDIALAEIADACIgBAAIADABIAFACIgBgBIAOAHIAAAAIgEgCIACAAIAGADIAAAAIAFABIADACQAWAKAKAKIAAACIgBAAIgFgDIgEgBIgOgHIAMAIIAMAIIAEAEIACAAQAMAKAFABIgBgBIACAAQgDgDgCAAIgCgBIgCgCQgDgBgEgFQAGAFAEABIADABIgLgIIAAgBIgHgGIABgBIAFADIACABIgIgFIgBgBIgFgDIgGgEIgJgGIgCgBIgDgCIABAAIACABIABAAIAMAIIgBAAIAMAHIAAAAQgCgDgFgDIgIgFIAEACIAhAXQATANAJAIIApAmIADADIAqAwIAOATIAUAdIAbAxIAQAgIAPAnIAJAdIAFAQIAAAAIAAABIAAgBIAAACIAAgBIAAgBIADANIACAKIAFAbIABAGIABABIAAABIgBgCIAAABIgBAAQgDgHgDgLQgEgSgCAAQgBAHAEALIAGASIABAKIABAAIACAEIAAgBIAAABIABAEIgBgCIgBABIAAABQAAAGACAEIAAgGIABAAIAAACIACABIgCgIIADAOIAAgCIgBgGIADAUIAAADIABAKIgBgDIAAACIABABIAAAjIAAAAIgBALIgBgBIgDAMIgBAEQgDACgBAHIgBADIgBgBIgDAAIgDAIgAlogHIAAgBIAAgDIgFgCIgCAAIgBgBIgBgEIAJAAIADACIAEABQAAAAAAABQAAAAAAABQAAAAAAABQAAABAAAAIAAABIgDADgAk9gJIgEAAQgCAAgEgHIAAgMIAGgBIANABQADAAAEADIADACIADACIAGAAIADgDIACAAIAFACIAEAAIALgCIAAAFQAAABABAAQAAABAAAAQABAAAAAAQABAAAAAAIAAABIgDACIgEAAIgJgCIgDAAQgEACgKAAIgFABIgGgBIgGACIgDADIgBABIgCgBgAlzgoQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBAAgBAAQgDAAgFgCIgBgDQAAgCgDgCIgDgCIgGAAIgGAEQgGAEgFgFQgEgGAFgFQAAgBAHAAIAGAAIAEAAIADgBIAHgBIADACIAEAEIAJAGIAEAGQADABADgBIAGAAIADAAQAHAAAFAMIgYAAQgGAAgDgGgAIxg4IgBgJIABAJgAiSkxQgCgDgDAAIgYAAIAAgDQAAgBAAgBQAAAAABgBQAAAAAAgBQABAAAAgBIASgQIACgFIACgEIAEgCIADAAIAAACQACACgDADIgEACIgDAFIADACIAGAAIACACIAGAFIAEAAIACADIgCABQgDAEAAAFQABAFgDADIgCABQgFgCgDgFgAjKlAIgCgBIgBgCIgCgCIgBgBIgBgDIgDgBIAEgCIACAAIACACQAAAAAAABQAAAAABABQAAAAABAAQAAABABAAIADAAIADABIAAABQgEAFgCAAIgBAAgADnlGIADgDIgBgEIADgBIAAgBQACgCAFABQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAgBgBIgKgBQgFACgBgGIADAAIABgCIABAAQAAgBAAAAQAAgBgBAAQAAgBgBAAQAAAAgBAAIgEgBIgBgCIACAAIAAgBIABgCIABAAIABABIAEABIADAAQABAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBgBIgBgDQgDgBgCgEQgCgEgCgBIAAABIgHAAQgBgBAAAAQgBgBAAAAQAAgBAAAAQABAAAAAAQACgDgGgFIABADIgDAAQgBgBgBgBQgBAAAAAAQgBgBAAAAQAAAAAAABIgDAAIgCgDIAEgBIgCgEIgBgCIAAgBQgDgBgBgBIgCgDQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAABAAIAGACIgCgFIgCgFIAGAAIADAAIACABIgBADIABADIgBACIAMAAIADAGIAAAEIAAACIgBAAIAAACQgDAEAIAAIAFADIACADQABACAEADIACAAIAFAEIADAGIADAAQAFAJACgBIAAgDIAAgBIAIAHIABADIgCAAIABADIgCAAIAAABIAAABIAEAFIgBABIgCAAIgBADIgFAAIgBAAIgHgDIAAAAQABAEgLgCIABAEIgDAAIgEgBIAAABIgBABIgDAAIgCAAgADJlVIgDABQgBgBAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQgCgEABgCIAEAAIgCgFIgFAAIgDgKIACAAIACAAIACAAIABgBIABAAIgDgHIADAAIAEADIABgBIAAgCIADgBIABABIACABIABAAIABABIACADIACACIACACQABACgEAAIACADIADAJIgCACIADADIAAACIgLAAIAAABIAAACQgBAAAAABQAAAAgBAAQAAAAAAABQgBAAAAAAgAC9mOIAAgCIAAgCIAAgCIABAAIACgCIACAAIAAACIAAACIABAAIAAABIgDAAIAAAAIAAADIgBAAgAg0moIgFgDQgDgCAAgDIgDAAIAAAAIgDABIgDAAQgGAAgGgMIgHgRIAFgCIACgFQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAIgEACQgBgBACgIIADAAIAAgCIAAAAIgCgBQgDACgCgBIgCgDIAAgBQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAQABAAAAgBQAAAAgBAAQAAgBAAAAQgBAAgBAAQgBgBgBAAIAAgCIAAgBIAGgDIABAAIADgEIACAAIACAAIADgCIAEAAIABgCIgBgDIAAgBIACgCIAAgBIgBgBIgDAAIgEgBIgCAAIgBAAIACABIAAAAIADABIgBADQgDAAgEACIgBAAQgBgCgEgBIAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQABgBABAAIACgCIgBgBQAAgCAIAAQAAABAAAAQABAAAAAAQABABAAAAQABAAAAAAIAGAAIAAgBIAAgBIgCgCIAAAAQgEAAABgEQgFAAAAABIgFABIgBgBIgBAAIgBAAIAAgBIAAgCIACAAIABgDIACAAIACgCIgCAAIACgBIABgCIAAgDIAAAAIAAgBIAAgEIAAAAIAAAAIAAgDIAAAAIAAAAIgBAAIAAgBIABgDIAAAAIAAAAIgBgBIAAgBIgCAAIAAAAIgDAAIgBgBIgCAAIAAgBIgBAAIgBAAIAAABIgDAAIAAAAIgCAAIAAAAIgBAAIgBAAIAAAAIgCAAIgBAAIgCABIgCAAIAAAAIAAgBIgBAAIABAAIAAgBIAAAAIAAAAIAAgBIACAAIgCgBIAAAAIACgCIACAAIACAAIAFAAIADgBIAAAAIADgBIgEAAIgCAAIgCAAIAAgBIgCAAIAAAAIAAAAIADgDIADAAIAAAAIABAAIAAgBIACAAIADAAIADAAIACgBIAEAAIABgBIADAAIABAAIAEgCIAAAAIABAAIACgBIgEAAIACAAIAAgBIACAAIADAAIAAgBIACAAIAFgBIACAAIgDAAIgQADIgDAAIAAAAIgDABIgDABIgBAAIABgBIgCAAIgCABIgGABIABgBIgBAAIgKADIAFgBIABAAIAAAAIgDACIgCAAQgGADgDAAIgCAAIgHADIgDAAIgEACIAEgBIgCABIgKADIgCAAIgCABIADgCIgCAAIgEABIAAgBIgFAAIgGABIABAAIAEgCIARgGIgBABIAAABIADAAIAHgCIACgBIgCABIgHABIACgBIAFgBIgFAAIACgBIAIgCIACAAIADAAIAAAAIgDACIAEgCIAEgBIgBAAIAAAAIACgBIABgBIAJgCIACAAIAAAAIgEACIAAAAIACAAIgBAAIAEgCIADAAIABgBIABAAIAFAAIgCAAIgIABIADgBIAAAAIAAgBIAAAAIAHgBIABAAIADgBIAFAAIAJgBIgCABIAFgBIgBAAIAEAAIARgBIgCABIAAAAIgIABIgDAAIgCAAIADAAIgBABIABAAIAAAAIABAAIACgBIACAAIABAAIACAAIAAgBIABAAIAAABIAAAAIABAAIAAAAIAAAAIAAgBIADAAIAAAAIAEAAIAAAAIAAAAIABAAIABAAIAAAAIAAABIABAAIAAAAIABAAIAAgBIADAAIAAAAIACAAIAAABIABAAIAAgBIgBAAIAAAAIAAgBIABAAIAAABIABgBIAFAAIABAAIABAAIADAAIAAAAIAGAAIADABIADAAIgEAAIgEAAIAAABIABAAIAAAAIAGAAIABAAIACAAIgBAAIACAAIABAAIAEADIgBgBIABgBIABAAIACAAIgBgBIABAAIAFABIACAAIAAABIABABIgCAAIAAAAIADAAIABABIABABIgBAAIACACIABABIAAABIAAAAIgBAAIADACIAAABIADACIAAgBQABAAAGABIgBABIgCAAIACABIACAAIADABIABAAIAAABIAGAFIgBAAIgEgDIAAgBIgEgBIgBAAIgCABIABAAQACACAFABIABABIACABIACACIgCABQADADAGADIgCAAIgCgBIAAABQgBABgEgBIAAABIAFACQABAAABAAQABAAAAABQAAAAABABQAAAAAAABIgEgBIgCAAIAAABIgEAAIgBgCIgEAAIAAABIAEABIgCABIADABQAEgDACAEIAAACIADADIgBgBIgCABIgEgDIgBABIADADIAFADIAIAGIgFABIgBACIAAAAQgBAAAAAAQAAAAgBgBQAAAAgBAAQAAgBAAAAIgEgDIgIACIAAABQACADAGABIABAAQADAAADACIABAAIABgBIABgBIABAAIAAABIgCADIgFAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBABAAABQAAABgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgDABIgEABQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAABQgBAAAAABQAAAAgBABQAAAAgBAAQAAAAAAAAQgGgCgCABIgDgBIgBAAIAAgBIgBAAIAAAAIgBAAQAAAAAAABQAAABAAAAQgBABAAAAQAAABgBAAIAAACIgCABQAAAAgBABQAAAAAAABQAAAAgBAAQAAABgBAAIgEAFIAAABIgEAAIgCAAQgEAEgEABQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAIgDgBIAAAEIgHAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAIgHABIAAABQACACAAADIAAABIgBAGQgDACgCAEIgDAAIgCAAQgBAAAAABQgBAAgBAAQAAAAAAABQAAAAAAAAIABACQAEADgDAFIgFAJIAAACQAAADgFAAIgDAAIgDAAgAkBm6IAFgDIAEABIgCAEIgCACIgDABIgFABgAkPm5IgBgBIADgCIAFgCIACAAIACgCIgBACIAAABIgIAEgABinEQgFgEgDAAIgLAAIgCgCIgCgEIgBgBIgGAAIgCgDIAMAAIgBgCIgFgDIgHABQAAgBgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIADgBIAIABIgBgCIADgBIACADIABACIAAACIAFAAIACgBQACgCAEAAIAGACQAEgEADAAIAEAAIAEAHIAEABIADACIACAEIgKABIgCACQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIgBAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBABQAAAAAAABQgBAAgBAAQAAAAgBAAIgFAAgAjPnlIABgDIAHgEIAHgBIgCAEIgEADIgGABgAksnpIAHgEIAGgBIgEADIgIADgAkynqIABgCIAHgEIgFAAIAHgEIAHgDIACAAIADAAIAFgEIgBAAIgGABIACgCIALgEIADgBIgDAAIgDABIADgBIgBAAIADgCIAFgCIAEgBIAIgEIAKgDIABAAIgBAAIgGADIgCABIAAAAIAGgCIgBABIABAAIgJAEIADgBIACgBIACgBIAHgDIABAAIgMAHIgCABIAAAAIADgBIAQgJIACAAIgBACIgFADIgIAEIgDACIgGAEIgEADIAAACIgBACIgEACIgFACIgCACIgGADIgCABIgCAAIABgDIgDAAIACgBIgDABIgGADIgEABIgFACIgEABgAkYoAIADgCIAjgQIAIgCIAAAAIgCABIgBABIAEgBIgFADIgQAGIgGACIgCACIgJADIgKAFIgBAAIgHADgAjqoHIAAgBIACgDIAFgCIABAAIgCACIAIgDIAGgEIAEgBIAAABIABAAIADgCIACgBIgCACQgEADgGACIgEAEIgEACIgGADIgEABIgGACQAAgBAGgEgAkPoDgAjVoNIARgIIAFgBIAAABIACAAQABABgIADIgKAFIgBgBIgGADIgIACgAiqoOIADgDIAFgDIADAAIAGAAIAAADIgKADgAjnoQIAFgBIgEACgAjhoVIABAAIALgEIgBAAIgEABIAAgBIgBAAIAFgCIAAAAIAAAAIAJgDIgFACIAQgFIgCABIABAAIgCABIgIADIACAAIAFgBIAIgEIAJgCIABAAIgNAEIgBABIAEgBIABAAIgRAGIgCAAIgBAAIgDABIgMADgAiuoYIACgCIgIACIABgCIADgCIAGgCQAHgEAIgCIACAAIgDACIgGACIgCACIADAAIABAAIAPgCIABAAIABABIgDADIgFABQgCACgIAAIABgBIgDABIgIABgAi7oZIgCAAIADgCIAFgCIAHgBIgEABIgBACIgJADgAi9odIADgBIgCAAIgCABIABgBIAIgEIAHgCIgCABIgGADIgEABIAKgDIABAAIgFACIAAABIAJgFIACAAIgDACIADgBIgTAIIgBAAIgCAAIgEABgAjEocIgBABIgFABgABuokQgGAAAAgCIACAAIAAAAIgFgCIACABIgCAAIgBAAIgEgCIAAAAIABAAIgEgCIgBAAIABABIgBAAIgFgCIgBAAIADABIAEACIAAAAIgHgCIAEABIgLgDIABAAIgMgDIAAAAIABAAIAEABIABAAIgEgBIADAAIAFACIAFABIgKgDIgDgBIABAAIASAEIgBAAIATAFIABAAIAKACIACABIgBAAIADABIgBAAIgGgCIACACIAAAAIgUgHIgCAAIAKADIgBAAIASAIgAinoiIAEgCIAEgCIAEAAIgBAAIACAAIgEACIgHACgAi8oiIADgCIAAABIgDABgAiTonIAFgCIAEgBQgDADgEAAgAirooIABAAIgBAAgAiTorIgCAAIgCAAIACAAIgBAAIAEgBIACAAIAGgCIgCAAIAIgCIABAAIgCABIgCABIABgBIgBABIgCABIgFABIgCABIgIACgAiAotIgEABIAAgBIAKgDIABAAIAGgBIgCAAIgCABIgBAAIABgBIAFgBIgBAAIANgCIACAAIAHgCIABAAIAEAAIgBAAIAFgBIgFABIgBAAIABAAIgKACIACAAIgEABIgDABIgBABIgJACIAAgBIgDABIAAAAIgEABIgEABIAAAAIgDABgAg+o5IABAAIgCAAg");
	this.shape.setTransform(5.3062,-3.6549,2.387,2.387);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F0F6F8").s().p("Ah1I7IgLgCIgBgCIgVgKIAAgBQgDgBgBgCIgDAAIgCgBIAAgBIgJgGIgCgDIgEgDIgCgCQADgCACAAQgDgDgFgDIgJgEIAAgDIgCgDIAHADIgIgHIgDgDIABAAIADADIAEADIgHgMIgEgGIAAgDIgCgDIgEAAIAHAKIgDAAQgEgBgCgGQgCgGgCgCQgDgDgEgIQgEgIgEgEQABgKgBgCIgBgCIgDgEQACgHgDgGQgCgGgKgPIgBgCIgDgWIgCgIIAAgIIgBgCIgBgCIgCgFIgBgEIAAAAIgBgDIgBgDIAAgBIgCgFIAAgDIgDgGIAAAAIgGgXQgIAAgJgMQgJgLgJABQgLABgHgLIgLgTIgFgIIgGgJIgBgFQgBgHgNgKQgMgKgCgIIAAgDQgDgDABgFIABgJQABgCADgBIACgCIgBgEIgIAAIgDgRIAGgBQgCgJAHgDIAAgEIAEgDIgBgHQAEAAAAgCQABgCAAgLQAGgFgDgHIgFgNIgCAAQgDgFAFgHQAFgHAAgDQAGgCABgCIAAgMIAHgBIAKgHIAKAAIAAgGQACgCADgBIAEAAIACACQgQAMANAVIACgCIgDgPIALgLIADgCQADABAIAFQADACAAAEIAGABIAKABIAGACIAEAGIADAAQADgHACgDIAGABIACABIAEgEQADABAFACIgBADIgCABQAAAGACACIAIgDIADAAIABAFQAAACAEACIADACIAMAHQAAANAXAFIAEAAIAGgBQAFgBACABIAQAGQACAGAKACIAEAKIACAMIAFAAQADAHgDAKQgDACgEgBIAAAIQAFABABgCQABgCAAgFIAEAAIACAAIALADIABADIgCACIgDAEIAAAFIAIAAIAAgJQAEgBAHADIADABQANACAKAJIgFADIAAACQAHADADgCIAAgDIAFgBIALAEIANAAQAFgBACAAIAIAFQABAHACABQACACAKADIAJAAQAJAEABAUQAAADgDAHIgNARQgDAEgDAAQgLAOgCABQgCAEAAAHIAAAFIABAHQAAAEgDAHIgBAEQgDAOgCABQgDAGAAAFIgFAEQgCAIgFACIgCAFIgUABIgGAFIgJAAQgEAEgKAMQgCAEADAGQADAHgBADQgBACgDADQgDACgBADIgGAMIgDAAIgBgGQgFAEgFAXQgBAEgFAAIgTgDIgFAAQABACAEADIAGAEIABAEIACAAIACAEIgBADIgDAFQgCAEAAADIgDgBIgGAAIgDABIgKABIABADQADAEAAADIABADIABACIgGAAIgFgCIgDAAIACADQADAFACABIADgBIAAAAIABAAIACACIAAADIgEAAIACAHIADAIIgFAAIgCACIABADIAJAHIADABIADACIgBACIACAGIgCACIADAEIgDABIAEAFIAIAHIACACIAJAGIAEACIAIADIgBABgAjCH/IABABgAEfHDIACgDQAAgBAAAAQABAAAAgBQAAAAgBAAQAAAAAAAAQACgEAFgDIACgCIAUg2IAKgQQACgKAEgHQgBgJABgKQACgUAKgHIAYgoIgBgHIACgHQAGgJgCgPQgCgVAAgEQgDgCgBgFIgBgJQgDgBgCgDQACgDADgBQAIgcADgIIACgMIgXgBQgGgCgBgDIgBgOQgEgDgHADIgGADIgBAAIgMgBQgFACgEAHIgQAAQgDgBgCgDIgMAAQgJgBgFACIgDAHQgKABgDgEQgFgEgKgVQgVgCACgVQgIgFgLgNQgIgMAAgCIAAgHIgEgOQAIgHAAgDIAAgEIAAgWIAEgKIgEgDIgMgCQgBgDAAgFIABgDQAGgCACgDQABgFAAgOIAGgCIADAAIAIgSQAIgSACgBQANgBABgOQADgBAHAAIAAgHIAAgZQAFgDAHABIgCgPIALAAIAAgIQAAgGABgDIAEACQAEAFAJgBIACAAIAEABIAEABQAEgDAIABIACgHQAHgDAIABIABgDQALgCADAAQADABAGAFQADgBABgDIAWgCQAEABAFAEQgCADgDABIAAAEQAFAEABAKQABAKAFADQADADAKAEQAJADAFAEIADAHIALACQAFABAFAIIAFAAIACgBIgEgXQAKABAOAIIAXANIABAAIACgDIACAAQAUAaAMAwQAGAZADATIAAAFQgBANAHAXQAIAYAAAMQABADAAAMIACACIAEAAIAEgBIABgDQADACgBAFQgDAXgEAKQgDAKgPAjQgFAMgOAWQgOAVgFAMIgBACQAAAGgGAMQgEALgBAHIgQAjIg/BNQgOANgfAVQgfAWgOANQgGACgEgBIgHACIgKAAgAGiGMIgBgBIACgCIgCAAIAAgBIAIgLIAHgKIAMgPIAAAAQAHgFAGgPIAKgNQABgCADABIADgEQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAAAIAPgWQAAAEgMAVIgGAJIgEAHQgqA8gKACgAmNBSQgBAAgBAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgCgBgHgJIgEgCIgEACIgDgEQABgEgCgEIgLgVIgFgDIAAAFIgIgDIgDgIIgDgBIgJAAIgEgHIgHgJIgGgEIgGABIgBAEIgFABIgHgDIgRgMIgHgHIgGgDIgJgQIABgGIADgEIgDgEIgBgKIgDgKIgEgPIgEgFIABgIIgCgGIgCgHIgCgJIgBgMIACgJIAAgFIgDgDIgCAAIgCALIABAHIgBAKIACACIAAAIIABAFIAAAQIACAFIAAAHIACADIABAHIgBAGIgDADIABgGIgCgFIgCgGIgCgDIAAgEIABgFIgCgHIgFgKIAAgFIADgFIAAgFIgCgMIAEgdIAAgGIgCgEIgBgFIgCABIAAgHIACgHIAAgFIAEgMIAAgFIACgHIADgJIABgFIAHgPIAHgRIADgDIAagvIACgHIACgEIABgDIADgFIABgBIAAACIgBADIABAAIgEAGIAAACIgBADIgDAEIgEALIAKgRIADgJIACgEIAAgBIACgGIADgFIADgGIAGgHIgBgBIASgWIAAAAIABgCIAEgEIACgDIAEgFIABgBIAHgIIgBACIAIgIIArgmIAbgVIAwgfIgCACIACgCIASgJIAGgDIgNAHIAAABIAJgFIgJAFIAIgDIABgBIAAABIgDADIgCADIACAAIgEADIgIAFIAFABIAGgCIgBACIgJAIIAOgLIAPgGIgCAEIABAAIABADIAIgBIAFgEIAGgCIACgFIAGgCIAHgEIgBADIgHAGIgDAAIgEAEIABAAIgGAFIgBADIAIgGIALgFIAGgEIgHADIgDAAIAEgEIACABIAGgEIAAgCIADgDIAOgJIACAAIAEgCIADAAIgCADIgFADIACABIgLAHIAAABIgEAHIAJgEIgCAFIgHADIgEAGIABABIAYgPIABgCIAEgDIAEgBIgCgCIAAgCIgCABIgEAAIACgDIAEgCIACABIAEgDIgDAAIgDgBIAXgMIAKgDIAIgBIgOAGIgKAHIgDAEIADgBIADgEIAFgCIACgDIAGgDIAEgCIADAAIAFgCIAFAAIgGAGIgFACIgDADIACAAIAEgDIACABIADAAIADgCIAFAAIACABIgCACIACAAIgBACIgBADIAGgBIACABIgEACIABAAIADAAIgBACIAEAAIADACIgEACIAEABIAAACIgDABIgCACIAFABIgEACIgEAAIgDAEIAHAAIgBAFIAEAAIADABIADABIACADIgBACIAHAAIgBAEIgDACIgEAAIgCADIgHACIgEAGIgFgBIgBgFIgFgIIgIAFIACAIIAGACIgDAHIAEADIgGAFIgCAFIgRgMIAAAEIAIAKIgCADIgFgCIgJAAIgCgGIgGAAIgBgEIABgEIgCgGIgIgCIgCABIgEADIgFAAIgFgBIAEgEIAIgEIAEAAIADABIAIgCIABgEIARgKIADgEIAAgEIgDgBIACgEIgCgBIABgDIgCAAIACgEIgDAAIAAgEIgCABIgBADIgJABIAAgCIgEAAIgCACIgFAAIACADIABABIgBAEIgGADIgDABIgEAFIgBADIgLAGIgFADIgEAAIgBADIgEACIgDgBIgCADIACABIAAAEIAFAAIgDAFIAFABIgFAFIgEAAIgCgCIgDAAIgFAAIgFAEIgDABQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBIgFAAIADgDIAFgCIAHgIIAMgJIABgCIgEAAIAAADIgHAEIgFACIgCgCIgDgCIgDAAIACADIgBACIAEAAIADABIgFAEIgDACIgEADIgEABIgCgCIgGAEIgDABIgEgCIgFgBIADADIADABIgCAEIgOAHIgWAQIgKAMIgBAEIACACIgEAKIgCAFIALgDIAGAIIAAAEIAHACIABADIAHAAIAIABIgFAHIgGAPIACAHIAAAJIAIgCIAGgGIAEgFIABgFIAEgKIAAgIIAIgBIAIgFIAHgHIAFgJIADgHIgDgEIgCgDIAFgDIADgGIAEAAIABgGIACgEIAGgHIAAgEIAFgEIAHAAIACACIAGAAIAEgCIAFAFIABAEIADADIAHABIgHANIgFAHIAGgCIADADIAAAEIAFAAIAGgEIAHgCIACgGIAKgHIAAAFIACAMIAGANIgBADIgEAAIABAEIAHAIIAIACIAFADIAGABIgFADIgSAFIgEAEIAEACIANgHIAJAAIAAAEIAIABIgBAGIgDADIACADIgDADIgGACIgMABIgIAHIgIAFIgIAAIgIgBIgbABIgHACIgEAGIgIABIgHAFIgEAFIgLAAIAHADIgDADIgNAMIAZgRIANgHIALgDIAJAAIgBAIIgIAGIABAKIAGAGIAGADIAKAAIAHgJIAIgCIgCAGIgHAFIgHAHIgHACIgQAGIgFACIgFAEIgEgCIABgGIAGgEIALgBIAEgCIgGgCIgNAAIgGAGIgJAFIgJgBIgCAFIgGAAIgIAIIgCALIAAAFIgIABIgIAEIgKAAIgHANIgDAEIgJAOIgDgHIgGADIABAFIgCAFIACAFIADAKIgGADIgDAGIgHAEIgRAOIgHADIgJASIgDARIADALIAAAMIACAJIgCAHIgDAEIgEgBIAAgHIgDgDIgBgFIgEgEIAAgFIgCgFIABgIIgHgNIgDABIgDAEIgDAAIgDgHIgJgBIgGACIgHAAIgDAIIAAAFIgKABIgCgGIgFACIgEgCIgGgBIgLANIgEAAIgHAMIABALIgDAMIgFAKIABAeIAEALIACAIIAFAFIAEAHIAIgCIAHgEIAFgBIAJgcIARgDIADADIgBAIIgEAEIAAAKIgFAPIAAAIIgEAGIAEAEIAHgEIAIACIAJgCIAHAFIADAGIAAAJIgBANIAAARIAIAKIAEAEIAeABIAEAGIgBAGIgEABIgCgFIgLgBIgCAFIABAIgAIkA/QgCgDAAgGIABgSIgHgnIAAgBIgFgNQgCgEAAgFIAAgJIgFgPQgEgJgBgGIAAgCQAAgEgLgaIgBgCIAAAFIgBAAIgBgBIgEgHQgFgIAAgFIAAgBIAAgBIgBgDIgCgCIAAgCIgBgCIgEgCIAAgBIABAAIAEABIABABIAAABIACABIABgBIAAAAIACgBIAAAAIAAgBIABgBIgBgLIAMACIgMgCIAAgCIAAgBIABgGIAAgBIgBgDIAAgBIAAgBIgBgFIAAgBIgEgKIgBgGIAAgBIgCgCIAAgBIAAACIgBAAIgDgDIgDAAIABADIABABIABAEIgFgBIgBgBIAAAAIgBgCIgCgCIgDgDIgCgBIgBABIABABIAAAEIAAABIABABIgBABIAAAAIgBAAIgCgBIgBAAIAAgBIgBgBIgBgBIgCgDIgBgBIgBgBIAAAAIgBABIACAFIAAACIAAADIgBgBIAAgBIgCgFIAAgCIgBgEIgCgBIgBgBIgBgBIAAgBIgDgFIgBgFQgBgDgDgEQgDgEgBgCIABgBIgFgIIgEgCQgDgCgDABIAAACQABAAAAABQABABAAAAQAAABAAAAQAAABAAAAIgDAAIgDgDIgCgBIAAACIABADQALAQADAAIgCgGIAFAFIAAABIgCAAQABAFAAACIgCAAIgDgCIAAABIABAFIgBAFIgBAAIgDgBIgDgGQgBgEgDgCIgCACQgGgGAAgDIABAAIABACIACAAIgDgIIgDAAIgGgOQgEgIgDgEQgBgDgGgDQgFgDgBgDIgCgCQgDAAgDgDQgWgWgFABIACAGIgBADIACAEIAFABIADAGIABAAIAGAGQADADABADIAGADIAGADIADAEQAFAFAFACIACAFQACACgBADQgBgDgEgCIgEABIAAACIACACIAEAAIABADIAAADIgDACIABAHIgFAEIACAHIgHAAIgGgFIgGgFIgBgCIAHABIAHAAIAAgDIAFgBQgDgNgigZQgBgDgDgBQgDgCgGgIQgEgGgFgCQgCAFgEAAIgDAAIAAAHIgGAAIgGgDIgBAAQgFgBgDABIADAMIAAAGIgIAAIgBACIgCABIgCADIgEAAIAAADIAAAIIADAIIACAGQgRAFgUANIACAAIgBACIgGgGIgGgEIgGgBQgEgBgDAAIgFAAQgBgGABgDIgBgBIAAgDIgCgCQgEgIAEgFIAAgCIgBgKQgDgDgCgHQgCgHgBgCIAAgCQAFAAADgBIAAgCIABgBIACABIAHACIAPAAQADAEAKACIACAAIAFgDIAAgBQAGgHgQgUIgEgJIgKgHIgCgBQgDACgFgFIgBgBIgBgCIAHgDIAEACQAEACAFgBIgBgCIAAgBIgCgEIgBgBIgCgFIAEACIABACIAKABIgBgFQADgBADABIgDgKIAEABIABAAQAEgHADAAIgDgFIgDgCIAAgCIABgBIABABIACAAIACABQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBIACgCIABgCIAGABIACAAIADAAIACAAIgCgEIgFgFIgBgDIgBgCIgLgNIACgBIAAgCIgBgBIgCgCIAEgCIgBgFQACABADAGQACAFAFgBIABADQAAAEADABIAAgBIAAgBIAEgCIACACIAGALIgBABIgGgDQgBAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAABIADAEIACAAQADADADABQAAAAABAAQAAAAAAgBQAAAAAAAAQABAAAAAAIgCgDIACgBIACABIACAAIAAgCIADABQAGAIADgEIAEABIADgHIAKAGIABAAIgEgDIgCgEIAJABIgBgBQgHgGgHgSIACAAIACADIABAAIAHAFQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQgHgIgFgBQAAABAAAAQABABAAAAQAAABgBAAQAAAAAAABQgFgBgCgEIADgBIgBgBIgBAAIgBgBIgBAAIAAAAIgBgBIAAgBIAAAAIABAAIACABIACABIABAAIABABIgBgBIgCgDIABgBIACABIAAgBIABgBIACABIABgBIAGADIgCgHIADAAIgBgBIgBgBIgDAAIgFgEIAAAAIAAABIgGABIAAABIgEAAIAAACIAAAAIgVgOQgIgIgHgNIABAAIABAAQAAgCgHgGIACAAIgFgEIgGgDIAAABIgEgEIgBAAIgCABIADAEIAAABIAGAEQADACABAEIgBAAIAAABIACADIgCABIABAEIgBAAQABAAAAABQAAAAAAAAQAAABABABQAAAAABABQABAAAAABQAAABABAAQAAABAAAAQAAABAAAAIAIAKIAJAIQAEgBACADIABABIADAHIgBAAIgBABIAAABIAAABIAAAAQABAEAFAGIAAACIAEACIACAAIADADIgFAAIAEAEIgCAAIAAACIgDgBIgCAAQAAACACAEIgGAAIgDgDIgBgBIgBgDIgCgCQgDgBgEgFIgBgDIgFgDQgEgCAAgCIAAgBIgGgGIgBAAQgDgGgFgBIABADIgBAAIAAABIAAADIAAABIABACIgBABIgBAAIAAABQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAgBAAIgDgBIgCABIgDgDIgBAAIgCAAIgBgBIgCgCIAAgBIAAAAIAAgBIgCgDQgEgBgBgCIAAgBIgCgDIABgBQAAgBgBAAQAAgBAAAAQgBAAgBAAQAAAAgBAAIgCAAIgCgDIAAgBIAAgBQgDgDgCgCIABgBIgDgDIABgCQAEAAgEgEIAAgBIABAAIABgDIACAAIAAgBIgCgCIgBgCIACAAIADACIABgBIgCgDIABgDIABAAIAAgCIgDgCIgDAAIgBgCIABgBIAAgDIABABIgJgPIABAAIgGgHIABAAIAAgBIACAAQgCgBgEgBIgBACIAAABIgBAAIAAACIgCgBIAAgBIABAAIgCgCIAAgCIABAAIgDgDIACAAIgDgDIAFADIAGACIgHgEIgCgBIABgBIgBgBQAEADABAAIgIgGIgCgCIAOAGIgHgEIABAAIAGABIABAAIgEgCQgFgBgDgDIABgBIADABIADACIAAAAIgDgDIABAAIgBgBIABAAIADACIACABIAFADIgHgFIAEAAIADADIAEACIgFgDIALAEIADACIgBAAIADABIAFACIgBgBIAOAHIAAAAIgEgCIACAAIAGADIAAAAIAFABIADACQAWAKAKAKIAAACIgBAAIgFgDIgEgBIgOgHIAMAIIAMAIIAEAEIACAAQAMAKAFABIgBgBIACAAQgDgDgCAAIgCgBIgCgCQgDgBgEgFQAGAFAEABIADABIgLgIIAAgBIgHgGIABgBIAFADIACABIgIgFIgBgBIgFgDIgGgEIgJgGIgCgBIgDgCIABAAIACABIABAAIAMAIIgBAAIAMAHIAAAAQgCgDgFgDIgIgFIAEACIAhAXQATANAJAIIApAnIACACIABAAIAqAwIAOATIAUAdIAbAxIAQAgIAPAnIAJAdIAFAQIAAAAIAAABIAAgBIAAACIAAgBIAAgBIADANIACAKIAFAbIABAGIABABIAAABIgBgCIAAABIgBAAQgDgHgDgLQgEgSgCAAQgBAHAEALIAGASIABAKIABAAIACAEIAAgBIAAABIABAEIgBgCIgBABIAAABQAAAGACAEIAAgGIABAAIAAACIACABIgCgIIADAOIAAgCIgBgGIADAUIAAADIABAKIgBgDIAAACIABABIAAAjIAAAAIgBALIgBgBIgDAMIgBAEQgDACgBAHIgBADIgBgBIgDAAIgDAIgAlogHIAAgBIAAgDIgFgCIgCAAIgBgBIgBgEIAJAAIADACIAEABQAAAAAAABQAAAAAAABQAAAAAAABQAAABAAAAIAAABIgDADgAk9gJIgEAAQgCAAgEgHIAAgMIAGgBIANABQADAAAEADIADACIADACIAGAAIADgDIACAAIAFACIAEAAIALgCIAAAFQAAABABAAQAAABAAAAQABAAAAAAQABAAAAAAIAAABIgDACIgEAAIgJgCIgDAAQgEACgKAAIgFABIgGgBIgGACIgDADIgBABIgCgBgAlzgoQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBAAgBAAQgDAAgFgCIgBgDQAAgCgDgCIgDgCIgGAAIgGAEQgGAEgFgFQgEgGAFgFQAAgBAHAAIAGAAIAEAAIADgBIAHgBIADACIAEAEIAJAGIAEAGQADABADgBIAGAAIADAAQAHAAAFAMIgYAAQgGAAgDgGgAIxg4IgBgJIABAJgAiSkxQgCgDgDAAIgYAAIAAgDQAAgBAAgBQAAAAABgBQAAAAAAgBQABAAAAgBIASgQIACgFIACgEIAEgCIADAAIAAACQACACgDADIgEACIgDAFIADACIAGAAIACACIAGAFIAEAAIACADIgCABQgDAEAAAFQABAFgDADIgCABQgFgCgDgFgAjKlAIgCgBIgBgCIgCgCIgBgBIgBgDIgDgBIAEgCIACAAIACACQAAAAAAABQAAAAABABQAAAAABAAQAAABABAAIADAAIADABIAAABQgEAFgCAAIgBAAgADnlGIADgDIgBgEIADgBIAAgBQACgCAFABQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAgBgBIgKgBQgFACgBgGIADAAIABgCIABAAQAAgBAAAAQAAgBgBAAQAAgBgBAAQAAAAgBAAIgEgBIgBgCIACAAIAAgBIABgCIABAAIABABIAEABIADAAQABAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBgBIgBgDQgDgBgCgEQgCgEgCgBIAAABIgHAAQgBgBAAAAQgBgBAAAAQAAgBAAAAQABAAAAAAQACgDgGgFIABADIgDAAQgBgBgBgBQgBAAAAAAQgBgBAAAAQAAAAAAABIgDAAIgCgDIAEgBIgCgEIgBgCIAAgBQgDgBgBgBIgCgDQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAABAAIAGACIgCgFIgCgFIAGAAIADAAIACABIgBADIABADIgBACIAMAAIADAGIAAAEIAAACIgBAAIAAACQgDAEAIAAIAFADIACADQABACAEADIACAAIAFAEIADAGIADAAQAFAJACgBIAAgDIAAgBIAIAHIABADIgCAAIABADIgCAAIAAABIAAABIAEAFIgBABIgCAAIgBADIgFAAIgBAAIgHgDIAAAAQABAEgLgCIABAEIgDAAIgEgBIAAABIgBABIgDAAIgCAAgADJlVIgDABQgBgBAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQgCgEABgCIAEAAIgCgFIgFAAIgDgKIACAAIACAAIACAAIABgBIABAAIgDgHIADAAIAEADIABgBIAAgCIADgBIABABIACABIABAAIABABIACADIACACIACACQABACgEAAIACADIADAJIgCACIADADIAAACIgLAAIAAABIAAACQgBAAAAABQAAAAgBAAQAAAAAAABQgBAAAAAAgAC9mOIAAgCIAAgCIAAgCIABAAIACgCIACAAIAAACIAAACIABAAIAAABIgDAAIAAAAIAAADIgBAAgAg0moIgFgDQgDgCAAgDIgDAAIAAAAIgDABIgDAAQgGAAgGgMIgHgRIAFgCIACgFQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAIgEACQgBgBACgIIADAAIAAgCIAAAAIgCgBQgDACgCgBIgCgDIAAgBQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAQABAAAAgBQAAAAgBAAQAAgBAAAAQgBAAgBAAQgBgBgBAAIAAgCIAAgBIAGgDIABAAIADgEIACAAIACAAIADgCIAEAAIABgCIgBgDIAAgBIACgCIAAgBIgBgBIgDAAIgEgBIgCAAIgBAAIACABIAAAAIADABIgBADQgDAAgEACIgBAAQgBgCgEgBIAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQABgBABAAIACgCIgBgBQAAgCAIAAQAAABAAAAQABAAAAAAQABABAAAAQABAAAAAAIAGAAIAAgBIAAgBIgCgCIAAAAQgEAAABgEQgFAAAAABIgFABIgBgBIgBAAIgBAAIAAgBIAAgCIACAAIABgDIACAAIACgCIgCAAIACgBIABgCIAAgDIAAAAIAAgBIAAgEIAAAAIAAAAIAAgDIAAAAIAAAAIgBAAIAAgBIABgDIAAAAIAAAAIgBgBIAAgBIgCAAIAAAAIgDAAIgBgBIgCAAIAAgBIgBAAIgBAAIAAABIgDAAIAAAAIgCAAIAAAAIgBAAIgBAAIAAAAIgCAAIgBAAIgCABIgCAAIAAAAIAAgBIgBAAIABAAIAAgBIAAAAIAAAAIAAgBIACAAIgCgBIAAAAIACgCIACAAIACAAIAFAAIADgBIAAAAIADgBIgEAAIAAAAIgEAAIAAgBIgCAAIAAAAIAAAAIADgDIADAAIAAAAIABAAIAAgBIACAAIADAAIADAAIABgBIABAAIAAAAIAEAAIABgBIADAAIABAAIAEgCIAAAAIABAAIACgBIgEAAIACAAIAAgBIACAAIADAAIAAgBIACAAIAFgBIACAAIgDAAIgQADIgDAAIAAAAIgDABIgDABIgBAAIABgBIgCAAIgCABIgGABIABgBIgBAAIgKADIAFgBIABAAIAAAAIgDACIgCAAQgGADgDAAIgCAAIgDABIgEACIgDAAIgEACIAEgBIgCABIgKADIgCAAIgCABIADgCIgCAAIgEABIAAgBIgFAAIgGABIABAAIAEgCIARgGIgBABIAAABIADAAIAHgCIACgBIgCABIgHABIACgBIAFgBIgFAAIACgBIAIgCIACAAIADAAIAAAAIgDACIAEgCIAEgBIgBAAIAAAAIACgBIABgBIAJgCIACAAIAAAAIgEACIAAAAIACAAIgBAAIAEgCIADAAIABgBIABAAIAFAAIgCAAIgIABIADgBIAAAAIAAgBIAAAAIAHgBIABAAIADgBIAFAAIAJgBIgCABIAFgBIgBAAIAEAAIARgBIgCABIAAAAIgIABIgDAAIgCAAIADAAIgBABIABAAIAAAAIABAAIACgBIACAAIABAAIACAAIAAgBIABAAIAAABIAAABIAAgBIABAAIAAAAIAAAAIAAgBIADAAIAAAAIAEAAIAAAAIAAAAIABAAIABAAIAAAAIAAABIABAAIAAAAIABAAIAAgBIADAAIAAAAIACAAIAAABIABAAIAAgBIgBAAIAAAAIAAgBIABAAIAAABIABgBIAFAAIABAAIABAAIADAAIAAAAIAGAAIADABIADAAIgEAAIgEAAIAAABIABAAIAAAAIAGAAIABAAIACAAIgBAAIACAAIABAAIAEADIgBgBIABgBIABAAIACAAIgBgBIABAAIAFABIACAAIAAABIABABIgCAAIAAAAIADAAIABABIABABIgBAAIACACIABABIAAABIAAAAIgBAAIADACIAAABIADACIAAgBQABAAAGABIgBABIgCAAIACABIACAAIADABIABAAIAAABIAGAFIgBAAIgEgDIAAgBIgEgBIgBAAIgCABIABAAQACACAFABIABABIACABIACACIgCABQADADAGADIgCAAIgCgBIAAABQgBABgEgBIAAABIAFACQABAAABAAQABAAAAABQAAAAABABQAAAAAAABIgEgBIgCAAIAAABIgEAAIgBgCIgEAAIAAABIAEABIgCABIADABQAEgDACAEIAAACIADADIgBgBIgCABIgEgDIgBABIADADIAFADIAIAGIgFABIgBACIAAAAQgBAAAAAAQAAAAgBgBQAAAAgBAAQAAgBAAAAIgEgDIgIACIAAABQACADAGABIABAAQADAAADACIABAAIABgBIABgBIABAAIAAABIgCADIgFAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBABAAABQAAABgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgDABIgEABQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAABQgBAAAAABQAAAAgBABQAAAAgBAAQAAAAAAAAQgGgCgCABIgDgBIgBAAIAAgBIgBAAIAAAAIgBAAQAAAAAAABQAAABAAAAQgBABAAAAQAAABgBAAIAAACIgCABQAAAAgBABQAAAAAAABQAAAAgBAAQAAABgBAAIgEAFIAAABIgEAAIgCAAQgEAEgEABQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAIgDgBIAAAEIgHAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAIgHABIAAABQACACAAADIAAABIgBAGQgDACgCAEIgDAAIgCAAQgBAAAAABQgBAAgBAAQAAAAAAABQAAAAAAAAIABACQAEADgDAFIgFAJIAAACQAAADgFAAIgDAAIgDAAgAkBm6IAFgDIAEABIgCAEIgCACIgDABIgFABgAkPm5IgBgBIADgCIAFgCIACAAIACgCIgBACIAAABIgIAEgABinEQgFgEgDAAIgLAAIgCgCIgCgEIgBgBIgGAAIgCgDIAMAAIgBgCIgFgDIgHABQAAgBgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIADgBIAIABIgBgCIADgBIACADIABACIAAACIAFAAIACgBQACgCAEAAIAGACQAEgEADAAIAEAAIAEAHIAEABIADACIACAEIgKABIgCACQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIgBAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBABQAAAAAAABQgBAAgBAAQAAAAgBAAIgFAAgAjPnlIABgDIAHgEIAHgBIgCAEIgEADIgGABgAksnpIAHgEIAGgBIgEADIgIADgAkynqIABgCIAHgEIgFAAIAHgEIAHgDIACAAIADAAIAFgEIgBAAIgGABIACgCIALgEIADgBIgDAAIgDABIADgBIgBAAIADgCIAFgCIAEgBIAIgEIAKgDIABAAIgBAAIgGADIgCABIAAAAIAGgCIgBABIABAAIgJAEIADgBIACgBIACgBIAHgDIABAAIgMAHIgCABIAAAAIADgBIAQgJIACAAIgBACIgFADIgIAEIgDACIgGAEIgEADIAAACIgBACIgEACIgFACIgCACIgGADIgCABIgCAAIABgDIgDAAIACgBIgDABIgGADIgEABIgFACIgEABgAkYoAIADgCIAjgQIAIgCIAAAAIgCABIgBABIAEgBIgFADIgQAGIgGACIgCACIgJADIgKAFIgBAAIgHADgAjqoHIAAgBIACgDIAFgCIABAAIgCACIAIgDIAGgEIAEgBIAAABIABAAIADgCIACgBIgCACQgEADgGACIgEAEIgEACIgGADIgEABIgGACQAAgBAGgEgAkPoDgAjVoNIARgIIAFgBIAAABIACAAQABABgIADIgKAFIgBgBIgGADIgIACgAiqoOIADgDIAFgDIADAAIAGAAIAAADIgKADgAjnoQIAFgBIgEACgAjhoVIABAAIALgEIgBAAIgEABIAAgBIgBAAIAFgCIAAAAIAAAAIAJgDIgFACIAQgFIgCABIABAAIgCABIgIADIACAAIAFgBIAIgEIAJgCIABAAIgNAEIgBABIAEgBIABAAIgRAGIgCAAIgBAAIgDABIgMADgAiuoYIACgCIgIACIABgCIADgCIAGgCQAHgEAIgCIACAAIgDACIgGACIgCACIADAAIABAAIAPgCIABAAIABABIgDADIgFABQgCACgIAAIABgBIgDABIgIABgAi7oZIgCAAIADgCIAFgCIAHgBIgEABIgBACIgJADgAi9odIADgBIgCAAIgCABIABgBIAIgEIAHgCIgCABIgGADIgEABIAKgDIABAAIgFACIAAABIAJgFIACAAIgDACIADgBIgTAIIgBAAIgCAAIgEABgAjEocIgBABIgFABgABuokQgGAAAAgCIACAAIAAAAIgFgCIACABIgCAAIgBAAIgEgCIAAAAIABAAIgEgCIgBAAIABABIgBAAIgFgCIgBAAIADABIAEACIAAAAIgHgCIAEABIgLgDIABAAIgMgDIAAAAIABAAIAEABIABAAIgEgBIADAAIAFACIAFABIgKgDIgDgBIABAAIASAEIgBAAIATAFIABAAIAKACIACABIgBAAIADABIgBAAIgGgCIACACIAAAAIgUgHIgCAAIAKADIgBAAIASAIgAinoiIAEgCIAEgCIAEAAIgBAAIACAAIgEACIgHACgAi8oiIADgCIAAABIgDABgAiTonIAFgCIAEgBQgDADgEAAgAirooIABAAIgBAAgAiTorIgCAAIgCAAIACAAIgBAAIAEgBIACAAIAGgCIgCAAIAIgCIABAAIgCABIgCABIABgBIgBABIgCABIgFABIgCABIgIACgAiAotIgEABIAAgBIAKgDIABAAIAGgBIgCAAIgCABIgBAAIABgBIAFgBIgBAAIANgCIACAAIAHgCIABAAIAEAAIgBAAIAFgBIgFABIgBAAIABAAIgKACIACAAIgEABIgDABIgBABIgJACIAAgBIgDABIAAAAIgEABIgEABIAAAAIgDABgAg+o5IABAAIgCAAg");
	this.shape_1.setTransform(5.3062,-3.6549,2.387,2.387);

	this.instance = new lib.Mesh_7();
	this.instance.setTransform(-140.9,-140.85,2.387,2.387);

	this.instance_1 = new lib.Path_98();
	this.instance_1.setTransform(-0.05,-0.25,2.3871,2.3871,0,0,0,59,58.9);
	this.instance_1.compositeOperation = "screen";

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B6BA0").s().p("AmZGnQiwiqgEj0QgEjzCqivQCrivD0gEQDzgECwCqQCvCqAED0QAEDyiqCwQirCvj0AEIgKAAQjtAAirimg");
	this.shape_2.setTransform(-0.1199,-0.2489,2.3871,2.3871);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.instance_1},{t:this.instance},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-140.9,-140.8,281.8,281.70000000000005), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Mesh_1();
	this.instance.setTransform(-86.85,-86.85,1.4009,1.4009);

	this.instance_1 = new lib.Group();
	this.instance_1.setTransform(-0.55,0.15,1.4009,1.4009,0,0,0,61.7,60.8);
	this.instance_1.compositeOperation = "screen";

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA8ADB").s().p("AE6A6QgQgJgdgTQgggUgPgHQgWgJgYABQgdAAgnAJQgXAHgxAQQg2ASgbAHQgvAMgmAAQhJAChwgtQgSgHglgQQA7gjA7gUQBOAdAqgBQAZAAAkgKQAXgGAtgPIA8gTQC0AhCGB+QgcgHgdgPg");
	this.shape.setTransform(7.5181,-74.1379,1.4008,1.4008);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA8ADB").s().p("AjsBZQgRgKgbgaQgagZgSgMQgdgRgogIQgSgDgSAAIgCgCQgjgigigsQA2gWBGANQA5AKAtAcQAZAQAiAhQASAQAHAFQAIAGAIAAQAKAAAQgJIAggUQArgfAegNQAygXA3ACQA4ABApATQAXAKAcAXIAQALQAEACAGAAQALAAA1gXQBGggAwgNQApgLAqgEQgZAigiAkQgfAegjAcIgmARQgnARgQAFQgbAJgUAAQgbAAgYgLQgNgHgUgQQgTgPgPgGQgXgKgkgBQgjgBgfAPQgTAIgkAZQggAYgTAJQgfAPgeAAQghAAgdgSg");
	this.shape_1.setTransform(0.094,63.2564,1.4008,1.4008);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#613D99").s().p("AHpBxQg4AAgpgZQgYgOgggjQgagbgPgKQgYgPgkgEQgigEgcANQgSAIglAeQgxAogfAPQg3AchEAAIgHAAQhIgBg7gcQgjgPg1gmQgkgbgSgHQgcgOgfAAQhDAAhLAwIgCABQgTgugJguQBZgzBTAAQAzAAAtAVQAbANAtAgQAsAgAbAMQAqATA1ABQAxABAlgSQAWgLAoghQAwgnAegNQAygYA8AHQA6AHArAcQAaARAgAjQAXAZAOAHQAUAMAggBQAggBAagIQAVgGAYgNQgSA8ghA5QgZAFgYAAg");
	this.shape_2.setTransform(-1.1317,26.0685,1.4008,1.4008);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA8ADB").s().p("AnLB9QgzgKhGgbIgfgNQACgxAKgvIA2AWQBPAeAwAFQAXACAKgEQATgKAtgiQBGg4AwgYQBRgpBZABQBBABAxAfQAcATAnAsQAiAnAWANQAlAVA5gBQA4gBApgWQAZgNArgjQAigeAUgNQAhgWAlgKQAQArAJAvQgYAHgWAOQgOALgcAXQgyAsgkASQg9AfhOACIgIAAQhPAAg4giQgWgNgXgVQgMgLgWgaQgeghgRgLQgagRglgBQhEAAg/AgQglASg/AxQgyAogcAPQgZANglAAQgZAAgegGg");
	this.shape_3.setTransform(-0.9917,-14.4603,1.4008,1.4008);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#613D99").s().p("ABmBSQiDgLhrgkQikg2jFA0IguAOQAjg/Azg3QA+gNBAgBQB5gEBrAlQCmA3DvgMQBngGBUgSQAhAqAWAqIgiAHQhPARhjAHQg7AFg4AAQg7AAg4gFg");
	this.shape_4.setTransform(-0.0461,-48.3117,1.4008,1.4008);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#6C78E6","#7377E2","#8774D6","#A76FC4","#D368AA"],[0,0.161,0.4,0.686,1],-43.6,43.7,43.7,-43.6).s().p("AmtG7Qi4iygEj/QgEj/Cyi4QCyi3EAgEQD/gFC4CyQC4CyAEEAQAED/iyC3QiyC4kAAEIgKAAQj5AAi0iug");
	this.shape_5.setTransform(-0.2496,-0.3114,1.4009,1.4009);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-87,-86.8,174,173.7), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-471,-529.5,942,1059), null);


(lib.Group_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_9_1();
	this.instance.setTransform(44.1,40.5,1,1,0,0,0,44.1,40.5);
	this.instance.alpha = 0.5;
	this.instance.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(-0.1,0,88.5,81.1), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_5_1();
	this.instance.setTransform(20.4,19.5,1,1,0,0,0,20.4,19.5);
	this.instance.alpha = 0.5;
	this.instance.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0.1,40.8,38.9), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol16();
	this.instance.setTransform(-0.7,2.65,1,1,0,0,0,-0.7,2.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({alpha:0},0).wait(5).to({alpha:1},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.6,-25.9,62,57);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol14();
	this.instance.setTransform(168.55,37.45,1,1,0,0,0,-11.5,-9.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:1019.25,y:-529.65},49).wait(1));

	// Isolation_Mode
	this.instance_1 = new lib.Symbol17("synched",0);
	this.instance_1.setTransform(74.85,81.55,1,1,0,0,0,-0.7,2.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:925.55,y:-485.55,startPosition:9},49).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(39.4,-619.1,1109.1,746.2);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Isolation_Mode
	this.instance = new lib.Symbol13();
	this.instance.setTransform(84.2,-30.55,1,1,0,0,0,0,44);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,rotation:-19.4886,x:84.35,y:-30.6},11).to({regX:0,rotation:0,x:84.2,y:-30.55},13).to({regX:0.1,rotation:14.9992,x:84.3,y:-30.5},12).to({regX:0,rotation:0,x:84.2,y:-30.55},13).wait(1));

	// Layer_1
	this.instance_1 = new lib.Symbol11();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.2,-145.2,209.3,290.4);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol9();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-140.9,-140.8,281.8,281.70000000000005), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_23_1();
	this.instance.setTransform(-122.8,-150.6,1,1,0,0,0,23.6,20.4);
	this.instance.alpha = 0.5;
	this.instance.compositeOperation = "multiply";

	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#3D599F","#405EA1","#496CA7","#5784B0","#6CA5BD","#80C6CA"],[0,0.153,0.333,0.529,0.729,0.898],31.5,-32.9,-38.3,27.2).s().p("Ak+FFQADg4gUgWQgdgZgUggQguhLA5hsQA0hhCGhzQCGhzBngjQBxgnBCA9QAqAnAZAQQAiAXAoAIQBTAQhxCVQhYB0iFByQh+BtiOBHQhVArgqAAQgrAAABgug");
	this.shape.setTransform(-109.2448,-135.948);

	this.instance_1 = new lib.Path_22_1();
	this.instance_1.setTransform(126.45,149.65,1,1,0,0,0,19.6,15.8);
	this.instance_1.alpha = 0.5;
	this.instance_1.compositeOperation = "multiply";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#80C6CA","#6CA5BD","#5784B0","#496CA7","#405EA1","#3D599F"],[0.102,0.271,0.471,0.667,0.847,1],-26.3,25.3,31.8,-20.8).s().p("AjAEDQgggggUgOQgbgUgggHQhCgQBfh1QBLhZBvhZQBohTB1g1QCNhAgGBIQgEAuAPASIAmAvQAjA/gyBTQgtBNhvBZQhvBYhVAZQggAJgbAAQgyAAghghg");
	this.shape_1.setTransform(115.9262,137.6894);

	this.instance_2 = new lib.Path_21_1();
	this.instance_2.setTransform(123.55,-74.95,1,1,0,0,0,5,3.5);
	this.instance_2.alpha = 0.5;
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_1_12();
	this.instance_3.setTransform(-13.1,-143.55,1,1,0,0,0,5.3,3.1);
	this.instance_3.alpha = 0.5;
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_2_1();
	this.instance_4.setTransform(-90.45,-14.9,1,1,0,0,0,6.8,7.9);
	this.instance_4.alpha = 0.5;
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_3_0();
	this.instance_5.setTransform(-102.9,-81.95,1,1,0,0,0,11,11.1);
	this.instance_5.alpha = 0.5;
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_4_0();
	this.instance_6.setTransform(-36.05,-160.75,1,1,0,0,0,8.7,5.2);
	this.instance_6.alpha = 0.5;
	this.instance_6.compositeOperation = "multiply";

	this.instance_7 = new lib.Path_20_1();
	this.instance_7.setTransform(-108.1,96.95,1,1,0,0,0,4.3,4.4);
	this.instance_7.alpha = 0.5;
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.Path_1_11();
	this.instance_8.setTransform(-83,123.25,1,1,0,0,0,4.3,4.4);
	this.instance_8.alpha = 0.5;
	this.instance_8.compositeOperation = "multiply";

	this.instance_9 = new lib.Path_2_0();
	this.instance_9.setTransform(-100.95,115.8,1,1,0,0,0,7,7.3);
	this.instance_9.alpha = 0.5;
	this.instance_9.compositeOperation = "multiply";

	this.instance_10 = new lib.Path_5_0();
	this.instance_10.setTransform(135.5,-3.9,1,1,0,0,0,2.6,4.6);
	this.instance_10.alpha = 0.5;
	this.instance_10.compositeOperation = "multiply";

	this.instance_11 = new lib.Path_6_0();
	this.instance_11.setTransform(-97.85,25.6,1,1,0,0,0,4.7,6.5);
	this.instance_11.alpha = 0.5;
	this.instance_11.compositeOperation = "multiply";

	this.instance_12 = new lib.Path_7_0();
	this.instance_12.setTransform(133.1,-39.1,1,1,0,0,0,4.7,6.5);
	this.instance_12.alpha = 0.5;
	this.instance_12.compositeOperation = "multiply";

	this.instance_13 = new lib.Path_8_0();
	this.instance_13.setTransform(-155,-9.95,1,1,0,0,0,2.8,4.8);
	this.instance_13.alpha = 0.5;
	this.instance_13.compositeOperation = "multiply";

	this.instance_14 = new lib.Path_9_0();
	this.instance_14.setTransform(87.7,119.55,1,1,0,0,0,4.6,4.1);
	this.instance_14.alpha = 0.5;
	this.instance_14.compositeOperation = "multiply";

	this.instance_15 = new lib.Path_10_0();
	this.instance_15.setTransform(64.95,137,1,1,0,0,0,8.6,5.4);
	this.instance_15.alpha = 0.5;
	this.instance_15.compositeOperation = "multiply";

	this.instance_16 = new lib.Path_19_1();
	this.instance_16.setTransform(153.35,-64.05,1,1,0,0,0,4.8,8.2);
	this.instance_16.alpha = 0.5;
	this.instance_16.compositeOperation = "multiply";

	this.instance_17 = new lib.Path_1_10();
	this.instance_17.setTransform(154.95,-65.05,1,1,0,0,0,6.4,9.2);
	this.instance_17.alpha = 0.5;
	this.instance_17.compositeOperation = "multiply";

	this.instance_18 = new lib.Path_18_1();
	this.instance_18.setTransform(82.1,-101.75,1,1,0,0,0,10.2,6);
	this.instance_18.alpha = 0.5;
	this.instance_18.compositeOperation = "multiply";

	this.instance_19 = new lib.Path_1_9();
	this.instance_19.setTransform(82.9,-103.6,1,1,0,0,0,11.1,8);
	this.instance_19.alpha = 0.5;
	this.instance_19.compositeOperation = "multiply";

	this.instance_20 = new lib.Path_17_1();
	this.instance_20.setTransform(-46.35,-117.4,1,1,0,0,0,10.3,6);
	this.instance_20.alpha = 0.5;
	this.instance_20.compositeOperation = "multiply";

	this.instance_21 = new lib.Path_1_8();
	this.instance_21.setTransform(-47.65,-119.5,1,1,0,0,0,11.6,8.3);
	this.instance_21.alpha = 0.5;
	this.instance_21.compositeOperation = "multiply";

	this.instance_22 = new lib.Path_16_1();
	this.instance_22.setTransform(-135.1,-44.35,1,1,0,0,0,4.4,11.2);
	this.instance_22.alpha = 0.5;
	this.instance_22.compositeOperation = "multiply";

	this.instance_23 = new lib.Path_1_7();
	this.instance_23.setTransform(-137.15,-44.5,1,1,0,0,0,6.5,12.1);
	this.instance_23.alpha = 0.5;
	this.instance_23.compositeOperation = "multiply";

	this.instance_24 = new lib.Path_15_1();
	this.instance_24.setTransform(164.45,-16.8,1,1,0,0,0,5.2,13.2);
	this.instance_24.alpha = 0.5;
	this.instance_24.compositeOperation = "multiply";

	this.instance_25 = new lib.Path_1_6();
	this.instance_25.setTransform(166.75,-17.7,1,1,0,0,0,7.5,14.3);
	this.instance_25.alpha = 0.5;
	this.instance_25.compositeOperation = "multiply";

	this.instance_26 = new lib.Path_14_1();
	this.instance_26.setTransform(-50.9,143.25,1,1,0,0,0,12.6,5.9);
	this.instance_26.alpha = 0.5;
	this.instance_26.compositeOperation = "multiply";

	this.instance_27 = new lib.Path_1_5();
	this.instance_27.setTransform(-51.5,145.55,1,1,0,0,0,13.6,8.2);
	this.instance_27.alpha = 0.5;
	this.instance_27.compositeOperation = "multiply";

	this.instance_28 = new lib.Path_13_1();
	this.instance_28.setTransform(21.4,155.8,1,1,0,0,0,13.2,4.5);
	this.instance_28.alpha = 0.5;
	this.instance_28.compositeOperation = "multiply";

	this.instance_29 = new lib.Path_1_4();
	this.instance_29.setTransform(22.05,158.2,1,1,0,0,0,14.3,6.9);
	this.instance_29.alpha = 0.5;
	this.instance_29.compositeOperation = "multiply";

	this.instance_30 = new lib.Path_12_1();
	this.instance_30.setTransform(107.95,-117.35,1,1,0,0,0,15.2,11.7);
	this.instance_30.alpha = 0.5;
	this.instance_30.compositeOperation = "multiply";

	this.instance_31 = new lib.Path_1_3();
	this.instance_31.setTransform(109.8,-120.25,1,1,0,0,0,17.1,14.7);
	this.instance_31.alpha = 0.5;
	this.instance_31.compositeOperation = "multiply";

	this.instance_32 = new lib.Path_11_1();
	this.instance_32.setTransform(-126.4,40.45,1,1,0,0,0,16.8,34.3);
	this.instance_32.alpha = 0.5;
	this.instance_32.compositeOperation = "multiply";

	this.instance_33 = new lib.Path_1_2();
	this.instance_33.setTransform(-133.75,43.6,1,1,0,0,0,24.2,37.8);
	this.instance_33.alpha = 0.5;
	this.instance_33.compositeOperation = "multiply";

	this.instance_34 = new lib.Path_10_1();
	this.instance_34.setTransform(62.65,42.7,1,1,0,0,0,41,35.3);
	this.instance_34.alpha = 0.5;
	this.instance_34.compositeOperation = "multiply";

	this.instance_35 = new lib.Group_0();
	this.instance_35.setTransform(65.75,47.9,1,1,0,0,0,44.1,40.5);
	this.instance_35.alpha = 0.5;
	this.instance_35.compositeOperation = "multiply";

	this.instance_36 = new lib.Path_8_1();
	this.instance_36.setTransform(21,-84.65,1,1,0,0,0,25.3,20);
	this.instance_36.alpha = 0.5;
	this.instance_36.compositeOperation = "multiply";

	this.instance_37 = new lib.Path_7_1();
	this.instance_37.setTransform(22.3,-88,1,1,0,0,0,26.6,23.4);
	this.instance_37.alpha = 0.5;
	this.instance_37.compositeOperation = "multiply";

	this.instance_38 = new lib.Path_6_1();
	this.instance_38.setTransform(-68.1,75,1,1,0,0,0,18.4,17.4);
	this.instance_38.alpha = 0.5;
	this.instance_38.compositeOperation = "multiply";

	this.instance_39 = new lib.Group_2();
	this.instance_39.setTransform(-70.05,77.1,1,1,0,0,0,20.4,19.5);
	this.instance_39.alpha = 0.5;
	this.instance_39.compositeOperation = "multiply";

	this.instance_40 = new lib.Path_4_1();
	this.instance_40.setTransform(-1.8,115.3,1,1,0,0,0,23,7.7);
	this.instance_40.alpha = 0.5;
	this.instance_40.compositeOperation = "multiply";

	this.instance_41 = new lib.Path_1_1();
	this.instance_41.setTransform(-1.6,119.4,1,1,0,0,0,24.6,11.8);
	this.instance_41.alpha = 0.5;
	this.instance_41.compositeOperation = "multiply";

	this.instance_42 = new lib.Path_3_1();
	this.instance_42.setTransform(142.65,49.75,1,1,0,0,0,13.5,30.3);
	this.instance_42.alpha = 0.5;
	this.instance_42.compositeOperation = "multiply";

	this.instance_43 = new lib.Path_1_0();
	this.instance_43.setTransform(148.35,50.85,1,1,0,0,0,19.2,32.5);
	this.instance_43.alpha = 0.5;
	this.instance_43.compositeOperation = "multiply";

	this.instance_44 = new lib.Path_2_2();
	this.instance_44.setTransform(37,-140.9,1,1,0,0,0,33,11.5);
	this.instance_44.alpha = 0.5;
	this.instance_44.compositeOperation = "multiply";

	this.instance_45 = new lib.Path_1_13();
	this.instance_45.setTransform(37.2,-146.95,1,1,0,0,0,35.4,17.5);
	this.instance_45.alpha = 0.5;
	this.instance_45.compositeOperation = "multiply";

	this.instance_46 = new lib.Mesh();
	this.instance_46.setTransform(-172,-178.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#3D599F","#405EA1","#496CA7","#5784B0","#6CA5BD","#80C6CA"],[0,0.153,0.333,0.529,0.729,0.898],40,-150.8,0,40,-150.8,349.3).s().p("AkIbYQllg0kxi5QknizjOkVQjPkWhVlNQhZlaA2ljQA2llC7kxQC1knEXjPQEYjPFPhXQFbhbFkAzQFlA1ExC4QEnCzDPEVQDOEWBWFNQBYFag2FjQg2Fli7ExQi0EnkYDPQkYDPlPBXQjdA6jgAAQiAAAiCgSg");
	this.shape_2.setTransform(5.5286,-1.65);

	this.instance_47 = new lib.Path_0();
	this.instance_47.setTransform(-180.35,55.9,1,1,0,0,0,7.2,21.1);
	this.instance_47.alpha = 0.5;
	this.instance_47.compositeOperation = "multiply";

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#3D599F","#405EA1","#496CA7","#5784B0","#6CA5BD","#80C6CA"],[0,0.153,0.333,0.529,0.729,0.898],-10.1,-29,9.2,34.1).s().p("AhQEDQgyg/gkh5Qglh3AHhPQAIhVA7gaQAngRARgLQAZgRARgYQAjgyBBB1QA0BdAkB3QAjBxAFByQAHCKg6gcQglgRgUAGQgZANgbADIgOABQg3AAgwg8g");
	this.shape_3.setTransform(-168.7305,50.0987);

	this.instance_48 = new lib.Path_99();
	this.instance_48.setTransform(169.7,-112.9,1,1,0,0,0,17.4,25.6);
	this.instance_48.alpha = 0.5;
	this.instance_48.compositeOperation = "multiply";

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#80C6CA","#6CA5BD","#5784B0","#496CA7","#405EA1","#3D599F"],[0.102,0.271,0.471,0.667,0.847,1],27.6,34.7,-22.9,-41.7).s().p("AAbFVQhohmhgiRQhbiJg0iWQg/i0BYAOQA4AJAZgQIAYgTQARgOAVgJQBSgkBiBFQBbBABhCSQBgCSAWBrQAWB0hEA5QgtAmgTAWQgbAggNAmQgLAfgaAAQgqAAhShRg");
	this.shape_4.setTransform(154.2683,-100.6576);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#80C6CA").s().p("AhjDsQipgxhWhEQhdhJAPhXQAKg5AAgeQAAgpgPgmQgfhOC7AMQCSAKCnAxQCgAtCJBQQCmBghOAuQgwAdgJAcQgCAJgEAVQgEAWgKAUQgnBRh5ALQgTACgWAAQhkAAiKgog");
	this.shape_5.setTransform(-38.6351,169.4326);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3E6C9E").s().p("AgRClQh4gZhpg0Qh/g/A3glQAigXAFgWQABgcAKgaQAYg9BZgPQBSgNB+AbQB/AbBCAuQBJAxgHBBQgEArABAVQACAeANAbQAbA4iKABQhsAAh+gbg");
	this.shape_6.setTransform(43.5399,-177.8362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance_48},{t:this.shape_3},{t:this.instance_47},{t:this.shape_2},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.shape_1},{t:this.instance_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-188.5,-197,377.1,394), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Isolation_Mode
	this.instance = new lib.Symbol10();
	this.instance.setTransform(801.1,-652.85);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:-647.45},24).to({y:-652.85},25).wait(1));

	// Isolation_Mode
	this.instance_1 = new lib.Symbol8();
	this.instance_1.setTransform(167.25,-601.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:-583.3},24).to({y:-601.3},25).wait(1));

	// Layer_1
	this.instance_2 = new lib.Symbol6();
	this.instance_2.setTransform(-0.05,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({y:-18},24).to({y:0},25).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-188.6,-793.7,1130.6,990.7);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Isolation_Mode
	this.instance = new lib.Symbol12("synched",0);
	this.instance.setTransform(-119.6,37.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-8.4763,x:-138.75,y:19.6,startPosition:24},24).to({rotation:0,x:-119.6,y:37.7,startPosition:49},25).wait(1));

	// Layer_1
	this.instance_1 = new lib.Symbol7("synched",0);
	this.instance_1.setTransform(-330.8,419.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50));

	// Isolation_Mode
	this.instance_2 = new lib.Symbol15("synched",0);
	this.instance_2.setTransform(-479.55,352.9,1,1,0,0,0,-11.5,-9.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50));

	// Layer_1
	this.instance_3 = new lib.Symbol4();
	this.instance_3.setTransform(451.9,0.1);
	this.instance_3.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50));

	// Layer_1
	this.instance_4 = new lib.Symbol2();

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-519.4,-541.8,1924.8000000000002,1158.6999999999998);


// stage content:
(lib.Untitled1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		this.clearAllSoundStreams();
		 
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50));

	// Layer_1
	this.instance = new lib.Symbol3("synched",0);
	this.instance.setTransform(471,529.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(50));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(422.6,517.2,1453.8000000000002,629.2);
// library properties:
lib.properties = {
	id: '4E88A15AFE4C8E47B6A8557A5978AE7C',
	width: 942,
	height: 1059,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"Mesh.png", id:"Mesh"},
		{src:"Mesh_1.png", id:"Mesh_1"},
		{src:"Mesh_2.png", id:"Mesh_2"},
		{src:"Mesh_0.png", id:"Mesh_0"},
		{src:"Mesh_0_1.png", id:"Mesh_0_1"},
		{src:"Mesh_1_1.png", id:"Mesh_1_1"},
		{src:"Mesh_0_2.png", id:"Mesh_0_2"},
		{src:"Mesh_1_2.png", id:"Mesh_1_2"},
		{src:"Mesh_3.png", id:"Mesh_3"},
		{src:"Mesh_1_0.png", id:"Mesh_1_0"},
		{src:"Mesh_2_1.png", id:"Mesh_2_1"},
		{src:"Mesh_2_2.png", id:"Mesh_2_2"},
		{src:"Mesh_3_1.png", id:"Mesh_3_1"},
		{src:"Mesh_4.png", id:"Mesh_4"},
		{src:"Mesh_5.png", id:"Mesh_5"},
		{src:"Path.png", id:"Path"},
		{src:"Path_1.png", id:"Path_1"},
		{src:"Path_10.png", id:"Path_10"},
		{src:"Path_11.png", id:"Path_11"},
		{src:"Path_12.png", id:"Path_12"},
		{src:"Mesh_4_1.png", id:"Mesh_4_1"},
		{src:"Path_13.png", id:"Path_13"},
		{src:"Path_14.png", id:"Path_14"},
		{src:"Path_15.png", id:"Path_15"},
		{src:"Mesh_3_2.png", id:"Mesh_3_2"},
		{src:"Path_17.png", id:"Path_17"},
		{src:"Path_18.png", id:"Path_18"},
		{src:"Path_19.png", id:"Path_19"},
		{src:"Path_2.png", id:"Path_2"},
		{src:"Path_21.png", id:"Path_21"},
		{src:"Path_22.png", id:"Path_22"},
		{src:"Path_23.png", id:"Path_23"},
		{src:"Path_24.png", id:"Path_24"},
		{src:"Path_25.png", id:"Path_25"},
		{src:"Path_26.png", id:"Path_26"},
		{src:"Path_27.png", id:"Path_27"},
		{src:"Path_28.png", id:"Path_28"},
		{src:"Path_29.png", id:"Path_29"},
		{src:"Path_3.png", id:"Path_3"},
		{src:"Path_30.png", id:"Path_30"},
		{src:"Path_31.png", id:"Path_31"},
		{src:"Path_32.png", id:"Path_32"},
		{src:"Path_33.png", id:"Path_33"},
		{src:"Path_34.png", id:"Path_34"},
		{src:"Path_35.png", id:"Path_35"},
		{src:"Path_36.png", id:"Path_36"},
		{src:"Path_37.png", id:"Path_37"},
		{src:"Path_38.png", id:"Path_38"},
		{src:"Path_39.png", id:"Path_39"},
		{src:"Path_4.png", id:"Path_4"},
		{src:"Path_40.png", id:"Path_40"},
		{src:"Path_41.png", id:"Path_41"},
		{src:"Path_42.png", id:"Path_42"},
		{src:"Path_43.png", id:"Path_43"},
		{src:"Path_44.png", id:"Path_44"},
		{src:"Path_45.png", id:"Path_45"},
		{src:"Path_46.png", id:"Path_46"},
		{src:"Path_47.png", id:"Path_47"},
		{src:"Path_48.png", id:"Path_48"},
		{src:"Path_49.png", id:"Path_49"},
		{src:"Path_5.png", id:"Path_5"},
		{src:"Path_50.png", id:"Path_50"},
		{src:"Path_51.png", id:"Path_51"},
		{src:"Path_52.png", id:"Path_52"},
		{src:"Path_53.png", id:"Path_53"},
		{src:"Path_54.png", id:"Path_54"},
		{src:"Path_55.png", id:"Path_55"},
		{src:"Path_56.png", id:"Path_56"},
		{src:"Path_57.png", id:"Path_57"},
		{src:"Path_58.png", id:"Path_58"},
		{src:"Path_59.png", id:"Path_59"},
		{src:"Path_6.png", id:"Path_6"},
		{src:"Path_60.png", id:"Path_60"},
		{src:"Path_61.png", id:"Path_61"},
		{src:"Path_62.png", id:"Path_62"},
		{src:"Path_63.png", id:"Path_63"},
		{src:"Path_64.png", id:"Path_64"},
		{src:"Path_65.png", id:"Path_65"},
		{src:"Path_66.png", id:"Path_66"},
		{src:"Path_67.png", id:"Path_67"},
		{src:"Path_68.png", id:"Path_68"},
		{src:"Path_69.png", id:"Path_69"},
		{src:"Path_7.png", id:"Path_7"},
		{src:"Path_70.png", id:"Path_70"},
		{src:"Path_71.png", id:"Path_71"},
		{src:"Path_72.png", id:"Path_72"},
		{src:"Path_73.png", id:"Path_73"},
		{src:"Path_74.png", id:"Path_74"},
		{src:"Path_75.png", id:"Path_75"},
		{src:"Path_76.png", id:"Path_76"},
		{src:"Path_77.png", id:"Path_77"},
		{src:"Path_78.png", id:"Path_78"},
		{src:"Path_79.png", id:"Path_79"},
		{src:"Path_8.png", id:"Path_8"},
		{src:"Path_80.png", id:"Path_80"},
		{src:"Path_81.png", id:"Path_81"},
		{src:"Path_82.png", id:"Path_82"},
		{src:"Path_83.png", id:"Path_83"},
		{src:"Path_84.png", id:"Path_84"},
		{src:"Path_85.png", id:"Path_85"},
		{src:"Path_86.png", id:"Path_86"},
		{src:"Path_87.png", id:"Path_87"},
		{src:"Path_88.png", id:"Path_88"},
		{src:"Path_89.png", id:"Path_89"},
		{src:"Path_9.png", id:"Path_9"},
		{src:"Path_90.png", id:"Path_90"},
		{src:"Path_91.png", id:"Path_91"},
		{src:"Path_92.png", id:"Path_92"},
		{src:"Path_93.png", id:"Path_93"},
		{src:"Path_94.png", id:"Path_94"},
		{src:"Path_95.png", id:"Path_95"},
		{src:"Path_96.png", id:"Path_96"},
		{src:"Path_16.png", id:"Path_16"},
		{src:"Path_20.png", id:"Path_20"},
		{src:"Mesh_6.png", id:"Mesh_6"},
		{src:"Mesh_7.png", id:"Mesh_7"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['4E88A15AFE4C8E47B6A8557A5978AE7C'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;